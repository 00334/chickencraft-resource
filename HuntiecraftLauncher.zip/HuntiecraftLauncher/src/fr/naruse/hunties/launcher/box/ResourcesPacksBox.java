package fr.naruse.hunties.launcher.box;

import fr.naruse.hunties.launcher.main.HuntiesPanel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ResourcesPacksBox {
    private HcnCheckBox box1, box2, box3, box4, box5, box6, box7, box8, box9;
    private List<HcnCheckBox> hcnCheckBoxes = new ArrayList<>();
    public ResourcesPacksBox(HuntiesPanel huntiesPanel) {
        int y = 16;
        this.box1 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293, 18, 19);
        this.box1.addTo(huntiesPanel);
        hcnCheckBoxes.add(box1);
        this.box2 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*1, 18, 19);
        this.box2.addTo(huntiesPanel);
        hcnCheckBoxes.add(box2);
        this.box3 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*2, 18, 19);
        this.box3.addTo(huntiesPanel);
        hcnCheckBoxes.add(box3);
        this.box4 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*3, 18, 19);
        this.box4.addTo(huntiesPanel);
        hcnCheckBoxes.add(box4);
        this.box5 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*4, 18, 19);
        this.box5.addTo(huntiesPanel);
        hcnCheckBoxes.add(box5);
        this.box6 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*5, 18, 19);
        this.box6.addTo(huntiesPanel);
        hcnCheckBoxes.add(box6);
        this.box7 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*6, 18, 19);
        this.box7.addTo(huntiesPanel);
        hcnCheckBoxes.add(box7);
        this.box8 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*7, 18, 19);
        this.box8.addTo(huntiesPanel);
        hcnCheckBoxes.add(box8);
        this.box9 = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 293+(19+6)*8, 18, 19);
        this.box9.addTo(huntiesPanel);
        hcnCheckBoxes.add(box9);
        setVisible(false);
    }

    private HashMap<String, String> shaderName = new HashMap<>();
    public List<String> getDownloadLinks(){
        List<String> links = new ArrayList<>();
        if(box1.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Pulchra-1024x.zip";
            links.add(link);
            shaderName.put(link, "Pulchra-x1024.zip");
        }
        if(box2.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Pulchra-512x.zip";
            links.add(link);
            shaderName.put(link, "Pulchra-x512.zip");
        }
        if(box3.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Pulchra-256x.zip";
            links.add(link);
            shaderName.put(link, "Pulchra-x256.zip");
        }
        if(box4.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Pulchra-128x.zip";
            links.add(link);
            shaderName.put(link, "Pulchra-x128.zip");
        }
        if(box5.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Modern-HD-64x.zip";
            links.add(link);
            shaderName.put(link, "Modern-HD-x64.zip");
        }
        if(box6.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Neela-Revamp-16x.zip";
            links.add(link);
            shaderName.put(link, "Neela-Revamp-x16.zip");
        }
        if(box7.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/R3D-CRAFT-512x.zip";
            links.add(link);
            shaderName.put(link, "R3D-CRAFT-x512.zip");
        }
        if(box8.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Paintrain-256x.zip";
            links.add(link);
            shaderName.put(link, "Paintrain-x256.zip");
        }
        if(box9.isSelected()){
            String link = "https://huntiescraft.net/app/webroot/launcher/resourcespacks/Faithful.zip";
            links.add(link);
            shaderName.put(link, "Faithful.zip");
        }
        return links;
    }

    public void setVisible(boolean b) {
        for(HcnCheckBox hcnCheckBox : hcnCheckBoxes){
            hcnCheckBox.setVisible(b);
        }
    }

    public String getShaderName(String link) {
        return shaderName.get(link);
    }
}
