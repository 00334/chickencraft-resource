package fr.naruse.hunties.launcher.box;

import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class HcnCheckBox implements MouseListener {
    private STexturedButton button, hover;
    private boolean isSelected = false;
    private int memory;
    public HcnCheckBox(String imageURL, String hoverURL, int x, int y, int width, int height){
        this(imageURL, hoverURL, x, y, width, height, 0);
    }

    public HcnCheckBox(String imageURL, String hoverURL, int x, int y, int width, int height, int memory){
        this.button = new STexturedButton(Swinger.getResource(imageURL));
        this.button.setBounds(x, y, width, height);
        this.button.setOpaque(false);
        this.button.addMouseListener(this);
        this.hover = new STexturedButton(Swinger.getResource(hoverURL));
        this.hover.setBounds(x, y, width, height);
        this.hover.setOpaque(false);
        this.hover.setVisible(false);
        this.hover.addMouseListener(this);
        this.memory = memory;
    }

    public void addTo(JPanel panel) {
        panel.add(button);
        panel.add(hover);
    }

    public void addMouseListener(MouseListener mouseListener){
        button.addMouseListener(mouseListener);
        hover.addMouseListener(mouseListener);
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
        if(isSelected){
            button.setVisible(false);
            hover.setVisible(true);
        }else {
            hover.setVisible(false);
            button.setVisible(true);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(isSelected){
            isSelected = false;
            hover.setVisible(false);
            button.setVisible(true);
        }else {
            isSelected = true;
            hover.setVisible(true);
            button.setVisible(false);
        }
        UtilsInterfaceManager.getInterfaceOption().getRamBoxesSelector().mouseClicked(this);
        UtilsInterfaceManager.getInterfaceOption().getGameConfigurationSelector().mouseClicked(this);
        UtilsInterfaceManager.getInterfaceOption().getInstallationPathSelector().mouseClicked(this);
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public int getMemory() {
        return memory;
    }

    public void setVisible(boolean b) {
        button.setVisible(b);
        hover.setVisible(b);
    }

    public boolean isVisible(){
        return button.isVisible();
    }
}
