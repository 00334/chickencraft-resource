package fr.naruse.hunties.launcher.box;

import fr.naruse.hunties.launcher.main.HuntiesPanel;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ShadersBox {
    private HcnCheckBox seusShader, continuumShader, sildurShader, kuda, doctorDread, wavingPlants;
    private List<HcnCheckBox> hcnCheckBoxes = new ArrayList<>();
    public ShadersBox(HuntiesPanel huntiesPanel) {
        int y = 16;
        this.continuumShader = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 70, 18, 19);
        this.continuumShader.addTo(huntiesPanel);
        hcnCheckBoxes.add(continuumShader);
        this.kuda = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 70+(19+5)*1, 18, 19);
        this.kuda.addTo(huntiesPanel);
        hcnCheckBoxes.add(kuda);
        this.sildurShader = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 70+(19+5)*2, 18, 19);
        this.sildurShader.addTo(huntiesPanel);
        hcnCheckBoxes.add(sildurShader);
        this.seusShader = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 70+(19+5)*3, 18, 19);
        this.seusShader.addTo(huntiesPanel);
        hcnCheckBoxes.add(seusShader);
        this.doctorDread = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 70+(19+5)*4, 18, 19);
        this.doctorDread.addTo(huntiesPanel);
        hcnCheckBoxes.add(doctorDread);
        this.wavingPlants = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 70+(19+5)*5, 18, 19);
        this.wavingPlants.addTo(huntiesPanel);
        hcnCheckBoxes.add(wavingPlants);
        setVisible(false);
    }
    private HashMap<String, String> shaderName = new HashMap<>();
    public List<String> getDownloadLinks(){
        List<String> links = new ArrayList<>();
        if(seusShader.isSelected()){
            String link = "https://huntiescraft.net/public/launcher/shaders/SEUS-v10.2-Preview-1-Ultra.zip";
            links.add(link);
            shaderName.put(link, getSeusName());
        }
        if(continuumShader.isSelected()){
            String link = "https://huntiescraft.net/public/launcher/shaders/Continuum-2.0-master.zip";
            links.add(link);
            shaderName.put(link, getContinuumName());
        }
        if(sildurShader.isSelected()){
            String link = "https://huntiescraft.net/public/launcher/shaders/Sildurs-Vibrant-Shaders-v1.19-Extreme.zip";
            links.add(link);
            shaderName.put(link, getSildurName());
        }
        if(kuda.isSelected()){
            String link = "https://huntiescraft.net/public/launcher/shaders/KUDA-Shaders-v6.1-Legacy.zip";
            links.add(link);
            shaderName.put(link, getKudaName());
        }
        if(doctorDread.isSelected()){
            String link = "https://huntiescraft.net/public/launcher/shaders/DocteurDreads-Shaders-v02-Ultra.zip";
            links.add(link);
            shaderName.put(link, getDrDreadsName());
        }
        if(wavingPlants.isSelected()){
            String link = "https://huntiescraft.net/public/launcher/shaders/Waving-Plants-V3.5.zip";
            links.add(link);
            shaderName.put(link, getWavingPlantsName());
        }
        return links;
    }

    public String getShaderName(String link){
        if(shaderName.containsKey(link)){
            return shaderName.get(link);
        }
        return "";
    }

    private String getSeusName(){
        return "Seus-Shaders.zip";
    }

    private String getContinuumName(){
        return "Continuum-Shaders.zip";
    }

    private String getSildurName(){
        return "Sildurs-Shaders.zip";
    }

    private String getDrDreadsName(){
        return "DocteurDreads-Shaders-v02-Ultra.zip";
    }

    private String getKudaName(){
        return "KUDA-Shaders-v6.1-Legacy.zip";
    }

    private String getWavingPlantsName(){
        return "Waving-Plants-V3.5.zip";
    }

    public void setVisible(boolean b) {
        for(HcnCheckBox hcnCheckBox : hcnCheckBoxes){
            hcnCheckBox.setVisible(b);
        }
    }
}
