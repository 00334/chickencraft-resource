package fr.naruse.hunties.launcher.utils;

import java.io.*;
import java.util.ArrayList;

public class HuntiesOption {
    private File file;
    private OperatorSystemType operatorSystemType;
    public HuntiesOption(File file){
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.file = file;
        if(getString("memory") == null){
            setString("memory", 1024+"");
        }
        if(getString("memory").equalsIgnoreCase("512")){
            setString("memory", 1024+"");
        }
        if(getString("memory").contains("m")){
            setString("memory", getString("memory").replace("m", ""));
        }
        if(getString("hasSawTrailer") == null){
            setString("hasSawTrailer", "false");
        }
        if(getString("path") == null){
            setString("path", "default");
        }
        if(getString("configuration") == null){
            setString("configuration", "2");
        }
        if(getString("version") == null){
            setString("version", "1.12.2");
        }
        if(getString("enableLogs") == null){
            setString("enableLogs", "true");
        }
        if(getString("showEnabledLogs") == null){
            setString("showEnabledLogs", "false");
        }
        this.operatorSystemType = Utils.osType();
        System.out.println("[HuntiesLauncher] Os type: "+operatorSystemType);
    }

    public String getString(String key){
        BufferedReader br = null;
        ArrayList<String> lines = new ArrayList<>();
        try {
            br = new BufferedReader(new FileReader(this.file));
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
            for(String s : lines){
                if(s.contains(":")){
                    if(s.split(":")[0].equals(key)){
                        return s.split(":")[1].substring(1);
                    }
                }
            }
        } catch (IOException var14) {
            System.err.println("[HuntiesLauncher] WARNING: Can't read options : " + var14);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException var13) {
                    System.err.println("[HuntiesLauncher] WARNING: Can't close the file : " + var13);
                }
            }

        }
        return null;
    }

    private ArrayList<String> read(){
        BufferedReader br = null;
        ArrayList<String> lines = new ArrayList<>();
        try {
            br = new BufferedReader(new FileReader(this.file));
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
            return lines;
        } catch (IOException var14) {
            System.err.println("[HuntiesLauncher] WARNING: Can't read options : " + var14);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException var13) {
                    System.err.println("[HuntiesLauncher] WARNING: Can't close the file : " + var13);
                }
            }

        }
        return null;
    }


    public void setString(String key, String value){
        ArrayList<String> list = new ArrayList<>();
        for(String line : read()){
            if(line.contains(":")){
                if(!line.split(":")[0].equalsIgnoreCase(key)){
                    list.add(line);
                }
            }
        }
        list.add(key+": "+value);
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(this.file));
            for(String line : list){
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException var11) {
            System.err.println("[HuntiesLauncher] WARNING: Can't save username : " + var11);
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException var10) {
                    System.err.println("[HuntiesLauncher] WARNING: Can't close the file : " + var10);
                }
            }
        }
    }

    public OperatorSystemType getOperatorSystemType() {
        return operatorSystemType;
    }
}
