package fr.naruse.hunties.launcher.utils.log;

import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.util.WindowMover;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.text.*;
import java.awt.*;
import java.lang.reflect.InvocationTargetException;

public class LogFrame extends JFrame  {
    private JTextPane jTextPane = new JTextPane();
    private JScrollPane jScrollPane = new JScrollPane(jTextPane);
    private static LogFrame INTANCE;
    public LogFrame() {
        this.INTANCE = this;
        this.setTitle("HuntiesCraft-Network | Console de Logs");
        this.setIconImage(Swinger.getResource("icon.jpg"));
        this.setSize(1200, 560);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        //this.setContentPane(null);
        WindowMover mover = new WindowMover(this);
        this.addMouseListener(mover);
        this.addMouseMotionListener(mover);

        JTextArea textArea = new JTextArea();
        jTextPane.setForeground(textArea.getForeground());
        jTextPane.setFont(textArea.getFont());
        jTextPane.setEditable(false);
        jTextPane.setBackground(Color.GRAY);

        this.add(jScrollPane);

        this.setVisible(true);

        setCloseOperation();
    }

    public static void setCloseOperation() {
        INTANCE.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void close(){
        for(Component c : INTANCE.getComponents()){
            INTANCE.remove(c);
        }
        INTANCE.setVisible(false);
    }

    public void showInfo(String info) {
        Document doc = jTextPane.getDocument();
        try {
            doc.insertString(doc.getLength(), info, null);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
        validate();
        if(jScrollPane.getVerticalScrollBar().getValue() >= jScrollPane.getVerticalScrollBar().getMaximum() -5 ){
            scrollDown();
        }
    }

    public void showInfo(String info, Color color) {
        StyledDocument doc = jTextPane.getStyledDocument();

        Style style = jTextPane.addStyle("I'm a Style", null);
        StyleConstants.setForeground(style, color);
        try {
            doc.insertString(doc.getLength(), info, style);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
        validate();
        if(jScrollPane.getVerticalScrollBar().getValue() >= jScrollPane.getVerticalScrollBar().getMaximum() -5 ){
            scrollDown();
        }
    }

    public void scrollDown(){
        jScrollPane.getVerticalScrollBar().setValue(jScrollPane.getVerticalScrollBar().getMaximum());
    }
}
