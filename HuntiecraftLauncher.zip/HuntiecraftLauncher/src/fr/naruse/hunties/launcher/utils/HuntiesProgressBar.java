package fr.naruse.hunties.launcher.utils;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Arc2D;

public class HuntiesProgressBar extends JComponent {
    private long value = 0, maximum = 100;
    public HuntiesProgressBar() {
        new Thread(){
            @Override
            public void run() {
                try {
                    sleep(1000*3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                while (true){
                    try {
                        sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(value == maximum){
                        return;
                    }
                    value++;
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().repaint(new Rectangle(290, 675, 80, 80));
                }
            }
        };
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(!isVisible()){
            return;
        }
        double per = value * 100 / maximum;
        double percentage = per/100*360;
        g.setColor(new Color(255, 255, 255, 255));
        g.setFont(g.getFont().deriveFont(14f).deriveFont(Font.BOLD));
        if(per == 100){
            if(UtilsInterfaceManager.State.getEnabledInterface() == null){
                g.drawString((int) per+"%", 307, 717);
            }
        }else{
            if(UtilsInterfaceManager.State.getEnabledInterface() == null){
                g.drawString((int) per+"%", 312, 717);
            }
        }

        g.setColor(new Color(255, 255, 255, 255));
        Shape shape = new Arc2D.Double(298, 680, 60, 60, 0, percentage, Arc2D.OPEN);
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        graphics.setStroke(new BasicStroke(4));
        graphics.draw(shape);
    }

    public long getMaximum() {
        return maximum;
    }

    public long getValue() {
        return value;
    }

    public void setMaximum(long maximum) {
        this.maximum = maximum;
        Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().repaint(new Rectangle(290, 675, 80, 80));
    }

    public void setValue(long value) {
        this.value = value;
        Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().repaint(new Rectangle(290, 675, 80, 80));
    }

    @Override
    public void setVisible(boolean aFlag) {
        super.setVisible(aFlag);
        if(Main.INSTANCE.getHuntiesFrame() != null) {
            Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().repaint(new Rectangle(290, 675, 80, 80));
        }
    }
}
