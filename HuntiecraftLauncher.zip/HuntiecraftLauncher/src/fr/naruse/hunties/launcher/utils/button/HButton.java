package fr.naruse.hunties.launcher.utils.button;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TimerTask;

public class HButton extends JButton {
    private HButton instance;
    private int i = 0;
    private float opacity = 1f;
    private OpacityAnimator opacityAnimator;
    public HButton(ImageIcon imageIcon, boolean isHover) {
        super(imageIcon);
        instance = this;
        this.opacityAnimator = new OpacityAnimator();
        setOpaque(false);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));
    }

    @Override
    protected void paintComponent(Graphics gr)
    {
        super.paintComponent(gr);
        Graphics2D g = (Graphics2D) gr;
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));
    }

    @Override
    public void setVisible(boolean aFlag) {
        if(aFlag){
            opacityAnimator.changeOpacity(1.0f, 1000);
        }else{
            opacityAnimator.changeOpacity(0.0f, 250);
        }
        super.setVisible(aFlag);
    }

    public void setOpacity(float opacity)
    {
        this.opacity = opacity;
        repaint();
    }

    public class OpacityAnimator {
        private final int DELAY_MS = 10;
        private final Timer timer;

        private float targetOpacity;
        private float currentOpacity;
        private float opacityStep;

        OpacityAnimator()
        {
            timer = new Timer(DELAY_MS, new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    System.out.println(opacity);
                    if (currentOpacity > targetOpacity)
                    {
                        currentOpacity += opacityStep;
                        currentOpacity = Math.max(
                                currentOpacity, targetOpacity);
                    }
                    else if (currentOpacity < targetOpacity)
                    {
                        currentOpacity += opacityStep;
                        currentOpacity = Math.min(
                                currentOpacity, targetOpacity);
                    }
                    if (currentOpacity == targetOpacity)
                    {
                        timer.stop();
                    }
                    setOpacity(currentOpacity);
                }
            });
        }

        void changeOpacity(float targetOpacity, int durationMs)
        {
            timer.stop();
            this.targetOpacity = targetOpacity;

            float delta = targetOpacity - currentOpacity;
            if (durationMs > 0)
            {
                opacityStep = (delta / durationMs) * DELAY_MS;
            }
            else
            {
                opacityStep = delta;
            }
            timer.start();
        }
    }
}
