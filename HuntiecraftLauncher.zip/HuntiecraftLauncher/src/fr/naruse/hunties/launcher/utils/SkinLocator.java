package fr.naruse.hunties.launcher.utils;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class SkinLocator extends JComponent {
    private String name;
    private BufferedImage bufferedImage;
    private BufferedImage steveImage;
    private File skinsFolder;

    {
        try {
            steveImage = ImageIO.read(HuntiesPanel.class.getResourceAsStream("images/steve.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(skinsFolder == null){
            Utils.generateDir();
            skinsFolder = new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "skins");
            if(!skinsFolder.exists()){
                skinsFolder.mkdirs();
            }
        }
        if(name == null){
            BufferedImage subImage = steveImage.getSubimage(8, 8, 8, 8);
            BufferedImage postImage = steveImage.getSubimage(8*5, 8, 8, 8);
            g.drawImage(subImage, 25, 660, (int) (89*0.6), (int) (89*0.6), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            g.drawImage(postImage, 25, 660, (int) (89*0.6), (int) (89*0.6), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            return;
        }
        if(bufferedImage == null){
            BufferedImage subImage = steveImage.getSubimage(8, 8, 8, 8);
            BufferedImage postImage = steveImage.getSubimage(8*5, 8, 8, 8);
            g.drawImage(subImage, 25, 660, (int) (89*0.6), (int) (89*0.6), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            g.drawImage(postImage, 25, 660, (int) (89*0.6), (int) (89*0.6), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            return;
        }
        if(bufferedImage.getWidth() == 1024 && bufferedImage.getHeight() == 512){
            BufferedImage subImage = bufferedImage.getSubimage(128, 128, 128, 128);
            BufferedImage postImage = bufferedImage.getSubimage(128*5, 128, 128, 128);
            g.drawImage(subImage, 25, 660, (int) (89*0.6), (int) (89*0.6), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            g.drawImage(postImage, 25, 660, (int) (89*0.6), (int) (89*0.6), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        }else{
            BufferedImage subImage = bufferedImage.getSubimage(8, 8, 8, 8);
            BufferedImage postImage = bufferedImage.getSubimage(8*5, 8, 8, 8);
            g.drawImage(subImage, 25, 660, (int) (89*0.5), (int) (89*0.5), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            g.drawImage(postImage, 25, 660, (int) (89*0.5), (int) (89*0.5), Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        }
    }

    public void setName(String name) {
        this.name = name;
        new Thread(){
            @Override
            public void run() {
                super.run();
                try {
                    if(skinsFolder == null){
                        Utils.generateDir();
                        skinsFolder = new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "skins");
                        if(!skinsFolder.exists()){
                            skinsFolder.mkdirs();
                        }
                    }
                    File skinFile = new File(skinsFolder, name+".png");
                    if(skinFile.exists()){
                        bufferedImage = ImageIO.read(skinFile);
                        if(Main.INSTANCE.getHuntiesFrame() != null){
                            if(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel() != null){
                                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().repaint();
                            }
                        }
                        return;
                    }
                    Utils.downloadFile("https://huntiescraft.net/api/sc/skin/"+name, skinFile);
                    bufferedImage = ImageIO.read(skinFile);
                    if(Main.INSTANCE.getHuntiesFrame() != null){
                        if(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel() != null){
                            Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().repaint();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
