package fr.naruse.hunties.launcher.utils;

import fr.naruse.hunties.launcher.utils.log.HuntiesOutputStream;

import java.sql.*;
import java.util.UUID;

public class SqlConnection {
    private boolean isOffline = false;
    public SqlConnection() {
        isOffline = true;
    }

    private Connection connection;
    private Statement statement;
    private String urlbase, host, database, user, pass;

    public SqlConnection(String urlbase, String host, String database, String user, String pass) {
        this.urlbase = urlbase;
        this.host = host;
        this.database = database;
        this.user = user;
        this.pass = pass;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void connection(){
        if(isOffline) return;
        try {
            /*+"?autoReconnect=true&useSSL=false&useTimezone=true&serverTimezone=GMT"*/
            connection = DriverManager.getConnection(urlbase + host + "/" + database+"?autoReconnect=false&useSSL=false&useTimezone=true&serverTimezone=GMT", user, pass);
            System.out.println("[HuntiesLauncher] Connection established.");
            DatabaseMetaData dbm = connection.getMetaData();
            ResultSet tables = dbm.getTables(null, null, "access", null);
            if (!tables.next()) {
                statement = connection.createStatement();
                String access = "CREATE TABLE access ("
                        + "uuid VARCHAR(255) KEY UNIQUE,"
                        + "name VARCHAR(255),"
                        + "token VARCHAR(255),"
                        + "pass VARCHAR(255))";
                statement.executeUpdate(access);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void disconnection(){
        if(isOffline || connection == null) return;
        try {
            connection.close();
            System.out.println("[HuntiesLauncher] Disconnection complete.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean createAccount(String uuid, String name, String token, String pass) throws SQLException {
        if(isOffline) return true;
        if(hasAccount(name)){
            return this.setAccount(uuid, token, pass);
        }
        PreparedStatement q = connection.prepareStatement("INSERT INTO access(uuid,name,token,pass) VALUES (?,?,?,?)");
        q.setString(1, uuid);
        q.setString(2, name);
        q.setString(3, token);
        q.setString(4, pass);
        q.execute();
        q.close();
        return true;
    }

    public boolean setAccount(String uuid, String token, String pass) throws SQLException {
        if(isOffline) return true;
        PreparedStatement ps = connection.prepareStatement("UPDATE access SET token = ? WHERE uuid = ?");
        ps.setString(1, token);
        ps.setString(2, uuid);
        ps.execute();
        ps.close();
        System.out.println("[HuntiesLauncher] [AccessToken] Push done.");
        return setPass(uuid, pass);
    }

    public boolean setPass(String uuid, String pass){
        if(isOffline) return true;
        pass = "Nope";
        try {
            PreparedStatement ps = connection.prepareStatement("UPDATE access SET pass = ? WHERE uuid = ?");
            String cryptedPass = Crypt.hashpw(pass, Crypt.gensalt(12));
            ps.setString(1, cryptedPass);
            ps.setString(2, uuid);
            ps.execute();
            ps.close();
            System.out.println("[HuntiesLauncher] [Access] Push done.");
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean hasAccount(String name){
        if(isOffline) return true;
        try {
            PreparedStatement q = connection.prepareStatement("SELECT uuid FROM access WHERE name = ?");
            q.setString(1, name);
            ResultSet resultat = q.executeQuery();
            boolean hasAccount = resultat.next();
            q.close();
            return hasAccount;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String getUUID(String name){
        if(isOffline) return UUID.randomUUID().toString();
        try{
            PreparedStatement rs = connection.prepareStatement("SELECT uuid FROM access WHERE name = ?");
            rs.setString(1, name);
            String uuid = null;
            ResultSet q = rs.executeQuery();
            while(q.next()){
                uuid = q.getString("uuid");
            }
            return uuid;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
    }

}
