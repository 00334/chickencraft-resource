package fr.naruse.hunties.launcher.utils;

import fr.naruse.hunties.launcher.main.HuntiesPanel;

import javax.swing.*;

public class UsernameSaver {
    private HuntiesPanel huntiesPanel;
    private HuntiesOption huntiesOption;
    private String key;
    private JTextField jTextField;
    public UsernameSaver(HuntiesPanel huntiesPanel, String key, JTextField jTextField) {
        this.key = key;
        this.jTextField = jTextField;
        this.huntiesPanel = huntiesPanel;
        this.huntiesOption = huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption();
    }

    public String readUsername() {
        return this.huntiesOption.getString("username."+key);
    }

    public void saveUsername() {
        String username = jTextField.getText();
        if(!username.equalsIgnoreCase("Votre pseudonyme")){
            this.huntiesOption.setString("username."+key, username);
        }
    }
}
