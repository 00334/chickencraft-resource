package fr.naruse.hunties.launcher.utils;

public enum OperatorSystemType {

    WINDOWS,
    MAC,
    LINUX,

}
