package fr.naruse.hunties.launcher.utils.updater;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.utils.Utils;

import java.awt.*;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

public class LauncherUpdater {
    private String threadName = "[LauncherUpdater]";
    private Main main;
    private File launcherUpdaterFile;
    private File desktopFile;
    private File downloadFile;
    public LauncherUpdater(Main main) {
        this.main = main;
        this.launcherUpdaterFile = new File(main.getHuntiesConnection().DIR, "Sides/common/launcher");
        if(!launcherUpdaterFile.exists()){
            launcherUpdaterFile.mkdir();
        }
        this.desktopFile = new File(System.getProperty("user.home") + "/Desktop");
        this.downloadFile = new File(System.getProperty("user.home") + "/Downloads");
        new Thread(){
            @Override
            public void run() {
                super.run();
                System.out.println(threadName+" Looking for 'HuntiesCraft-Network.exe' or 'HuntiesCraft-Network.jar'...");
                File bootstrapFile = null;
                for(File file : desktopFile.listFiles()){
                   //System.out.println(threadName+" Checking "+file.getPath()+"\\");
                    File f = checkInFile(file);
                    if(f != null){
                        System.out.println(threadName+" File '"+f.getName()+"' found !");
                        bootstrapFile = f;
                        LauncherUpdater.this.update(bootstrapFile);
                        try {
                            LauncherUpdater.this.createShortcut();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        return;
                    }
                }
                if(bootstrapFile == null){
                    if(downloadFile.exists()){
                        for(File file : downloadFile.listFiles()){
                            //System.out.println(threadName+" Checking "+file.getPath()+"\\");
                            File f = checkInFile(file);
                            if(f != null){
                                System.out.println(threadName+" File '"+f.getName()+"' found !");
                                bootstrapFile = f;
                                LauncherUpdater.this.update(bootstrapFile);
                                try {
                                    LauncherUpdater.this.createShortcut();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                return;
                            }
                        }
                    }
                    if(bootstrapFile == null){
                        System.out.println(threadName+" Check failed !");
                    }
                }
            }
        }.start();
    }


    private File checkInFile(File file){
        if(file.listFiles() != null){
            for(File f : file.listFiles()){
                checkInFile(f);
            }
        }else{
            if(file.getName().equals("HuntiesCraft-Network.exe") || file.getName().equals("HuntiesCraft-Network.jar")){
                return file;
            }
        }
        return null;
    }

    private void update(File file) {
        try {
            File exeFile = downloadFile(main, "https://huntiescraft.net/public/launcher/servers/sides/common/files/launcher/HuntiesCraft-Network.exe", new File(launcherUpdaterFile, "HuntiesCraft-Network.exe"));
            File jarFile = downloadFile(main, "https://huntiescraft.net/public/launcher/servers/sides/common/files/launcher/HuntiesCraft-Network.jar", new File(launcherUpdaterFile, "HuntiesCraft-Network.jar"));
            if(exeFile.getName().equals(file.getName())){
                boolean areEqual = Utils.areFilesEqual(exeFile, file);
                if(!areEqual){
                    Utils.copyFile(exeFile, file);
                    System.out.println(threadName+ " Bootstrap updated.");
                }else{
                    System.out.println(threadName+" Bootstrap up to date.");
                }
            }else if(jarFile.getName().equals(file.getName())){
                boolean areEqual = Utils.areFilesEqual(jarFile, file);
                if(!areEqual){
                    Utils.copyFile(jarFile, file);
                    System.out.println(threadName+ " Bootstrap updated.");
                }else{
                    System.out.println(threadName+" Bootstrap up to date.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private File downloadFile(Main main, String host, File dest) throws IOException, NullPointerException{
        InputStream is = null;
        OutputStream os = null;
        String threadName = this.threadName+" "+dest.getName()+" -> ";
        try {
            DecimalFormat df = new java.text.DecimalFormat("0.##");
            URL url = new URL(host);
            URLConnection connection = url.openConnection();
            int fileLength = connection.getContentLength();
            System.out.println(threadName+" File length: "+df.format(fileLength*0.000001)+" Mo");
            if (fileLength == -1) {
                System.out.println(threadName+" Invalide URL or file.");
                return null;
            }
            if(dest.exists()){
                if(dest.length() == fileLength){
                    System.out.println(threadName+" "+dest.getName()+" is up to date.");
                    return dest;
                }
                dest.delete();
            }
            is = connection.getInputStream();
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            int count = 0;
            while ((length = is.read(buffer)) > 0) {
                count += length;
                System.out.println(threadName+" Status: "+df.format(count*0.000001)+" Mo /"+df.format(fileLength*0.000001));
                os.write(buffer, 0, length);
            }
            System.out.println(threadName+" Download successful for "+dest.getName()+".");
        } finally {
            if(is != null){
                is.close();
                os.close();
            }
        }
        return dest;
    }


    private void createShortcut() throws IOException {
        System.out.println(threadName + " Creating shortcut in desktop if there is not one..");
        File file = null;
        switch (Utils.osType()) {
            case WINDOWS: {
                file = downloadFile(main, "https://huntiescraft.net/app/webroot/launcher/sides/common/files/launcher/HuntiesCraft-Network.exe", new File(launcherUpdaterFile, "HuntiesCraft-Network.exe"));
                break;
            }
            case MAC: {
                file = downloadFile(main, "https://huntiescraft.net/app/webroot/launcher/sides/common/files/launcher/HuntiesCraft-Network.jar", new File(launcherUpdaterFile, "HuntiesCraft-Network.jar"));
                break;
            }
            case LINUX: {
                file = downloadFile(main, "https://huntiescraft.net/app/webroot/launcher/sides/common/files/launcher/HuntiesCraft-Network.jar", new File(launcherUpdaterFile, "HuntiesCraft-Network.jar"));
                break;
            }
        }
        if (file == null) {
            System.out.println(threadName + " Failed to create a shortcut !");
            return;
        }
        if(new File(desktopFile, file.getName()).exists()){
            return;
        }
        Utils.copyFile(file, new File(desktopFile, file.getName()));
        System.out.println(threadName + " Shortcut created.");
    }
}
