package fr.naruse.hunties.launcher.utils;

import fr.naruse.hunties.launcher.box.HcnCheckBox;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;

import javax.swing.*;

public class PasswordSaver {
    private HcnCheckBox savePass;
    private HuntiesPanel huntiesPanel;
    private HuntiesOption huntiesOption;
    private String key;
    private JPasswordField jPasswordField;
    public PasswordSaver(HuntiesPanel huntiesPanel, String key, JPasswordField jPasswordField, HcnCheckBox savePass) {
        this.huntiesPanel = huntiesPanel;
        this.huntiesOption = huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption();
        this.key = key;
        this.jPasswordField = jPasswordField;
        this.savePass = savePass;
    }

    public String readPassword() {
        String crypted = this.huntiesOption.getString("i."+key);
        if(crypted == null){
            return "";
        }
        String s = Utils.decrypt(crypted).substring(2);
        if(!s.equalsIgnoreCase("")){
            this.savePass.setSelected(true);
        }
        return s;
    }

    public void savePassword() {
        if(savePass.isSelected()){
            if(!jPasswordField.getText().equalsIgnoreCase("")){
                this.huntiesOption.setString("i."+key, Utils.encrypt(jPasswordField.getText()));
            }
        }else{
            this.huntiesOption.setString("i."+key, Utils.encrypt(""));
        }
    }

    public void saveCheckBox() {
        if(!savePass.isSelected()){
            this.huntiesOption.setString("i."+key, Utils.encrypt(""));
        }
    }
}
