package fr.naruse.hunties.launcher.utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.$Gson$Preconditions;
import com.google.gson.stream.JsonReader;
import fr.naruse.hunties.launcher.main.Main;
import fr.theshark34.openlauncherlib.JavaUtil;
import fr.theshark34.openlauncherlib.LaunchException;
import fr.theshark34.openlauncherlib.external.BeforeLaunchingEvent;
import fr.theshark34.openlauncherlib.external.ExternalLaunchProfile;
import fr.theshark34.openlauncherlib.util.LogUtil;
import fr.theshark34.openlauncherlib.util.ProcessLogManager;
import org.apache.commons.io.FileUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Utils {

    public static File generateDir(){
        File file = createInstallationGameDir();
        Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR = file;
        Main.INSTANCE.getHuntiesConnection().MODDED_DIR = new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "Sides/Modded");
        Main.INSTANCE.getHuntiesConnection().VANILLA_DIR = new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "Sides/Vanilla");
        Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR = new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "Sides/Universal");
        Main.INSTANCE.getHuntiesConnection().COMMON_DIR = new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "Sides/Common");
        if(!Main.INSTANCE.getHuntiesConnection().MODDED_DIR.exists()){
            Main.INSTANCE.getHuntiesConnection().MODDED_DIR.mkdir();
        }
        if(!Main.INSTANCE.getHuntiesConnection().VANILLA_DIR.exists()){
            Main.INSTANCE.getHuntiesConnection().VANILLA_DIR.mkdir();
        }
        if(!Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR.exists()){
            Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR.mkdir();
        }
        if(!Main.INSTANCE.getHuntiesConnection().COMMON_DIR.exists()){
            Main.INSTANCE.getHuntiesConnection().COMMON_DIR.mkdir();
        }
        return file;
    }

    private static File createInstallationGameDir() {
        String path = Main.INSTANCE.getHuntiesOption().getString("path").replace(";", ":");
        if(path.equalsIgnoreCase("default")){
            return createGameDir();
        }
        String serverName = "HuntiesCraft-Network";
        String os = System.getProperty("os.name").toLowerCase();
        File finalFile;
        if (os.contains("win")) {
            finalFile = new File(path+"\\." + serverName);
        } else {
            finalFile = os.contains("mac") ? new File(path+"/" + serverName) : new File(path + "/." + serverName);
        }
        if(!finalFile.exists()){
            finalFile.mkdir();
        }
        return finalFile;
    }

    private static File createGameDir() {
        String serverName = "HuntiesCraft-Network";
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            return new File(System.getProperty("user.home") + "\\AppData\\Roaming\\." + serverName);
        } else {
            return os.contains("mac") ? new File(System.getProperty("user.home") + "/Library/Application Support/" + serverName) : new File(System.getProperty("user.home") + "/." + serverName);
        }
    }

    public static void unzip(File zipfile, File folder){
        try{
            ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipfile.getCanonicalFile())));
            ZipEntry ze = null;
            try {
                while((ze = zis.getNextEntry()) != null){
                    File f = new File(folder.getCanonicalPath(), ze.getName());
                    if (ze.isDirectory()) {
                        f.mkdirs();
                        continue;
                    }

                    f.getParentFile().mkdirs();
                    OutputStream fos = new BufferedOutputStream(
                            new FileOutputStream(f));

                    try {
                        try {
                            final byte[] buf = new byte[8192];
                            int bytesRead;
                            while (-1 != (bytesRead = zis.read(buf)))
                                fos.write(buf, 0, bytesRead);
                        }
                        finally {
                            fos.close();
                        }
                    }
                    catch (final IOException ioe) {
                        f.delete();
                        throw ioe;
                    }
                }
            }
            finally {
                zis.close();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static int percentage(long value, long maximum) {
        return crossMult(value, maximum, 100);
    }

    public static int crossMult(long value, long maximum, int coefficient) {
        return (int)((double) value / (double) maximum * (double)coefficient);
    }

    public static File downloadFile(String host, File dest) {
        try (BufferedInputStream in = new BufferedInputStream(new URL(host).openStream());
             FileOutputStream fileOutputStream = new FileOutputStream(dest)) {
            byte dataBuffer[] = new byte[1024];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(Main.INSTANCE.getHuntiesFrame(), "Une erreur s'est produite, veuillez vérifier votre connexion !\nCela n'affectera pas le fonctionnement du launcher, mais cela reste une erreur.");
            return null;
        }
        return dest;
    }

    public static boolean checkPassword(String user, String pass){
        File dest = new File("checkerFor"+user);
        try {
            URLConnection connection = new URL("http://huntiescraft.net/api/trixauth/check/?pseudo="+user+"&password="+pass).openConnection();
            connection.addRequestProperty("Accept", "application/json");
            connection.addRequestProperty("Connection", "close");
            connection.addRequestProperty("Content-Encoding", "gzip");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
            connection.setDoOutput(true);
            DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
            outputStream.flush();
            outputStream.close();

            InputStream is = connection.getInputStream();
            try (BufferedInputStream in = new BufferedInputStream(is);
                 FileOutputStream fileOutputStream = new FileOutputStream(dest)) {
                byte dataBuffer[] = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                    fileOutputStream.write(dataBuffer, 0, bytesRead);
                }
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }

            JsonParser jsonParser = new JsonParser();
            JsonObject jsonObject = (JsonObject) jsonParser.parse(new JsonReader(new FileReader(dest)));
            boolean result = jsonObject.get("exists").getAsBoolean();
            new Thread(){
                @Override
                public void run() {
                    super.run();
                    dest.delete();
                }
            }.start();
            return result;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static File downloadShader(String host, File dest, int fileCount, int totalFileCount) throws IOException, NullPointerException{
        URL url = new URL(host);
        URLConnection connection = url.openConnection();
        int fileLength = connection.getContentLength();
        if(dest.exists()){
            if(dest.length() == fileLength){
                dest.delete();
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(1);
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Téléchargement des shaders " + fileCount + "/" + totalFileCount + " " + Utils.percentage(1, 1) + "%");
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(1);
            }
        }
        try (BufferedInputStream in = new BufferedInputStream(new URL(host).openStream());
             FileOutputStream fileOutputStream = new FileOutputStream(dest)) {
            byte dataBuffer[] = new byte[1024];
            int bytesRead;
            Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(fileLength);
            int count = 0;
            while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
                count += bytesRead;
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Téléchargement des shaders " + fileCount + "/" + totalFileCount + " " + Utils.percentage(count, fileLength) + "%");
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(count);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }

    public static File downloadResourcePack(String host, File dest, int fileCount, int totalFileCount) throws IOException, NullPointerException{
        InputStream is = null;
        OutputStream os = null;
        try {
            if(dest.exists()) dest.delete();
            URL url = new URL(host);
            URLConnection connection = url.openConnection();
            int fileLength = connection.getContentLength();
            if (fileLength == -1) {
                System.out.println("Invalide URL or file.");
                return null;
            }
            if(dest.exists()){
                if(dest.length() == fileLength){
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(1);
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Téléchargement des resources packs " + fileCount + "/" + totalFileCount + " " + Utils.percentage(1, 1) + "%");
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(1);
                    return dest;
                }else{
                    dest.delete();
                }
            }
            is = connection.getInputStream();
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            int count = 0;
            Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(fileLength);
            while ((length = is.read(buffer)) > 0) {
                count += length;
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Téléchargement des resources packs " + fileCount + "/" + totalFileCount + " " + Utils.percentage(count, fileLength) + "%");
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(count);
                os.write(buffer, 0, length);
            }
        } finally {
            if(is != null){
                is.close();
                os.close();
            }
        }
        return dest;
    }

    public static long fileSize(String host){
        try {
            URL url = new URL(host);
            URLConnection connection = url.openConnection();
            int fileLength = connection.getContentLength();
            return fileLength;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static String byteToMB(long bytes){
        DecimalFormat df = new DecimalFormat("0.##");
        return df.format(bytes*0.000001);
    }

    public static long folderSize(File directory) {
        long length = 0;
        for (File file : directory.listFiles()) {
            if (file.isFile())
                length += file.length();
            else
                length += folderSize(file);
        }
        return length;
    }

    public static String encrypt(String s){
        String crypte = " ";
        for (int i = 0; i < s.length(); i++)  {
            int c = s.charAt(i)^48;
            crypte = crypte + (char) c;
        }
        return crypte;
    }

    public static String decrypt(String s){
        String aCrypter = " ";
        for (int i = 0; i < s.length(); i++)  {
            int c = s.charAt(i)^48;
            aCrypter = aCrypter + (char) c;
        }
        return aCrypter;
    }

    public static boolean areFilesEqual(File file1, File file2) {
        if(!file1.exists() || !file2.exists()){
            return false;
        }
        return file1.length() == file2.length();
    }

    public static void copyFile(File file, File dest) {
        copyFile(file, dest, false);
    }

    public static void copyFile(File file, File dest, boolean sendLog) {
        try {
            if(sendLog){
                System.out.println("[HuntiesLauncher] Copying '"+file.getName()+"' to "+dest.getPath()+"...");
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Copie du fichier '"+file.getName()+"' vers '"+dest.getParentFile().getParentFile().getName()+"'...");
            }
            FileUtils.copyFile(file, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class Cesar {

        public static final String ALPHABET_LOWER = "abcdefghijklmnopqrstuvwxyz";
        public static final String ALPHABET_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public static String crypt(String plainText, int shiftKey) {
            String cipherText = "";
            for (int i = 0; i < plainText.length(); i++) {
                int charPosition = -1;
                char replaceVal;
                int keyVal = -1;
                char val = plainText.charAt(i);
                if(Character.isUpperCase(val)) {
                    charPosition = ALPHABET_UPPER.indexOf(val);
                    if(charPosition != -1) {
                        keyVal = (shiftKey + charPosition) % 26;
                        replaceVal = ALPHABET_UPPER.charAt(keyVal);
                    } else {
                        replaceVal = plainText.charAt(i);
                    }
                } else {
                    charPosition = ALPHABET_LOWER.indexOf(val);
                    if(charPosition != -1) {
                        keyVal = (shiftKey + charPosition) % 26;
                        replaceVal = ALPHABET_LOWER.charAt(keyVal);
                    } else {
                        replaceVal = plainText.charAt(i);
                    }
                }
                cipherText += replaceVal;
            }
            return cipherText;
        }
    }

    public static String hash(String pass) {
        MessageDigest digest = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return digest != null ? byteToHex(digest.digest(pass.getBytes(StandardCharsets.UTF_8))) : "";
    }

    public static String byteToHex(byte[] bytes) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(0xff & bytes[i]);
            if (hex.length() == 1) sb.append('0');
            sb.append(hex);
        }
        return sb.toString();
    }

    public static String getVersion() {
        String version = System.getProperty("java.version");
        return version;
    }

    public static OperatorSystemType osType(){
        String osName = System.getProperty("os.name").toLowerCase();
        if(osName.contains("windows")){
            return OperatorSystemType.WINDOWS;
        }else if(osName.contains("linux")){
            return OperatorSystemType.LINUX;
        }else {
            return OperatorSystemType.MAC;
        }
    }

    public static BufferedImage getFontImage() {
        try {
            generateDir();
            File imagesFolder = new File(Main.INSTANCE.getHuntiesConnection().COMMON_DIR, "images");
            if(imagesFolder.exists()){
                return checkFontImage(imagesFolder);
            }else{
                return ImageIO.read(Main.INSTANCE.getClass().getResourceAsStream("images/font/font_0.png"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    private static BufferedImage checkFontImage(File imagesFolder) throws IOException {
        if(imagesFolder.exists()){
            int size = imagesFolder.listFiles().length;
            if(size != 0){
                String randomUrl = "font_"+new Random().nextInt(size)+".png";
                File imageFile = new File(imagesFolder, randomUrl);
                if(imageFile.exists()){
                    return ImageIO.read(imageFile);
                }
            }
        }
        return ImageIO.read(Main.INSTANCE.getClass().getResourceAsStream("images/font/font_0.png"));
    }
}
