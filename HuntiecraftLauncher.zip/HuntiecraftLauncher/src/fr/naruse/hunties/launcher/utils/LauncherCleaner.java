package fr.naruse.hunties.launcher.utils;

import fr.naruse.hunties.launcher.main.Main;

import java.io.File;

public class LauncherCleaner {
    private Main main;
    public LauncherCleaner(Main main) {
        this.main = main;
        String files = "crashes Sides gameInfo.txt launcher.jar launcher_settings.txt rpc.txt";
        if(main.getHuntiesConnection().INSTALLATION_DIR.listFiles() != null){
            for(File file : main.getHuntiesConnection().INSTALLATION_DIR.listFiles()){
                if(!files.contains(file.getName())){
                    checkInFile(file, new File(main.getHuntiesConnection().MODDED_DIR, file.getName()));
                    file.delete();
                }
            }
        }
    }

    private void checkInFile(File file, File dest){
        if(file.listFiles() != null){
            for(File f : file.listFiles()){
                checkInFile(f, new File(dest, f.getName()));
            }
        }else{
            System.out.println("[HuntiesLauncher] Copying "+file.getName()+" to "+main.getHuntiesConnection().MODDED_DIR.getPath());
            Utils.copyFile(file, dest);
            file.delete();
        }
    }
}
