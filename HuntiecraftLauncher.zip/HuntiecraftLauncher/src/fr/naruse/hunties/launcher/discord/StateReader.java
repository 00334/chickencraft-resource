package fr.naruse.hunties.launcher.discord;

import fr.naruse.hunties.launcher.main.Main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class StateReader {
    private File file;
    private ArrayList<String> lines = new ArrayList<>();
    private HashMap<String, String> stateHashMap = new HashMap<>();
    public StateReader(){
        this.file = new File(Main.INSTANCE.getHuntiesConnection().DIR, "rpc.txt");
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        update();
    }

    public String getState(){
        update();
        String key = "State";
        if(stateHashMap.containsKey(key)){
            return stateHashMap.get(key).replace("State:", "").replace(":", " : ");
        }
        return "En jeu";
    }

    public void update(){
        new Thread() {
            @Override
            public void run() {
                super.run();
                lines = read();
                stateHashMap.clear();
                String lastLine = "";
                for(String line : lines){
                    lastLine += line;
                }
                stateHashMap.put("State", lastLine.replace("State: ", ""));
            }
        }.start();
    }

    private ArrayList<String> read(){
        try {
            Scanner s = new Scanner(file);
            ArrayList<String> lines = new ArrayList<>();
            while (s.hasNext()){
                String next = s.next();
                lines.add(next);
            }
            return lines;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


    public ArrayList<String> getLines() {
        return lines;
    }

    public boolean contains(String name) {
        if(lines == null || lines.size() == 0){
            return false;
        }
        for(String line : lines){
            if(line != null){
                line = line.replace(":", "");
                if(line.equalsIgnoreCase(name)){
                    return true;
                }
            }
        }
        return false;
    }

    public enum RPCState {

        MAIN_MENU("Sur le menu principal", "inloading"),
        IN_SOLO("Joue en solo", "inloading"),
        IN_FREEBUILD("Joue en FreeBuild", "inloading"),
        IN_FACTION("Joue en Faction", "inloading"),
        IN_LOBBY("En jeu", "inloading"),
        IN_FIGHT_WAR("Joue en FightWar", "inloading"),
        WHERE_IS_HE("Où est-il ?", "inloading")
        ;

        private String s, s1;
        RPCState(String sn, String s1) {
            this.s = sn;
            this.s1 = s1;
        }

        public String getStateMessage() {
            return s;
        }

        public String getImageLink() {
            return s1;
        }
    }
}
