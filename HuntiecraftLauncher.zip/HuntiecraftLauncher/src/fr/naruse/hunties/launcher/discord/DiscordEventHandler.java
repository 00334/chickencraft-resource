package fr.naruse.hunties.launcher.discord;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.connector.AuthenticatorInfos;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence;

import java.time.OffsetDateTime;
import java.util.concurrent.TimeUnit;

public class DiscordEventHandler {

    public static void inConnection(){
        DiscordRichPresence richPresence = new DiscordRichPresence.Builder("Connexion...")
                .setBigImage("inloading", "")
                .setDetails("Joueur: "+ AuthenticatorInfos.USERNAME)
                .setStartTimestamps(OffsetDateTime.now().toEpochSecond())
                .build();
        DiscordRPC.discordUpdatePresence(richPresence);
    }

    private static boolean inChecking = false;
    public static void inCheckingFiles(){
        if(inChecking){
            return;
        }
        inChecking = true;
        DiscordRichPresence richPresence = new DiscordRichPresence.Builder("Chargement des fichiers...")
                .setBigImage("inloading", "")
                .setDetails("Joueur: "+AuthenticatorInfos.USERNAME)
                .setStartTimestamps(OffsetDateTime.now().toEpochSecond())
                .build();
        DiscordRPC.discordUpdatePresence(richPresence);
    }

    public static void inLaunching() {
        DiscordRichPresence richPresence = new DiscordRichPresence.Builder("Lancement du jeu...")
                .setBigImage("inloading", "")
                .setDetails("Joueur: "+AuthenticatorInfos.USERNAME)
                .setStartTimestamps(OffsetDateTime.now().toEpochSecond())
                .build();
        DiscordRPC.discordUpdatePresence(richPresence);
        inGame();
    }

    public static void inGame(){
        DiscordRichPresence richPresence = new DiscordRichPresence.Builder("Joueur: "+AuthenticatorInfos.USERNAME)
                .setBigImage("inloading", "")
                .setDetails("http://huntiescraft.net")
                .setStartTimestamps(OffsetDateTime.now().toEpochSecond())
                .build();
        DiscordRPC.discordUpdatePresence(richPresence);
    }

    public static void stop(){
        DiscordRichPresence richPresence = new DiscordRichPresence.Builder("Fermeture du launcher...")
                .setBigImage("inloading", "")
                .setStartTimestamps(OffsetDateTime.now().toEpochSecond())
                .build();
        DiscordRPC.discordUpdatePresence(richPresence);
    }
}
