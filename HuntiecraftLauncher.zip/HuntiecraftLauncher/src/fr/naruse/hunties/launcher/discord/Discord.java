package fr.naruse.hunties.launcher.discord;

import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence;

public class Discord {
    private DiscordRichPresence presence;
    private DiscordConnectionHandler discordConnectionHandler;
    private StateReader stateReader;
    public Discord(DiscordRichPresence presence) {
        this.presence = presence;
        this.stateReader = new StateReader();
        this.discordConnectionHandler = new DiscordConnectionHandler();
    }

    public void setPresence(DiscordRichPresence presence) {
        this.presence = presence;
        DiscordRPC.discordUpdatePresence(presence);
    }

    public DiscordRichPresence getPresence() {
        return presence;
    }

    public DiscordConnectionHandler getDiscordConnectionHandler() {
        return discordConnectionHandler;
    }

    public StateReader getStateReader() {
        return stateReader;
    }
}
