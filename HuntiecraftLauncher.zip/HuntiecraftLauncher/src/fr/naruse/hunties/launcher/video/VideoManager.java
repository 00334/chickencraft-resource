package fr.naruse.hunties.launcher.video;

import fr.naruse.hunties.launcher.box.HcnCheckBox;
import fr.naruse.hunties.launcher.main.Main;

public class VideoManager {
    private Main pl;
    private HcnCheckBox activateSound;
    public VideoManager(Main pl) {
        this.pl = pl;
        //activateSound = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 3, 517, 20, 20);
        //activateSound.addTo(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        /*if(pl.getHuntiesOption().getString("hasSawTrailer").equals("false")){
            downloadAndPlayTrailer();
            pl.getHuntiesOption().setString("hasSawTrailer", "true");
        }else{*/
            downloadAndPlaySizeVideos(Videos.TRAILER);
        //}
    }

    public void downloadAndPlayTrailer(){
        Main.INSTANCE.getHuntiesFrame().setVisible(false);
        new Thread(){
            @Override
            public void run() {
                super.run();
                VideoDownloader videoDownloader = new VideoDownloader(Videos.TRAILER);
                videoDownloader.start();
                while (true){
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(videoDownloader.isDone()){
                        FullScreenVideoPlayer fullScreenVideoPlayer = new FullScreenVideoPlayer(Videos.TRAILER);
                        fullScreenVideoPlayer.play();
                        interrupt();
                        break;
                    }
                }
            }
        }.start();
    }

    public void downloadAndPlaySizeVideos(Videos videos){
        new Thread(){
            @Override
            public void run() {
                super.run();
                VideoDownloader videoDownloader = new VideoDownloader(videos);
                videoDownloader.start();
                while (true){
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(videoDownloader.isDone()){
                        ScreenVideoPlayer screenVideoPlayer = new ScreenVideoPlayer(videos, 470, 264, 686, 465);
                        screenVideoPlayer.play();
                        interrupt();
                        break;
                    }
                }
            }
        }.start();
    }
}
