package fr.naruse.hunties.launcher.video;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.utils.Animator;
import fr.theshark34.swinger.Swinger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Screen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;

public class FullScreenVideoPlayer extends JFrame{
    private MediaPlayer mediaPlayer;
    private Videos videos;
    public FullScreenVideoPlayer(Videos videos){
        this.videos = videos;
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setIconImage(Swinger.getResource("icon.jpg"));
        setTitle("HuntiesCraft-Network");
        setForeground(new Color(11, 135, 200, 201));
    }
    private double stopTime;
    public void play(){
        try{
            Main.INSTANCE.getHuntiesFrame().setVisible(false);
            setVisible(true);
            Animator.fadeInFrame(this, Animator.SLOW);
            this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            final JFXPanel VFXPanel = new JFXPanel();

            File video_source = new File(Main.INSTANCE.getHuntiesConnection().DIR, videos.getVideoPath());
            Media m = new Media(video_source.toURI().toString());
            this.mediaPlayer = new MediaPlayer(m);
            MediaView viewer = new MediaView(mediaPlayer);

            StackPane root = new StackPane();
            Scene scene = new Scene(root);

            javafx.geometry.Rectangle2D screen = Screen.getPrimary().getVisualBounds();
            viewer.setX((screen.getWidth() - getWidth()) / 2);
            viewer.setY((screen.getHeight() - getHeight()) / 2);

            DoubleProperty width = viewer.fitWidthProperty();
            DoubleProperty height = viewer.fitHeightProperty();
            width.bind(Bindings.selectDouble(viewer.sceneProperty(), "width"));
            height.bind(Bindings.selectDouble(viewer.sceneProperty(), "height"));
            viewer.setPreserveRatio(true);

            root.getChildren().add(viewer);
//686 466
            //1155 714
            VFXPanel.setScene(scene);
            mediaPlayer.play();
            setLayout(new BorderLayout());
            add(VFXPanel, BorderLayout.CENTER);

            stopTime = System.currentTimeMillis()+mediaPlayer.getTotalDuration().toMillis();
            new Thread() {
                @Override
                public void run() {
                    super.run();
                    while (true){
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(!isVisible() || stopTime <= System.currentTimeMillis()){
                            mediaPlayer.stop();
                            interrupt();
                            setVisible(false);
                            Main.INSTANCE.getHuntiesFrame().setVisible(true);
                            Main.INSTANCE.getVideoManager().downloadAndPlaySizeVideos(videos);
                            break;
                        }
                    }
                }
            }.start();
        }catch (Exception e){
            if(mediaPlayer != null){
                mediaPlayer.stop();
            }
            setVisible(false);
            Main.INSTANCE.getHuntiesFrame().setVisible(true);
        }
    }
}
