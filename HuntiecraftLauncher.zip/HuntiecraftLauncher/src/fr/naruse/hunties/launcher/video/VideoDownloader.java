package fr.naruse.hunties.launcher.video;

import fr.naruse.hunties.launcher.main.Main;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.colored.SColoredBar;
import fr.theshark34.swinger.util.WindowMover;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

import static fr.theshark34.swinger.Swinger.getTransparentWhite;

public class VideoDownloader extends JFrame{
    private Videos videos;
    private boolean isDone = false;

    public VideoDownloader(Videos videos){
        this.videos = videos;
    }

    public void start() {
        DownloaderPanel downloaderPanel;
        this.setTitle("HuntiesCraft-Network");
        this.setIconImage(Swinger.getResource("icon.jpg"));
        this.setSize(400, 150);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setContentPane(downloaderPanel = new DownloaderPanel());
        this.setResizable(false);
        WindowMover mover = new WindowMover(this);
        this.addMouseListener(mover);
        this.addMouseMotionListener(mover);
        setVisible(false);
        try {
            downloadFile(downloaderPanel, videos.getHost(), new File(Main.INSTANCE.getHuntiesConnection().DIR, videos.getVideoPath()));
        } catch (IOException e) {
            downloaderPanel.setInfoText("Erreur : "+e);
            e.printStackTrace();
        }

        setVisible(false);
        isDone = true;
    }

    private File downloadFile(DownloaderPanel panel, String host, File dest) throws IOException, NullPointerException{
        InputStream is = null;
        OutputStream os = null;
        try {
            URL url = new URL(host);
            URLConnection connection = url.openConnection();
            int fileLength = connection.getContentLength();
            if (fileLength == -1) {
                return null;
            }
            if(dest.exists()){
                if(dest.length() == fileLength){
                    return dest;
                }
                dest.delete();
            }
            if(!dest.getParentFile().exists()){
                dest.getParentFile().mkdirs();
            }
            setVisible(true);
            is = connection.getInputStream();
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            int count = 0;
            DecimalFormat df = new DecimalFormat("0.##");
            panel.getInfoLabel().setBounds(10, 20, 400, 40);
            while ((length = is.read(buffer)) > 0) {
                count += length;
                panel.getProgressBar().setMaximum(fileLength);
                panel.getProgressBar().setValue(count);
                panel.setInfoText("Téléchargement... ("+df.format(count*0.000001)+" Mo /"+df.format(fileLength*0.000001)+" Mo)");
                os.write(buffer, 0, length);
            }
        } finally {
            if(is != null){
                is.close();
                os.close();
            }
        }
        return dest;
    }

    public boolean isDone() {
        return this.isDone;
    }

    class DownloaderPanel extends JPanel {
        private JLabel infoLabel = new JLabel("Chargement...");
        private SColoredBar progressBar = new SColoredBar(getTransparentWhite(100), getTransparentWhite(175));
        public DownloaderPanel() {
            this.setLayout(null);
            this.infoLabel.setForeground(Color.BLACK);
            this.infoLabel.setFont(infoLabel.getFont().deriveFont(17F));
            this.infoLabel.setBounds(145, 20, 400, 40);
            this.add(infoLabel);
            this.progressBar.setVisible(true);
            this.progressBar.setBackground(Color.LIGHT_GRAY);
            this.progressBar.setForeground(new Color(194, 88, 77));
            this.progressBar.setBounds(12, 65, 400-15*2, 20);
            this.add(progressBar);
        }

        public void setInfoText(String text){
            this.infoLabel.setText(text);
        }

        public SColoredBar getProgressBar() {
            return progressBar;
        }

        public JLabel getInfoLabel() {
            return infoLabel;
        }

    }
}
