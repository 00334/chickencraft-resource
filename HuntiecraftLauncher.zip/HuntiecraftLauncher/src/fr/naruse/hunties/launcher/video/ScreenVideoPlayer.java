package fr.naruse.hunties.launcher.video;

import fr.naruse.hunties.launcher.main.Main;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Screen;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

public class ScreenVideoPlayer implements MouseListener {
    private MediaPlayer mediaPlayer;
    private Videos videos;
    private int width, height, x, y;

    public ScreenVideoPlayer(Videos videos, int width, int height, int x, int y){
        this.videos = videos;
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
    }

    private double stopTime;
    public void play(){
        try{
            final JFXPanel VFXPanel = new JFXPanel();

            File video_source = new File(Main.INSTANCE.getHuntiesConnection().DIR, videos.getVideoPath());
            Media m = new Media(video_source.toURI().toString());
            this.mediaPlayer = new MediaPlayer(m);
            MediaView viewer = new MediaView(mediaPlayer);

            StackPane root = new StackPane();
            Scene scene = new Scene(root);

            javafx.geometry.Rectangle2D screen = Screen.getPrimary().getVisualBounds();
            viewer.setX((screen.getWidth() - width) / 2);
            viewer.setY((screen.getHeight() - height) / 2);

            DoubleProperty width = viewer.fitWidthProperty();
            DoubleProperty height = viewer.fitHeightProperty();
            width.bind(Bindings.selectDouble(viewer.sceneProperty(), "width"));
            height.bind(Bindings.selectDouble(viewer.sceneProperty(), "height"));
            viewer.setPreserveRatio(true);

            root.getChildren().add(viewer);

            //686 466
            //1155 714

            VFXPanel.setScene(scene);
            VFXPanel.setBackground(new Color(255, 255, 255, 0));

            mediaPlayer.setVolume(0);
            mediaPlayer.play();

            VFXPanel.setBounds(x, y, this.width, this.height);
            VFXPanel.addMouseListener(this);

            Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().add(VFXPanel);

            stopTime = System.currentTimeMillis()+mediaPlayer.getTotalDuration().toMillis();
            new Thread() {
                @Override
                public void run() {
                    super.run();
                    while (true){
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(!Main.INSTANCE.getHuntiesFrame().isVisible()){
                            mediaPlayer.stop();
                            VFXPanel.setVisible(false);
                            interrupt();
                            break;
                        }
                        if(stopTime <= System.currentTimeMillis()){
                            mediaPlayer.stop();
                            VFXPanel.setVisible(false);
                            Main.INSTANCE.getVideoManager().downloadAndPlaySizeVideos(videos);
                            interrupt();
                            break;
                        }
                    }
                }
            }.start();
        }catch (Exception e){
            if(mediaPlayer != null){
                mediaPlayer.stop();
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(mediaPlayer.getVolume() == 0){
            mediaPlayer.setVolume(100);
        }else{
            mediaPlayer.setVolume(0);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
