package fr.naruse.hunties.launcher.video;

public enum Videos{

    TRAILER("Sides/Common/videos/Trailer_HuntiesCraft_Network_hd.mp4", "https://huntiescraft.net/public/launcher/servers/sides/common/files/videos/Trailer_HuntiesCraft_Network_hd.mp4");

    private String s, h;
    Videos(String s, String h) {
        this.s = s;
        this.h = h;
    }

    public String getVideoPath() {
        return s;
    }

    public String getHost() {
        return h;
    }
}
