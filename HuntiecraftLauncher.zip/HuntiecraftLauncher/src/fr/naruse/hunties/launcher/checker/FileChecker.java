package fr.naruse.hunties.launcher.checker;

import fr.naruse.hunties.launcher.main.Main;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class FileChecker {
    private Main pl;
    private File[] files;
    public FileChecker(Main pl, File dir){
        this.pl = pl;
        //this.files = new File(dir, "mods").listFiles();
        //startCheckingThread(dir);
    }

    private void startCheckingThread(File dir) {
        new Thread(){
            @Override
            public void run() {
                super.run();
                while (true){
                    try {
                        Thread.sleep(TimeUnit.SECONDS.toMillis(10));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    File[] currentFiles = new File(dir, "mods").listFiles();
                    if(files.length != currentFiles.length){
                        stopGame();
                        return;
                    }
                    for(int i = 0; i != files.length; i++){
                        if(files[i].compareTo(currentFiles[i]) != 0){
                            stopGame();
                            return;
                        }
                    }
                }
            }
        }.start();
    }

    private void stopGame(){
        System.out.println("[HuntiesLauncher] Fermeture forcée du jeu.");
        pl.getGameManager().getGameInfoReader().setString("forceStop", "true");
    }
}
