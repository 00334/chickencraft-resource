package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MinimizeButtonAction implements MouseListener, ActionListener {
    private HuntiesPanel huntiesPanel;
    private JButton button, buttonHover;
    public MinimizeButtonAction(HuntiesPanel huntiesPanel, JButton button, JButton buttonHover) {
        this.huntiesPanel = huntiesPanel;
        this.button = button;
        this.buttonHover = buttonHover;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        button.setVisible(false);
        buttonHover.setVisible(true);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        button.setVisible(true);
        buttonHover.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        huntiesPanel.getHuntiesFrame().setState(JFrame.ICONIFIED);
        huntiesPanel.getHuntiesFrame().getMain().getLogFrame().setState(JFrame.ICONIFIED);
    }
}
