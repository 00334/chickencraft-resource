package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.connector.ConnectorModded;
import fr.naruse.hunties.launcher.main.connector.ConnectorPremium;
import fr.naruse.hunties.launcher.main.connector.ConnectorCrack;
import fr.naruse.hunties.launcher.main.connector.Connectors;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyListeners implements KeyListener {
    private HuntiesPanel huntiesPanel;
    private Connectors connectors;
    public KeyListeners(HuntiesPanel huntiesPanel, Connectors connectors) {
        this.huntiesPanel = huntiesPanel;
        this.connectors = connectors;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == 10){
            switch (connectors){
                case HUNTIES: new ConnectorModded(huntiesPanel).connexion(UtilsInterfaceManager.getInterfaceConnexion().getHConnexionButtonAction()); break;
                case CRACK: new ConnectorCrack(huntiesPanel).connexion(UtilsInterfaceManager.getInterfaceConnexion().getPConnexionButtonAction()); break;
                case PREMIUM: new ConnectorPremium(huntiesPanel).connexion(UtilsInterfaceManager.getInterfaceConnexion().getCConnexionButtonAction()); break;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
