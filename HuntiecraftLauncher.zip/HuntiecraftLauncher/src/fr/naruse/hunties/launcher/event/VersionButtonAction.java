package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.selector.VersionSelectorFrame;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class VersionButtonAction implements MouseListener, SwingerEventListener {
    private HuntiesPanel huntiesPanel;
    public STexturedButton button, hover;
    public VersionButtonAction(HuntiesPanel huntiesPanel, STexturedButton button, STexturedButton hover) {
        this.huntiesPanel = huntiesPanel;
        this.button = button;
        this.hover = hover;
        button.setBounds(710, 315);
        hover.setBounds(button.getX(), button.getY(), button.getWidth(), button.getHeight());
        hover.setVisible(false);
        button.setVisible(false);
        huntiesPanel.add(button);
        huntiesPanel.add(hover);
        button.addEventListener(this);
        button.addMouseListener(this);
        hover.addEventListener(this);
        hover.addMouseListener(this);
    }

    @Override
    public void onEvent(SwingerEvent swingerEvent) {
        new VersionSelectorFrame(huntiesPanel);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if(UtilsInterfaceManager.State.getEnabledInterface() == Interfaces.UNIVERSAL){
            button.setVisible(false);
            hover.setVisible(true);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(UtilsInterfaceManager.State.getEnabledInterface() == Interfaces.UNIVERSAL){
            button.setVisible(true);
            hover.setVisible(false);
        }
    }

    public void setVisible(boolean b) {
        button.setVisible(b);
        hover.setVisible(b);
        if(b){
            hover.setVisible(false);
        }
    }
}
