package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class QuitButtonAction implements MouseListener, ActionListener {
    private HuntiesPanel huntiesPanel;
    private JButton quitButton, quitButtonHover;
    public QuitButtonAction(HuntiesPanel huntiesPanel, JButton quitButton, JButton quitButtonHover) {
        this.huntiesPanel = huntiesPanel;
        this.quitButton = quitButton;
        this.quitButtonHover = quitButtonHover;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        quitButton.setVisible(false);
        quitButtonHover.setVisible(true);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        quitButton.setVisible(true);
        quitButtonHover.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        UtilsInterfaceManager.getInterfaceConnexion().savePassAndName();
        huntiesPanel.getHuntiesFrame().close();
    }
}
