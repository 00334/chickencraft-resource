package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.connector.ConnectorModded;
import fr.naruse.hunties.launcher.main.connector.ConnectorPremium;
import fr.naruse.hunties.launcher.main.connector.ConnectorCrack;
import fr.naruse.hunties.launcher.main.connector.Connectors;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ConnexionButtonAction implements SwingerEventListener, MouseListener {
    private HuntiesPanel huntiesPanel;
    public STexturedButton connexionButton, connexionButtonHover;
    private Connectors connectors;
    private boolean isConnected = false;
    public ConnexionButtonAction(HuntiesPanel huntiesPanel, STexturedButton connexionButton, STexturedButton connexionButtonHover, Connectors connectors) {
        this.huntiesPanel = huntiesPanel;
        this.connexionButton = connexionButton;
        this.connexionButtonHover = connexionButtonHover;
        connexionButton.addEventListener(this);
        connexionButton.addMouseListener(this);
        connexionButtonHover.addEventListener(this);
        connexionButtonHover.addMouseListener(this);
        this.connectors = connectors;
    }

    @Override
    public void onEvent(SwingerEvent swingerEvent) {
        switch (connectors){
            case HUNTIES: new ConnectorModded(huntiesPanel).connexion(this); break;
            case CRACK: new ConnectorCrack(huntiesPanel).connexion(this); break;
            case PREMIUM: new ConnectorPremium(huntiesPanel).connexion(this); break;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if(UtilsInterfaceManager.State.getEnabledInterface() == Interfaces.CONNEXION){
            connexionButton.setVisible(false);
            connexionButtonHover.setVisible(true);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(UtilsInterfaceManager.State.getEnabledInterface() == Interfaces.CONNEXION){
            connexionButton.setVisible(true);
            connexionButtonHover.setVisible(false);
        }
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnected(boolean connected) {
        isConnected = connected;
    }
}
