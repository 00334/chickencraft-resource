package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class InscriptionButtonAction implements SwingerEventListener {
    private HuntiesPanel huntiesPanel;
    public InscriptionButtonAction(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
    }

    @Override
    public void onEvent(SwingerEvent swingerEvent) {
        if(Desktop.isDesktopSupported()){
            try {
                Desktop.getDesktop().browse(new URI(""));
            } catch (IOException e1) {
                e1.printStackTrace();
            } catch (URISyntaxException e1) {
                e1.printStackTrace();
            }
        }
    }
}
