package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.option.OptionsFrame;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;

public class OptionsButtonAction implements SwingerEventListener {
    private HuntiesPanel huntiesPanel;
    private boolean optionFrameIsOpen = false;
    private OptionsFrame optionsFrame;
    public OptionsButtonAction(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
    }

    @Override
    public void onEvent(SwingerEvent e) {
        if(optionFrameIsOpen){
            this.optionsFrame.setVisible(true);
        }else{
            optionFrameIsOpen = true;
            this.optionsFrame = new OptionsFrame(huntiesPanel);
            this.optionsFrame.setVisible(true);
        }
    }

}
