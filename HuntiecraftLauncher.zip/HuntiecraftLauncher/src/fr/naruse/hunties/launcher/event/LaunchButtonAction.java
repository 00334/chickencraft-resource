package fr.naruse.hunties.launcher.event;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.connector.AuthenticatorInfos;
import fr.naruse.hunties.launcher.main.connector.Connectors;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.main.updater.UpdaterVanilla;
import fr.naruse.hunties.launcher.main.updater.UpdaterHunties;
import fr.naruse.hunties.launcher.main.updater.UpdaterUniversal;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class LaunchButtonAction implements SwingerEventListener, MouseListener {
    private HuntiesPanel huntiesPanel;
    public STexturedButton button, hover;
    private Connectors[] connectors;
    public LaunchButtonAction(HuntiesPanel huntiesPanel, STexturedButton button, STexturedButton hover, Connectors[] connectors) {
        this.huntiesPanel = huntiesPanel;
        this.button = button;
        this.hover = hover;
        //126 691
        button.setBounds(126, 691, (int) (206*0.8), (int) (61*0.8));
        hover.setBounds(button.getX(), button.getY(), button.getWidth(), button.getHeight());
        hover.setVisible(false);
        button.setVisible(false);
        huntiesPanel.add(button);
        huntiesPanel.add(hover);
        button.addEventListener(this);
        button.addMouseListener(this);
        hover.addEventListener(this);
        hover.addMouseListener(this);
        this.connectors = connectors;
    }

    public void launch(){
        for(Connectors connectors : connectors) {
            switch (connectors) {
                case HUNTIES: {
                    huntiesPanel.getHuntiesFrame().getMain().getHuntiesConnection().update(new UpdaterHunties(Main.INSTANCE));
                    return;
                }
                case PREMIUM:
                case CRACK: {
                    huntiesPanel.getHuntiesFrame().getMain().getHuntiesConnection().update(new UpdaterUniversal(Main.INSTANCE));
                    huntiesPanel.getHuntiesFrame().getMain().getHuntiesConnection().update(new UpdaterUniversal(Main.INSTANCE));
                    return;
                }
            }
        }
    }

    @Override
    public void onEvent(SwingerEvent swingerEvent) {
        launch();
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if(UtilsInterfaceManager.State.getEnabledInterface() == null){
            button.setVisible(false);
            hover.setVisible(true);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(UtilsInterfaceManager.State.getEnabledInterface() == null){
            button.setVisible(true);
            hover.setVisible(false);
        }
    }

    public void setVisible(boolean b) {
        button.setVisible(b);
        hover.setVisible(b);
        if(b){
            hover.setVisible(false);
        }
    }
}
