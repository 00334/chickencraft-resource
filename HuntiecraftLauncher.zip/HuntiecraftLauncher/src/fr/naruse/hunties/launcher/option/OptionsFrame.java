package fr.naruse.hunties.launcher.option;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.openlauncherlib.LanguageManager;
import fr.theshark34.openlauncherlib.util.ramselector.OptionFrame;
import fr.theshark34.swinger.Swinger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class OptionsFrame extends JFrame implements ActionListener {
    private HuntiesPanel huntiesPanel;
    private JButton ok, set, reset;
    private JLabel dir;
    public OptionsFrame(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
        this.setTitle(LanguageManager.lang(new String[]{"options"}));
        this.setResizable(false);
        this.setSize(375, 160);
        this.setIconImage(Swinger.getResource("icon.jpg"));
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        JLabel chooseHardDriveText = new JLabel("Dossier d'installation:");
        chooseHardDriveText.setBounds(10, 0, 200, 100);
        chooseHardDriveText.setFont(chooseHardDriveText.getFont().deriveFont(15f));
        this.add(chooseHardDriveText);

        ArrayList<String> hdd = new ArrayList<>();
        File[] paths;
        paths = File.listRoots();
        for(File path:paths) {
            hdd.add(path.toString());
        }
        set = new JButton("modifier");
        set.setBounds(375-120-10, 40, 120, 20);
        set.addActionListener(this);
        this.add(set);
        dir = new JLabel(huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().getString("path").replace(";", ":"));
        dir.setBounds(375-200-10, 40, 80, 20);
        dir.setFont(dir.getFont().deriveFont(13f));
        dir.setBackground(new Color(195, 151, 69));
        this.add(dir);
        ok = new JButton("Ok");
        ok.addActionListener(this);
        ok.setBounds(getWidth()/2-80/2-52, 70, 100, 23);
        this.add(ok);
        reset = new JButton("Reset");
        reset.addActionListener(this);
        reset.setBounds(getWidth()/2-80/2+52, 70, 100, 23);
        this.add(reset);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == ok){
            setVisible(false);
        }
        if(e.getSource() == set){
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                if(file == null){
                    return;
                }
                String newDir = file.getAbsolutePath();
                if(JOptionPane.showConfirmDialog(null, "Êtes-vous sûr du nouveau chemin ? \n"+newDir) == 0){
                    huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().setString("path", newDir.replace(":", ";"));
                    dir.setText(newDir);
                }
            }
        }
        if(e.getSource() == reset){
            huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().setString("path", "default");
            dir.setText("default");
        }
        UtilsInterfaceManager.getInterfaceOption().getInstallationPathSelector().selectChosenRam(huntiesPanel);
    }
}
