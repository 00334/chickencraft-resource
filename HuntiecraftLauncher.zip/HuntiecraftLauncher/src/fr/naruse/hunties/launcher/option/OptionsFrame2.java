package fr.naruse.hunties.launcher.option;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.openlauncherlib.LanguageManager;
import fr.theshark34.swinger.Swinger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class OptionsFrame2 extends JFrame implements ActionListener {
    private HuntiesPanel huntiesPanel;
    private JButton validate;
    private JCheckBox logFrame;
    public OptionsFrame2(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
        this.setTitle(LanguageManager.lang(new String[]{"options"}));
        this.setResizable(false);
        this.setSize(375, 160);
        this.setIconImage(Swinger.getResource("icon.jpg"));
        this.setLocationRelativeTo(null);
        this.setLayout(null);

        logFrame = new JCheckBox("Activer la console de debug");
        logFrame.setBounds(getWidth()/2-100, 40, 500, 16);
        logFrame.setSelected(Boolean.valueOf(Main.INSTANCE.getHuntiesOption().getString("enableLogs")));
        logFrame.addActionListener(this);
        add(logFrame);

        validate = new JButton("Valider");
        validate.setBounds(getWidth()/2-50, 90, 100, 25);
        validate.addActionListener(this);
        add(validate);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == validate){
            Main.INSTANCE.getHuntiesOption().setString("enableLogs", logFrame.isSelected()+"");
            this.setVisible(false);
        }
    }
}
