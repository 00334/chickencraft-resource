package fr.naruse.hunties.launcher.game;

import fr.naruse.hunties.launcher.main.Main;

public class GameManager {
    private Main pl;
    private GameInfoReader gameInfoReader;
    public GameManager(Main pl){
        this.pl = pl;
        this.gameInfoReader = new GameInfoReader();
    }

    public GameInfoReader getGameInfoReader() {
        return gameInfoReader;
    }

    public Main getMain() {
        return pl;
    }
}
