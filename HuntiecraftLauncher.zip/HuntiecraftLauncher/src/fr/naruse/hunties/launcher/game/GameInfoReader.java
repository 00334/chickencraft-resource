package fr.naruse.hunties.launcher.game;

import fr.naruse.hunties.launcher.main.Main;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class GameInfoReader {
    private File file;
    private ArrayList<String> lines = new ArrayList<>();
    private HashMap<String, String> stateHashMap = new HashMap<>();
    public GameInfoReader(){
        this.file = new File(Main.INSTANCE.getHuntiesConnection().DIR, "gameInfo.txt");
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        setString("music.name", "null");
        setString("music.isPaused", "false");
        setString("music.url", "null");
        setString("music.volume", "100");
        setString("forceStop", "false");
        setString("music.stats.duration", "null");
        setString("music.stats.position", "null");
        setString("music.stats.name", "null");
    }

    public String getString(String key){
        BufferedReader br = null;
        ArrayList<String> lines = new ArrayList<>();
        try {
            br = new BufferedReader(new FileReader(this.file));
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
            for(String s : lines){
                if(s.contains(":")){
                    if(s.split(":")[0].equals(key)){
                        return s.split(":")[1].substring(1);
                    }
                }
            }
        } catch (IOException var14) {
            System.err.println("[HuntiesLauncher] WARNING: Can't read options : " + var14);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException var13) {
                    System.err.println("[HuntiesLauncher] WARNING: Can't close the file : " + var13);
                }
            }

        }
        return null;
    }

    private ArrayList<String> read(){
        BufferedReader br = null;
        ArrayList<String> lines = new ArrayList<>();
        try {
            br = new BufferedReader(new FileReader(this.file));
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
            return lines;
        } catch (IOException var14) {
            System.err.println("[HuntiesLauncher] WARNING: Can't read options : " + var14);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException var13) {
                    System.err.println("[HuntiesLauncher] WARNING: Can't close the file : " + var13);
                }
            }

        }
        return null;
    }


    public void setString(String key, String value){
        ArrayList<String> list = new ArrayList<>();
        for(String line : read()){
            if(line.contains(":")){
                if(!line.split(":")[0].equalsIgnoreCase(key)){
                    list.add(line);
                }
            }
        }
        list.add(key+": "+value);
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(this.file));
            for(String line : list){
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException var11) {
            System.err.println("[HuntiesLauncher] WARNING: Can't save username : " + var11);
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException var10) {
                    System.err.println("[HuntiesLauncher] WARNING: Can't close the file : " + var10);
                }
            }
        }
    }
}
