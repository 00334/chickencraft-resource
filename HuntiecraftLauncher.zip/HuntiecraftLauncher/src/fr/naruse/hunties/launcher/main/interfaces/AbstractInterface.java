package fr.naruse.hunties.launcher.main.interfaces;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.theshark34.swinger.Swinger;

import java.awt.*;
import java.awt.image.BufferedImage;


public abstract class AbstractInterface implements IInterface {
    private HuntiesPanel huntiesPanel;
    private Interfaces interfaces;
    private BufferedImage interfaceImage, buttonImage;
    private boolean isEnabled = false;
    public AbstractInterface(HuntiesPanel huntiesPanel, Interfaces interfaces) {
        this.huntiesPanel = huntiesPanel;
        this.interfaces = interfaces;
        this.interfaceImage = interfaces.getInterfaceImage();
        this.buttonImage = interfaces.getButtonImage();
    }

    @Override
    public void paintComponent(Graphics g) {
        Swinger.drawFullsizedImage(g, huntiesPanel, interfaceImage);
    }

    protected BufferedImage getButtonImage() {
        return buttonImage;
    }

    protected BufferedImage getInterfaceImage() {
        return interfaceImage;
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }

    public HuntiesPanel getHuntiesPanel() {
        return huntiesPanel;
    }
}
