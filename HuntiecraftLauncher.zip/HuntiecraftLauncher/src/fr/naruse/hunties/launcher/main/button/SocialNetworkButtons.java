package fr.naruse.hunties.launcher.main.button;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.textured.STexturedButton;

public class SocialNetworkButtons {
    private STexturedButton siteButton = new STexturedButton(Swinger.getResource("button/sites.png"));
    private STexturedButton siteHoverButton = new STexturedButton(Swinger.getResource("button/siteHover.png"));
    private STexturedButton twitterButton = new STexturedButton(Swinger.getResource("button/twitter.png"));
    private STexturedButton twitterHoverButton = new STexturedButton(Swinger.getResource("button/twittersHover.png"));
    private STexturedButton youtubeButton = new STexturedButton(Swinger.getResource("button/youtube.png"));
    private STexturedButton youtubeHoverButton = new STexturedButton(Swinger.getResource("button/youtubeHover.png"));
    public SocialNetworkButtons(HuntiesPanel huntiesPanel) {
        int x = (31+52);
        new Thread(){
            @Override
            public void run() {
                super.run();
                new SocialNetworkButton(huntiesPanel, siteButton, siteHoverButton, "https://huntiescraft.net/shop", 28, 750-125-35*3-75*2);
                new SocialNetworkButton(huntiesPanel, twitterButton, twitterHoverButton, "https://twitter.com/HuntiesCraft", 28, 750-125-35*2-75);
                new SocialNetworkButton(huntiesPanel, youtubeButton, youtubeHoverButton, "https://www.youtube.com/channel/UCZaZQp4BLpR8FEV4RZpemFQ", 28, 750-125-35);
            }
        }.start();
    }
}
