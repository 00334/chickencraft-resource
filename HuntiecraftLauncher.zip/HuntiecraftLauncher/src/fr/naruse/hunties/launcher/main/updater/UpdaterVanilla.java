package fr.naruse.hunties.launcher.main.updater;

import fr.naruse.hunties.launcher.checker.FileChecker;
import fr.naruse.hunties.launcher.discord.DiscordEventHandler;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.connector.AuthenticatorInfos;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.utils.Utils;
import fr.theshark34.openlauncherlib.external.ExternalLaunchProfile;
import fr.theshark34.openlauncherlib.external.ExternalLauncher;
import fr.theshark34.openlauncherlib.minecraft.*;
import fr.theshark34.openlauncherlib.util.ProcessLogManager;
import fr.theshark34.supdate.BarAPI;
import fr.theshark34.supdate.SUpdate;
import fr.theshark34.supdate.application.integrated.FileDeleter;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class UpdaterVanilla extends AbstractUpdater {
    private String uuid;
    private String clientToken;
    private File DIR;
    public UpdaterVanilla(Main main) {
        super(main);
        this.DIR = main.getHuntiesConnection().VANILLA_DIR;
    }

    @Override
    public void update() {
        JOptionPane.showMessageDialog(Main.INSTANCE.getHuntiesFrame(), "Fonctionnalité indisponible pour le moment.");
        /*
        generateUUID(AuthenticatorInfos.HUNTIES_USERNAME, false);
        String host = "https://huntiescraft.net/app/webroot/launcher/sides/vanilla/";
        SUpdate su = new SUpdate(host, DIR);
        su.getServerRequester().setRewriteEnabled(true);
        su.addApplication(new FileDeleter());
        updateThread = new Thread(){
            @Override
            public void run() {
                super.run();
                try{
                    su.start();
                }catch (Exception e){
                    e.printStackTrace();
                    main.getHuntiesFrame().setVisible(false);
                    JOptionPane.showMessageDialog(main.getHuntiesFrame().getHuntiesPanel(), "Erreur, Impossible de mettre à jour le jeu : "+e.getLocalizedMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                    return;
                }
                shaderThread = new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        Main.INSTANCE.getHuntiesConnection().getUpdaterCommon().informationThread.interrupt();
                        List<String> links = UtilsInterfaceManager.getInterfaceDownload().getShadersBox().getDownloadLinks();
                        int size = links.size();
                        int count = 1;
                        for(String link : links){
                            try {
                                String name = UtilsInterfaceManager.getInterfaceDownload().getShadersBox().getShaderName(link);
                                Utils.downloadShader(link, new File(new File(DIR, "shaderpacks"), name), count, size);
                                System.out.println("[HuntiesLauncer] Download successful for "+name+".");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            count++;
                        }
                        copyShaders(Interfaces.VANILLA);
                        ressourcePackThread.start();
                        this.interrupt();
                    }
                };
                shaderThread.start();
                ressourcePackThread = new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        List<String> links = UtilsInterfaceManager.getInterfaceDownload().getResourcesPacksBox().getDownloadLinks();
                        int size = links.size();
                        int count = 1;
                        for(String link : links){
                            try {
                                String name = UtilsInterfaceManager.getInterfaceDownload().getResourcesPacksBox().getShaderName(link);
                                Utils.downloadResourcePack(link, new File(new File(DIR, "resourcepacks"), name), count, size);
                                System.out.println("[HuntiesLauncer] Download successful for "+name+".");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            count++;
                        }
                        copyResourcePacks(Interfaces.VANILLA);
                        downloadAssets("https://huntiescraft.net/app/webroot/launcher/sides/common/files/zipFiles/assetsZip.zip", new File(DIR, "zipFiles/assetsZip.zip"));
                        unzipAssets(DIR);
                        launchGame();
                        this.interrupt();
                    }
                };
            }
        };
        updateThread.start();*/
    }

    @Override
    public void launchGame() {
        /*
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Lancement du jeu...");
        try {
            main.getHuntiesConnection().VERSION = new GameVersion("1.12.2", GameType.V1_8_HIGHER);
            main.getHuntiesConnection().INFOS = new GameInfos("HuntiesCraft-Network", DIR, main.getHuntiesConnection().VERSION, new GameTweak[] {GameTweak.FORGE});


            String tokenAndPassword = clientToken+"-!token-pass!-"+Utils.Cesar.crypt(AuthenticatorInfos.HUNTIES_PASSWORD, 5);
            AuthInfos authInfos = new AuthInfos(AuthenticatorInfos.HUNTIES_USERNAME, tokenAndPassword, uuid);
            boolean ac = true;
            while (true){
                try{
                    ac = main.getSqlConnection().createAccount(uuid, Get.getSession.getUsername(), tokenAndPassword, "null");
                    if(ac){
                        break;
                    }
                }catch (Exception e){
                    e.printStackTrace();
                    generateUUID(Get.getSession.getUsername(), true);
                }
            }
            if (!ac){
                main.getHuntiesFrame().setVisible(false);
                JOptionPane.showMessageDialog(main.getHuntiesFrame().getHuntiesPanel(), "Erreur : Impossible de communiquer aux serveurs", "Erreur", JOptionPane.ERROR_MESSAGE);
                System.exit(1);
                return;
            }
            ExternalLaunchProfile profile = MinecraftLauncher.createExternalProfile(main.getHuntiesConnection().INFOS, GameFolder.BASIC, authInfos);
            int xmx = Integer.valueOf(main.getHuntiesOption().getString("memory"));
            profile.getVmArgs().add("-Xmx"+xmx+"M");
            for(int i = 0; i != profile.getVmArgs().size(); i++){
                String arg = profile.getVmArgs().get(i);
                if(arg.equalsIgnoreCase("XX:+CMSIncrementalMode")){
                    profile.getVmArgs().remove(arg);
                    System.out.println("[HuntiesLauncher] Removing CMSIncrementalMode argument.");
                }
                System.out.println("[HuntiesLauncher] Argument "+(i+1)+"; "+arg);
            }

            DiscordEventHandler.inLaunching();
            ExternalLauncher launcher = new ExternalLauncher(profile);
            Process p = launcher.launch();
            ProcessLogManager manager = new ProcessLogManager(p.getInputStream(), new File(DIR, "logs.txt"));
            manager.start();
            Thread.sleep(5000L);
            main.getHuntiesFrame().setVisible(false);
            main.getSqlConnection().createAccount(uuid, Get.getSession.getUsername(), clientToken, AuthenticatorInfos.HUNTIES_PASSWORD);
            p.waitFor();
            DiscordEventHandler.stop();
            Thread.sleep(5000L);
            System.exit(0);
            main.getSqlConnection().disconnection();
        } catch (Exception var5) {
            var5.printStackTrace();
        }
         */
    }

    public void generateUUID(String username, boolean forceGenerate){
        if(forceGenerate){
            this.uuid = UUID.randomUUID().toString();
            main.getHuntiesOption().setString("uuid", uuid);
        }else{
            if(main.getHuntiesOption().getString("uuid") != null){
                this.uuid = main.getHuntiesOption().getString("uuid");
                if(main.getSqlConnection().hasAccount(username)){
                    this.uuid = main.getSqlConnection().getUUID(username);
                    main.getHuntiesOption().setString("uuid", uuid);
                }
            }else{
                if(main.getSqlConnection().hasAccount(username)){
                    this.uuid = main.getSqlConnection().getUUID(username);
                    main.getHuntiesOption().setString("uuid", uuid);
                }else{
                    this.uuid = UUID.randomUUID().toString();
                    main.getHuntiesOption().setString("uuid", uuid);
                }
            }
        }
        this.clientToken = UUID.randomUUID().toString().replace("-", "");
    }

    @Override
    protected void unzipAssets(File folder) {
        main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(100);
        main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(100);
        File assetsFolder = new File(folder, "assets");
        if(assetsFolder.exists()){
            long length = Utils.folderSize(assetsFolder);
            if(length != 258503728){
                assetsFolder.delete();
            }else{
                main.getHuntiesFrame().getHuntiesPanel().setInfoText("Lancement du jeu...");
                return;
            }
        }
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Décompression des assets...");
        Utils.unzip(new File(folder, "zipFiles/assetsZip.zip"), assetsFolder);
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Lancement du jeu...");
    }
}
