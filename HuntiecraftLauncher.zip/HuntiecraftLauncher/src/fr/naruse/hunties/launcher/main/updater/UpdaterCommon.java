package fr.naruse.hunties.launcher.main.updater;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.printer.Printer;
import fr.naruse.hunties.launcher.utils.Utils;
import fr.theshark34.supdate.BarAPI;
import fr.theshark34.supdate.SUpdate;
import fr.theshark34.supdate.application.integrated.FileDeleter;

import javax.swing.*;
import java.io.File;

public class UpdaterCommon extends AbstractUpdater {
    private File DIR;
    private AbstractUpdater nextUpdater;
    public Thread informationThread;
    public UpdaterCommon(Main main, AbstractUpdater abstractUpdater) {
        super(main);
        DIR = Main.INSTANCE.getHuntiesConnection().COMMON_DIR;
        nextUpdater = abstractUpdater;
    }

    @Override
    public void update() {
        copyLauncher();
        String host = "https://huntiescraft.net/public/launcher/servers/sides/common/";
        SUpdate su = new SUpdate(host, DIR);
        su.getServerRequester().setRewriteEnabled(true);
        su.addApplication(new FileDeleter());
        informationThread = new Thread() {
            private long val;
            private long max;
            private long percentage = 0;
            @Override
            public void run() {
                while(!this.isInterrupted()) {
                    if(BarAPI.getNumberOfTotalDownloadedBytes() == 0 || percentage == 99) {
                        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Vérification des fichiers...");
                        continue;
                    }
                    val = BarAPI.getNumberOfTotalDownloadedBytes();
                    max = BarAPI.getNumberOfTotalBytesToDownload();
                    percentage = Utils.percentage(val, max);
                    main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum((int) (max/1024));
                    main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue((int) (val/1024));
                    String mBDownloaded =  Utils.byteToMB(BarAPI.getNumberOfTotalDownloadedBytes())+" Mo / "+Utils.byteToMB(BarAPI.getNumberOfTotalBytesToDownload())+" Mo";
                    main.getHuntiesFrame().getHuntiesPanel().setInfoText("Téléchargement... | "+mBDownloaded);
                    if(isInterrupted()){
                        break;
                    }
                }
            }
        };
        informationThread.start();
        updateThread = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    //su.start();
                    main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(100);
                    main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(100);
                    main.getHuntiesFrame().getHuntiesPanel().setInfoText("Vérification des fichiers...");
                    Printer.MODDED.print(DIR, Main.INSTANCE.getHuntiesConnection().MODDED_DIR);
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.14.4"));
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.13.2"));
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.12.2"));
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.11.2"));
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.10.2"));
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.9.4"));
                    Printer.UNIVERSAL.print(DIR, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.8.9"));
                    Utils.copyFile(new File(Main.INSTANCE.getHuntiesConnection().COMMON_DIR, "launcher.jar"), new File(Main.INSTANCE.getHuntiesConnection().INSTALLATION_DIR, "launcher.jar"));
                    launchGame();
                } catch (Exception e) {
                    e.printStackTrace();
                    main.getHuntiesFrame().setVisible(false);
                    JOptionPane.showMessageDialog(main.getHuntiesFrame().getHuntiesPanel(), "Erreur, Impossible de mettre à jour le jeu : " + e.getLocalizedMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                    return;
                }
            }
        };
        updateThread.start();
    }

    private void copyLauncher() {
        File launcherFile = new File(main.getHuntiesConnection().DIR, "launcher.jar");
        if(!launcherFile.exists()){
            return;
        }
        File dest = new File(main.getHuntiesConnection().DIR, "Sides/Common/launcher.jar");
        if(dest.exists()){
            if(launcherFile.length() != dest.length()){
                dest.delete();
            }else{
                return;
            }
        }
        Utils.copyFile(launcherFile, dest);
    }

    @Override
    public void launchGame() {
        System.out.println("[HuntiesLauncher] Starting updater : "+nextUpdater.getClass().getName());
        nextUpdater.update();
    }

}
