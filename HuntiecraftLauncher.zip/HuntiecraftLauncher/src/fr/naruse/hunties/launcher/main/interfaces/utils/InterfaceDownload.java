package fr.naruse.hunties.launcher.main.interfaces.utils;

import fr.naruse.hunties.launcher.box.ResourcesPacksBox;
import fr.naruse.hunties.launcher.box.ShadersBox;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.AbstractInterface;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;

import java.awt.*;

public class InterfaceDownload extends AbstractInterface {
    private ShadersBox shadersBox;
    private ResourcesPacksBox resourcesPacksBox;
    public InterfaceDownload(HuntiesPanel huntiesPanel) {
        super(huntiesPanel, Interfaces.DOWNLOAD);
        this.shadersBox = new ShadersBox(huntiesPanel);
        this.resourcesPacksBox = new ResourcesPacksBox(huntiesPanel);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if(enabled){
            shadersBox.setVisible(true);
            resourcesPacksBox.setVisible(true);
        }else{
            shadersBox.setVisible(false);
            resourcesPacksBox.setVisible(false);
        }
    }

    public ShadersBox getShadersBox() {
        return shadersBox;
    }

    public ResourcesPacksBox getResourcesPacksBox() {
        return resourcesPacksBox;
    }
}
