package fr.naruse.hunties.launcher.main.updater;

import fr.naruse.hunties.launcher.discord.DiscordEventHandler;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.connector.AuthenticatorInfos;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.main.printer.Printer;
import fr.naruse.hunties.launcher.utils.Utils;
import fr.naruse.hunties.launcher.utils.log.LogFrame;
import fr.theshark34.openlauncherlib.external.ExternalLaunchProfile;
import fr.theshark34.openlauncherlib.external.ExternalLauncher;
import fr.theshark34.openlauncherlib.minecraft.*;
import fr.theshark34.openlauncherlib.util.ProcessLogManager;
import fr.theshark34.supdate.SUpdate;
import fr.theshark34.supdate.application.integrated.FileDeleter;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class UpdaterHunties extends AbstractUpdater {
    private String uuid;
    private String clientToken;
    private File DIR;
    public UpdaterHunties(Main main) {
        super(main);
        this.DIR = main.getHuntiesConnection().MODDED_DIR;
    }

    @Override
    public void update() {
        String host = "https://huntiescraft.net/public/launcher/servers/sides/modded/";
        SUpdate su = new SUpdate(host, DIR);
        su.getServerRequester().setRewriteEnabled(true);
        su.addApplication(new FileDeleter());
        updateThread = new Thread(){
            @Override
            public void run() {
                super.run();
                try{
                   // su.start();
                }catch (Exception e){
                    e.printStackTrace();
                    main.getHuntiesFrame().setVisible(false);
                    JOptionPane.showMessageDialog(main.getHuntiesFrame().getHuntiesPanel(), "Erreur, Impossible de mettre à jour le jeu : "+e.getLocalizedMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                    return;
                }
                shaderThread = new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        Main.INSTANCE.getHuntiesConnection().getUpdaterCommon().informationThread.interrupt();
                        List<String> links = UtilsInterfaceManager.getInterfaceDownload().getShadersBox().getDownloadLinks();
                        int size = links.size();
                        int count = 1;
                        for(String link : links){
                            try {
                                String name = UtilsInterfaceManager.getInterfaceDownload().getShadersBox().getShaderName(link);
                                Utils.downloadShader(link, new File(new File(DIR, "shaderpacks"), name), count, size);
                                System.out.println("[HuntiesLauncer] Download successful for "+name+".");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            count++;
                        }
                        copyShaders(Interfaces.MODDED);
                        ressourcePackThread.start();
                        this.interrupt();
                    }
                };
                shaderThread.start();
                ressourcePackThread = new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        /*List<String> links = UtilsInterfaceManager.getInterfaceDownload().getResourcesPacksBox().getDownloadLinks();
                        int size = links.size();
                        int count = 1;
                        for(String link : links){
                            try {
                                String name = UtilsInterfaceManager.getInterfaceDownload().getResourcesPacksBox().getShaderName(link);
                                Utils.downloadResourcePack(link, new File(new File(DIR, "resourcepacks"), name), count, size);
                                System.out.println("[HuntiesLauncer] Download successful for "+name+".");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            count++;
                        }*/
                        copyResourcePacks(Interfaces.MODDED);
                        Printer.MODDED.print(DIR, Main.INSTANCE.getHuntiesConnection().MODDED_DIR);
                        try {
                            sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        do{
                            downloadAssets("https://huntiescraft.net/public/launcher/servers/sides/common/files/zipFiles/assetsZip.zip", new File(DIR, "zipFiles/assetsZip.zip"));
                            try {
                                sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }while (!new File(DIR, "zipFiles/assetsZip.zip").exists());
                        unzipAssets(DIR);
                        Utils.downloadFile("https://huntiescraft.net/public/launcher/langs/en_gb.lang", new File(DIR, "assets/objects/84/847db7b482553352123614e0aeecbccf1c5e72b5"));
                        Utils.downloadFile("https://huntiescraft.net/public/launcher/langs/fr_fr.lang", new File(DIR, "assets/objects/2b/2b43aa57b09d03f1b0554518dcd4f723dd17421f"));
                        launchGame();
                        this.interrupt();
                    }
                };
            }
        };
        updateThread.start();
    }

    @Override
    public void launchGame() {
        main.getSqlConnection().connection();
        try{
            generateUUID(AuthenticatorInfos.HUNTIES_USERNAME, false);
        }catch (Exception e){
            JOptionPane.showMessageDialog(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel(), "Une erreur s'est produite ! Vérifiez votre connexion.");
            generateUUID(AuthenticatorInfos.HUNTIES_USERNAME, false);
        }
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Lancement du jeu...");
        try {
            main.getHuntiesConnection().VERSION = new GameVersion("1.12", GameType.V1_8_HIGHER);
            main.getHuntiesConnection().INFOS = new GameInfos("HuntiesCraft-Network", main.getHuntiesConnection().MODDED_DIR, main.getHuntiesConnection().VERSION, new GameTweak[] {});

            String tokenAndPassword = clientToken+"-!token-pass!-"+Utils.Cesar.crypt(AuthenticatorInfos.HUNTIES_PASSWORD, 5);
            AuthInfos authInfos = new AuthInfos(AuthenticatorInfos.HUNTIES_USERNAME, tokenAndPassword, uuid);
            boolean ac;
            while (true){
                try{
                    ac = main.getSqlConnection().createAccount(uuid, AuthenticatorInfos.HUNTIES_USERNAME, tokenAndPassword, "null");
                    if(ac){
                        break;
                    }
                }catch (Exception e){
                    e.printStackTrace();
                    generateUUID(AuthenticatorInfos.HUNTIES_USERNAME, true);
                }
            }
            if (!ac){
                main.getHuntiesFrame().setVisible(false);
                JOptionPane.showMessageDialog(main.getHuntiesFrame().getHuntiesPanel(), "Erreur : Impossible de communiquer aux serveurs", "Erreur", JOptionPane.ERROR_MESSAGE);
                System.exit(1);
                return;
            }
            ExternalLaunchProfile profile = MinecraftLauncher.createExternalProfile(main.getHuntiesConnection().INFOS, GameFolder.BASIC, authInfos);
            int xmx = Integer.valueOf(main.getHuntiesOption().getString("memory"));
            profile.getVmArgs().add("-Xmx"+xmx+"M");

            DiscordEventHandler.inLaunching();
            ExternalLauncher launcher = new ExternalLauncher(profile);
            Process p = launcher.launch();
            ProcessLogManager manager = new ProcessLogManager(p.getInputStream(), new File(DIR, "logs.txt"));
            manager.start();
            Thread.sleep(5000l);
            main.getHuntiesFrame().setVisible(false);
            try{
                main.getSqlConnection().createAccount(uuid, AuthenticatorInfos.HUNTIES_USERNAME, clientToken, AuthenticatorInfos.HUNTIES_PASSWORD);
            }catch (Exception e){
                main.getSqlConnection().createAccount(uuid, AuthenticatorInfos.HUNTIES_USERNAME, clientToken, AuthenticatorInfos.HUNTIES_PASSWORD);
                main.getSqlConnection().createAccount(uuid, AuthenticatorInfos.HUNTIES_USERNAME, clientToken, AuthenticatorInfos.HUNTIES_PASSWORD);
                e.printStackTrace();
            }
            main.getSqlConnection().disconnection();
            threadCloseLogs();
            p.waitFor();
            DiscordEventHandler.stop();
            Thread.sleep(5000l);
            if(Boolean.getBoolean(Main.INSTANCE.getHuntiesOption().getString("enableLogs"))){
                LogFrame.setCloseOperation();
            }
            System.exit(0);
        } catch (Exception var5) {
            var5.printStackTrace();
        }
    }

    private void threadCloseLogs() {
        if(!Boolean.getBoolean(Main.INSTANCE.getHuntiesOption().getString("enableLogs"))){
            return;
        }
        new Thread(){
            @Override
            public void run() {
                super.run();
                try {
                    sleep(1000*60);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    public void generateUUID(String username, boolean forceGenerate){
        if(forceGenerate){
            this.uuid = UUID.randomUUID().toString();
            main.getHuntiesOption().setString("uuid", uuid);
        }else{
            if(main.getHuntiesOption().getString("uuid") != null){
                this.uuid = main.getHuntiesOption().getString("uuid");
                if(main.getSqlConnection().hasAccount(username)){
                    this.uuid = main.getSqlConnection().getUUID(username);
                    main.getHuntiesOption().setString("uuid", uuid);
                }
            }else{
                if(main.getSqlConnection().hasAccount(username)){
                    this.uuid = main.getSqlConnection().getUUID(username);
                    main.getHuntiesOption().setString("uuid", uuid);
                }else{
                    this.uuid = UUID.randomUUID().toString();
                    main.getHuntiesOption().setString("uuid", uuid);
                }
            }
        }
        this.clientToken = UUID.randomUUID().toString().replace("-", "");
    }

    @Override
    protected void unzipAssets(File folder) {
        main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(100);
        main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(100);
        File assetsFolder = new File(folder, "assets");
        if(assetsFolder.exists()){
            long length = Utils.folderSize(assetsFolder);
                    //   226268645
            if(length <= 226000000 || length >= 227220000){
                assetsFolder.delete();
            }else{
                return;
            }
        }
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Décompression des assets...");
        Utils.unzip(new File(folder, "zipFiles/assetsZip.zip"), assetsFolder.getParentFile());
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Lancement du jeu...");
    }
}
