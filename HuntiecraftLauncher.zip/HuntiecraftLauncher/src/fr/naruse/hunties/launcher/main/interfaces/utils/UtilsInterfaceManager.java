package fr.naruse.hunties.launcher.main.interfaces.utils;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.AbstractInterface;
import fr.naruse.hunties.launcher.main.interfaces.IInterface;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.game.GameInterfaceManager;
import fr.naruse.hunties.launcher.utils.button.HButton;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class UtilsInterfaceManager implements IInterface, MouseListener, ActionListener {

    private InterfaceDownload interfaceDownload;
    private InterfaceOption interfaceOption;
    private InterfaceConnexion interfaceConnexion;

    private AbstractInterface currentInterface;

    private HuntiesPanel huntiesPanel;
    private static UtilsInterfaceManager INTERFACE_MANAGER;

    private JButton downloadButton = new JButton(new ImageIcon(Interfaces.DOWNLOAD.getButtonImage()));
    private JButton optionButton = new JButton(new ImageIcon(Interfaces.OPTION.getButtonImage()));
    private JButton connexionButton = new JButton(new ImageIcon(Interfaces.CONNEXION.getButtonImage()));
    private JButton downloadHover = new JButton(new ImageIcon(Interfaces.DOWNLOAD.getHoverImage()));
    private JButton optionHover = new JButton(new ImageIcon(Interfaces.OPTION.getHoverImage()));
    private JButton connexionHover = new JButton(new ImageIcon(Interfaces.CONNEXION.getHoverImage()));

    private JLabel pseudo = new JLabel();

    public UtilsInterfaceManager(HuntiesPanel panel) {
        INTERFACE_MANAGER = this;
        this.huntiesPanel = panel;
        this.interfaceDownload = new InterfaceDownload(huntiesPanel);
        this.interfaceOption = new InterfaceOption(huntiesPanel);
        this.interfaceConnexion = new InterfaceConnexion(huntiesPanel);

        downloadButton.setBounds(34, 750-125-35*4-75*3, Interfaces.DOWNLOAD.getButtonImage().getWidth(), Interfaces.DOWNLOAD.getButtonImage().getHeight());
        optionButton.setBounds(34, 750-125-35*5-75*4, Interfaces.OPTION.getButtonImage().getWidth(), Interfaces.OPTION.getButtonImage().getHeight());
        connexionButton.setBounds(34, 34, Interfaces.CONNEXION.getButtonImage().getWidth(), Interfaces.CONNEXION.getButtonImage().getHeight());
        huntiesPanel.add(downloadButton);
        huntiesPanel.add(optionButton);
        huntiesPanel.add(connexionButton);
        downloadButton.addActionListener(this);
        optionButton.addActionListener(this);
        connexionButton.addActionListener(this);
        downloadButton.addMouseListener(this);
        optionButton.addMouseListener(this);
        connexionButton.addMouseListener(this);
        downloadButton.setBorder(BorderFactory.createEmptyBorder());
        downloadButton.setContentAreaFilled(false);
        downloadButton.setBorderPainted(false);
        optionButton.setBorder(BorderFactory.createEmptyBorder());
        optionButton.setContentAreaFilled(false);
        optionButton.setBorderPainted(false);
        connexionButton.setBorder(BorderFactory.createEmptyBorder());
        connexionButton.setContentAreaFilled(false);
        connexionButton.setBorderPainted(false);
        downloadHover.setBorder(BorderFactory.createEmptyBorder());
        downloadHover.setContentAreaFilled(false);
        downloadHover.setBorderPainted(false);
        optionHover.setBorder(BorderFactory.createEmptyBorder());
        optionHover.setContentAreaFilled(false);
        optionHover.setBorderPainted(false);
        connexionHover.setBorder(BorderFactory.createEmptyBorder());
        connexionHover.setContentAreaFilled(false);
        connexionHover.setBorderPainted(false);

        downloadHover.setBounds(34, downloadButton.getY(), Interfaces.DOWNLOAD.getButtonImage().getWidth(), Interfaces.DOWNLOAD.getButtonImage().getHeight());
        optionHover.setBounds(34, optionButton.getY(), Interfaces.OPTION.getButtonImage().getWidth(), Interfaces.OPTION.getButtonImage().getHeight());
        connexionHover.setBounds(34, connexionButton.getY(), Interfaces.CONNEXION.getButtonImage().getWidth(), Interfaces.CONNEXION.getButtonImage().getHeight());
        downloadHover.setVisible(false);
        optionHover.setVisible(false);
        connexionHover.setVisible(false);
        huntiesPanel.add(downloadHover);
        huntiesPanel.add(optionHover);
        huntiesPanel.add(connexionHover);
        downloadHover.addActionListener(this);
        optionHover.addActionListener(this);
        connexionHover.addActionListener(this);
        downloadHover.addMouseListener(this);
        optionHover.addMouseListener(this);
        connexionHover.addMouseListener(this);

        huntiesPanel.addMouseListener(this);

        pseudo.setBounds(30, 78, 80, 18);
        pseudo.setForeground(Color.white);
        pseudo.setFont(pseudo.getFont().deriveFont(22));
        huntiesPanel.add(pseudo);

        State.setInterfaceEnabled(null);
    }

    @Override
    public void paintComponent(Graphics g) {
        if(currentInterface != null){
            currentInterface.paintComponent(g);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(State.getEnabledInterface() == Interfaces.OPTION){
            interfaceOption.getInstallationPathSelector().mousePressed(e);
        }
        if(e.getSource() == downloadHover || e.getSource() == optionHover ||e.getSource() == interfaceConnexion){
            return;
        }
        if(e.getX() > 425){
            State.setInterfaceEnabled(null);
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if (e.getSource() == downloadButton) {
            if (!downloadHover.isVisible()) {
                downloadButton.setVisible(false);
                downloadHover.setVisible(true);
            }
        } else if (e.getSource() == optionButton) {
            if (!optionHover.isVisible()) {
                optionButton.setVisible(false);
                optionHover.setVisible(true);
            }
        } else if (e.getSource() == connexionButton) {
            if (!connexionHover.isVisible()) {
                connexionButton.setVisible(false);
                connexionHover.setVisible(true);
            }
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if (e.getSource() == downloadHover) {
            if (State.getEnabledInterface() == Interfaces.DOWNLOAD) {
                return;
            }
            downloadHover.setVisible(false);
            downloadButton.setVisible(true);
        } else if (e.getSource() == optionHover) {
            if (State.getEnabledInterface() == Interfaces.OPTION) {
                return;
            }
            optionHover.setVisible(false);
            optionButton.setVisible(true);
        } else if (e.getSource() == connexionHover) {
            if (State.getEnabledInterface() == Interfaces.CONNEXION) {
                return;
            }
            connexionHover.setVisible(false);
            connexionButton.setVisible(true);
        }
    }

    public static void setPseudo(String name){
        INTERFACE_MANAGER.pseudo.setText(name);
    }

    public JButton getConnexionButton() {
        return connexionButton;
    }

    public static InterfaceConnexion getInterfaceConnexion() {
        return INTERFACE_MANAGER.interfaceConnexion;
    }

    public static InterfaceOption getInterfaceOption() {
        return INTERFACE_MANAGER.interfaceOption;
    }

    public static InterfaceDownload getInterfaceDownload() {
        return INTERFACE_MANAGER.interfaceDownload;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == downloadHover) {
            if (!(currentInterface instanceof InterfaceDownload)) {
                State.setInterfaceEnabled(Interfaces.DOWNLOAD);
            }
        }
        if (e.getSource() == optionHover) {
            if (!(currentInterface instanceof InterfaceOption)) {
                State.setInterfaceEnabled(Interfaces.OPTION);
            }
        }
        if (e.getSource() == connexionHover) {
            if (!(currentInterface instanceof InterfaceConnexion)) {
                State.setInterfaceEnabled(Interfaces.CONNEXION);
            }
        }
    }

    public static class State {
        private static boolean isDownloadEnabled = true, isOptionEnabled = false, isConnexionEnabled = true;

        public static Interfaces getEnabledInterface() {
            if (isDownloadEnabled) {
                return Interfaces.DOWNLOAD;
            }
            if (isOptionEnabled) {
                return Interfaces.OPTION;
            }
            if (isConnexionEnabled) {
                return Interfaces.DOWNLOAD;
            }
            return null;
        }

        public static void setInterfaceEnabled(Interfaces interfaces) {
            if(interfaces == null){
                INTERFACE_MANAGER.interfaceDownload.setEnabled(false);
                INTERFACE_MANAGER.interfaceOption.setEnabled(false);
                INTERFACE_MANAGER.interfaceConnexion.setEnabled(false);
                INTERFACE_MANAGER.currentInterface = null;
                INTERFACE_MANAGER.downloadButton.setVisible(true);
                INTERFACE_MANAGER.downloadHover.setVisible(false);
                INTERFACE_MANAGER.optionButton.setVisible(true);
                INTERFACE_MANAGER.optionHover.setVisible(false);
                INTERFACE_MANAGER.connexionButton.setVisible(true);
                INTERFACE_MANAGER.connexionHover.setVisible(false);
                isDownloadEnabled = false;
                isOptionEnabled = false;
                isConnexionEnabled = false;
                if (INTERFACE_MANAGER.huntiesPanel.getGraphics() != null) {
                    INTERFACE_MANAGER.huntiesPanel.repaint();
                }
                //System.out.println("[HuntiesLauncher] UtilsInterfaceManager : no interface loaded.");
                GameInterfaceManager.State.setInterfaceEnabled(GameInterfaceManager.State.getEnabledInterface());
                GameInterfaceManager.setButtonVisible(true);
                return;
            }
            GameInterfaceManager.setButtonVisible(false);
            switch (interfaces) {
                case DOWNLOAD: {
                    INTERFACE_MANAGER.interfaceDownload.setEnabled(true);
                    INTERFACE_MANAGER.interfaceOption.setEnabled(false);
                    INTERFACE_MANAGER.interfaceConnexion.setEnabled(false);
                    INTERFACE_MANAGER.currentInterface = INTERFACE_MANAGER.interfaceDownload;
                    INTERFACE_MANAGER.downloadButton.setVisible(false);
                    INTERFACE_MANAGER.downloadHover.setVisible(true);
                    INTERFACE_MANAGER.optionButton.setVisible(true);
                    INTERFACE_MANAGER.optionHover.setVisible(false);
                    INTERFACE_MANAGER.connexionButton.setVisible(true);
                    INTERFACE_MANAGER.connexionHover.setVisible(false);
                    isDownloadEnabled = true;
                    isOptionEnabled = false;
                    isConnexionEnabled = false;
                    break;
                }
                case OPTION: {
                    INTERFACE_MANAGER.interfaceDownload.setEnabled(false);
                    INTERFACE_MANAGER.interfaceOption.setEnabled(true);
                    INTERFACE_MANAGER.interfaceConnexion.setEnabled(false);
                    INTERFACE_MANAGER.currentInterface = INTERFACE_MANAGER.interfaceOption;
                    INTERFACE_MANAGER.optionButton.setVisible(false);
                    INTERFACE_MANAGER.optionHover.setVisible(true);
                    INTERFACE_MANAGER.downloadButton.setVisible(true);
                    INTERFACE_MANAGER.downloadHover.setVisible(false);
                    INTERFACE_MANAGER.connexionButton.setVisible(true);
                    INTERFACE_MANAGER.connexionHover.setVisible(false);
                    isDownloadEnabled = false;
                    isOptionEnabled = true;
                    isConnexionEnabled = false;
                    break;
                }
                case CONNEXION: {
                    INTERFACE_MANAGER.interfaceDownload.setEnabled(false);
                    INTERFACE_MANAGER.interfaceOption.setEnabled(false);
                    INTERFACE_MANAGER.interfaceConnexion.setEnabled(true);
                    INTERFACE_MANAGER.currentInterface = INTERFACE_MANAGER.interfaceConnexion;
                    INTERFACE_MANAGER.connexionButton.setVisible(false);
                    INTERFACE_MANAGER.connexionHover.setVisible(true);
                    INTERFACE_MANAGER.downloadButton.setVisible(true);
                    INTERFACE_MANAGER.downloadHover.setVisible(false);
                    INTERFACE_MANAGER.optionButton.setVisible(true);
                    INTERFACE_MANAGER.optionHover.setVisible(false);
                    isDownloadEnabled = false;
                    isOptionEnabled = false;
                    isConnexionEnabled = true;
                    break;
                }
            }
            if (INTERFACE_MANAGER.huntiesPanel.getGraphics() != null) {
                INTERFACE_MANAGER.huntiesPanel.repaint();
            }
            //System.out.println("[HuntiesLauncher] UtilsInterfaceManager : interface '" + interfaces.name() + "' loaded.");
        }

        public static boolean isIsConnexionEnabled() {
            return isConnexionEnabled;
        }

        public static boolean isIsDownloadEnabled() {
            return isDownloadEnabled;
        }

        public static boolean isIsOptionEnabled() {
            return isOptionEnabled;
        }
    }
}