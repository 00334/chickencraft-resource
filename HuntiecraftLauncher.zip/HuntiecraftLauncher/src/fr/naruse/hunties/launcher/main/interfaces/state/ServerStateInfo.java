package fr.naruse.hunties.launcher.main.interfaces.state;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.utils.Utils;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileReader;

public class ServerStateInfo {
    private String host;
    private File file;
    private String[] lines = new String[4];
    private Color[] colors = new Color[4];
    private JLabel[] jLabels = new JLabel[4];
    public ServerStateInfo(String host) {
        file = Utils.downloadFile(host, new File(Main.INSTANCE.getHuntiesConnection().DIR, "server_state.json"));
        if(file == null){
            return;
        }
        JsonParser jsonParser = new JsonParser();
        try(FileReader fileReader = new FileReader(file)){
            Object object = jsonParser.parse(fileReader);

            JsonObject jsonObject = (JsonObject) object;

            JsonObject line1 = jsonObject.getAsJsonObject("line1");
            lines[0] = line1.get("string").getAsString();
            colors[0] = getColorByName(line1.get("color").getAsString());

            JsonObject line2 = jsonObject.getAsJsonObject("line2");
            lines[1] = line2.get("string").getAsString();
            colors[1] = getColorByName(line2.get("color").getAsString());

            JsonObject line3 = jsonObject.getAsJsonObject("line3");
            lines[2] = line3.get("string").getAsString();
            colors[2] = getColorByName(line3.get("color").getAsString());

            JsonObject line4 = jsonObject.getAsJsonObject("line4");
            lines[3] = line4.get("string").getAsString();
            colors[3] = getColorByName(line4.get("color").getAsString());

        }catch (Exception e){
            e.printStackTrace();
        }
        file.delete();

        jLabels[0] = new JLabel(lines[0]);
        jLabels[0].setForeground(colors[0]);
        jLabels[0].setFont(jLabels[0].getFont().deriveFont(13f));
        jLabels[0].setBounds(170, 220, 257, 20);

        jLabels[1] = new JLabel(lines[1]);
        jLabels[1].setFont(jLabels[1].getFont().deriveFont(13f));
        jLabels[1].setForeground(colors[1]);
        jLabels[1].setBounds(170, 220+23, 257, 20);

        jLabels[2] = new JLabel(lines[2]);
        jLabels[2].setFont(jLabels[2].getFont().deriveFont(13f));
        jLabels[2].setForeground(colors[2]);
        jLabels[2].setBounds(170, 220+23*2, 257, 20);

        jLabels[3] = new JLabel(lines[3]);
        jLabels[3].setFont(jLabels[3].getFont().deriveFont(13f));
        jLabels[3].setForeground(colors[3]);
        jLabels[3].setBounds(170, 220+23*3, 257, 20);

        new Thread(){
            @Override
            public void run() {
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for(JLabel jLabel : jLabels){
                    jLabel.setFont(new java.awt.Font(Font.MONOSPACED, Font.TYPE1_FONT,14));
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().add(jLabel);
                }
            }
        }.start();
    }

    private Color getColorByName(String name) {
        try {
            return (Color)Color.class.getField(name.toUpperCase()).get(null);
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setVisible(boolean b) {
        if(file == null){
            return;
        }
        for(JLabel jLabel : jLabels){
            jLabel.setVisible(b);
        }
    }
}
