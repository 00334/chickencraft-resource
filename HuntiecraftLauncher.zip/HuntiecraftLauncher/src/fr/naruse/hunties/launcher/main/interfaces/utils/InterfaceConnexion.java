package fr.naruse.hunties.launcher.main.interfaces.utils;

import fr.naruse.hunties.launcher.box.HcnCheckBox;
import fr.naruse.hunties.launcher.event.ConnexionButtonAction;
import fr.naruse.hunties.launcher.event.KeyListeners;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.connector.Connectors;
import fr.naruse.hunties.launcher.main.interfaces.AbstractInterface;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.utils.PasswordSaver;
import fr.naruse.hunties.launcher.utils.UsernameSaver;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import java.awt.*;

public class InterfaceConnexion extends AbstractInterface {
    private JTextField hUsernameField, pUsernameField, cUsernameField;
    private JPasswordField hPasswordField = new JPasswordField(), pPasswordField = new JPasswordField();
    private HcnCheckBox hSavePass, pSavePass, cSavePass;
    private UsernameSaver hUsernameSaver, pUsernameSaver, cUsernameSaver;
    private PasswordSaver hPasswordSaver, pPasswordSaver;
    private STexturedButton hConnexionButton = new STexturedButton(Swinger.getResource("button/connexionsButton.png")),
            pConnexionButton = new STexturedButton(Swinger.getResource("button/connexionsButton.png")),
            cConnexionButton = new STexturedButton(Swinger.getResource("button/connexionsButton.png"));
    private STexturedButton hConnexionButtonHover = new STexturedButton(Swinger.getResource("button/connexionsHover.png")),
            pConnexionButtonHover = new STexturedButton(Swinger.getResource("button/connexionsHover.png")),
            cConnexionButtonHover = new STexturedButton(Swinger.getResource("button/connexionsHover.png"));
    private ConnexionButtonAction hConnexionButtonAction, pConnexionButtonAction, cConnexionButtonAction;
    public InterfaceConnexion(HuntiesPanel huntiesPanel) {
        super(huntiesPanel, Interfaces.CONNEXION);
        this.hUsernameField = new JTextField();
        this.hUsernameField.setForeground(Color.LIGHT_GRAY);
        this.hUsernameField.setFont(hUsernameField.getFont().deriveFont(16F));
        this.hUsernameField.setCaretColor(Color.BLACK);
        this.hUsernameField.setSelectionColor(Color.ORANGE);
        this.hUsernameField.setOpaque(false);
        this.hUsernameField.setBorder(null);
        this.hUsernameField.setBounds(123, 155, 254, 18);
        this.hUsernameField.addKeyListener(new KeyListeners(huntiesPanel, Connectors.HUNTIES));
        this.hUsernameField.setVisible(false);
        huntiesPanel.add(hUsernameField);
        this.hPasswordField.setForeground(Color.LIGHT_GRAY);
        this.hPasswordField.setFont(hUsernameField.getFont().deriveFont(15F));
        this.hPasswordField.setCaretColor(Color.BLACK);
        this.hPasswordField.setSelectionColor(Color.ORANGE);
        this.hPasswordField.setOpaque(false);
        this.hPasswordField.setBorder(null);
        this.hPasswordField.setBounds(123, 196, 254, 18);
        this.hPasswordField.addKeyListener(new KeyListeners(huntiesPanel, Connectors.HUNTIES));
        this.hPasswordField.setVisible(false);
        huntiesPanel.add(hPasswordField);
        this.hSavePass = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 121+170, 196+28, 18, 19);
        this.hSavePass.addTo(huntiesPanel);
        this.hSavePass.setVisible(false);

        this.hConnexionButton.setBounds(180, 260);
        this.hConnexionButtonHover.setBounds(180, 260);
        this.hConnexionButton.setVisible(false);
        this.hConnexionButtonHover.setVisible(false);
        huntiesPanel.add(hConnexionButton);
        huntiesPanel.add(hConnexionButtonHover);
        huntiesPanel.getNewConnexionButtonAction(hConnexionButtonAction = new ConnexionButtonAction(huntiesPanel, hConnexionButton, hConnexionButtonHover, Connectors.HUNTIES));

        this.hUsernameSaver = new UsernameSaver(huntiesPanel, "h", hUsernameField);
        this.hPasswordSaver = new PasswordSaver(huntiesPanel, "h", hPasswordField, hSavePass);

        String username = hUsernameSaver.readUsername();
        if(username != null){
            hUsernameField.setText(username);
            huntiesPanel.getSkinLocator().setName(username);
        }
        String password = hPasswordSaver.readPassword();
        if(password != null){
            hPasswordField.setText(password);
        }



        this.pUsernameField = new JTextField();
        this.pUsernameField.setForeground(Color.LIGHT_GRAY);
        this.pUsernameField.setFont(pUsernameField.getFont().deriveFont(16F));
        this.pUsernameField.setCaretColor(Color.BLACK);
        this.pUsernameField.setSelectionColor(Color.ORANGE);
        this.pUsernameField.setOpaque(false);
        this.pUsernameField.setBorder(null);
        this.pUsernameField.setBounds(123, 196+165+19, 254, 18);
        this.pUsernameField.addKeyListener(new KeyListeners(huntiesPanel, Connectors.PREMIUM));
        this.pUsernameField.setVisible(false);
        huntiesPanel.add(pUsernameField);
        this.pPasswordField.setForeground(Color.LIGHT_GRAY);
        this.pPasswordField.setFont(pUsernameField.getFont().deriveFont(15F));
        this.pPasswordField.setCaretColor(Color.BLACK);
        this.pPasswordField.setSelectionColor(Color.ORANGE);
        this.pPasswordField.setOpaque(false);
        this.pPasswordField.setBorder(null);
        this.pPasswordField.setBounds(123, 196+165+42+19, 254, 18);
        this.pPasswordField.addKeyListener(new KeyListeners(huntiesPanel, Connectors.PREMIUM));
        this.pPasswordField.setVisible(false);
        huntiesPanel.add(pPasswordField);
        this.pSavePass = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 121+170, 196+28+228, 18, 19);
        this.pSavePass.addTo(huntiesPanel);
        this.pSavePass.setVisible(false);

        this.pConnexionButton.setBounds(180, 260+165+60);
        this.pConnexionButtonHover.setBounds(180, 260+165+60);
        this.pConnexionButton.setVisible(false);
        this.pConnexionButtonHover.setVisible(false);
        huntiesPanel.add(pConnexionButton);
        huntiesPanel.add(pConnexionButtonHover);
        huntiesPanel.getNewConnexionButtonAction(pConnexionButtonAction = new ConnexionButtonAction(huntiesPanel, pConnexionButton, pConnexionButtonHover, Connectors.PREMIUM));

        this.pUsernameSaver = new UsernameSaver(huntiesPanel, "p", pUsernameField);
        this.pPasswordSaver = new PasswordSaver(huntiesPanel, "p", pPasswordField, pSavePass);

        username = pUsernameSaver.readUsername();
        if(username != null){
            pUsernameField.setText(username);
        }
        password = pPasswordSaver.readPassword();
        if(password != null){
            pPasswordField.setText(password);
        }



        this.cUsernameField = new JTextField();
        this.cUsernameField.setForeground(Color.LIGHT_GRAY);
        this.cUsernameField.setFont(cUsernameField.getFont().deriveFont(16F));
        this.cUsernameField.setCaretColor(Color.BLACK);
        this.cUsernameField.setSelectionColor(Color.ORANGE);
        this.cUsernameField.setOpaque(false);
        this.cUsernameField.setBorder(null);
        this.cUsernameField.setBounds(123, 196+(165+19)*2+19*2+4, 254, 18);
        this.cUsernameField.addKeyListener(new KeyListeners(huntiesPanel, Connectors.CRACK));
        this.cUsernameField.setVisible(false);
        huntiesPanel.add(cUsernameField);
        this.cSavePass = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 121+170, 196+28+228+183, 18, 19);
        this.cSavePass.addTo(huntiesPanel);
        this.cSavePass.setVisible(false);

        this.cConnexionButton.setBounds(180, 260+165*2+60+20);
        this.cConnexionButtonHover.setBounds(180, 260+165*2+60+20);
        this.cConnexionButton.setVisible(false);
        this.cConnexionButtonHover.setVisible(false);
        huntiesPanel.add(cConnexionButton);
        huntiesPanel.add(cConnexionButtonHover);
        huntiesPanel.getNewConnexionButtonAction(cConnexionButtonAction = new ConnexionButtonAction(huntiesPanel, cConnexionButton, cConnexionButtonHover, Connectors.CRACK));

        this.cUsernameSaver = new UsernameSaver(huntiesPanel, "c", cUsernameField);

        username = cUsernameSaver.readUsername();
        if(username != null){
            cUsernameField.setText(username);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if(enabled){
            this.hPasswordField.setVisible(true);
            this.hUsernameField.setVisible(true);
            this.hSavePass.setVisible(true);
            this.hConnexionButton.setVisible(true);
            this.hConnexionButtonHover.setVisible(false);
            this.hPasswordSaver.readPassword();

            this.pPasswordField.setVisible(true);
            this.pUsernameField.setVisible(true);
            this.pSavePass.setVisible(true);
            this.pConnexionButton.setVisible(true);
            this.pConnexionButtonHover.setVisible(false);
            this.pPasswordSaver.readPassword();

            this.cUsernameField.setVisible(true);
            this.cSavePass.setVisible(true);
            this.cConnexionButton.setVisible(true);
            this.cConnexionButtonHover.setVisible(false);
            this.cSavePass.setSelected(true);
        }else{
            this.hPasswordField.setVisible(false);
            this.hUsernameField.setVisible(false);
            this.hSavePass.setVisible(false);
            this.hConnexionButton.setVisible(false);
            this.hConnexionButtonHover.setVisible(false);

            this.pPasswordField.setVisible(false);
            this.pUsernameField.setVisible(false);
            this.pSavePass.setVisible(false);
            this.pConnexionButton.setVisible(false);
            this.pConnexionButtonHover.setVisible(false);

            this.cUsernameField.setVisible(false);
            this.cSavePass.setVisible(false);
            this.cConnexionButton.setVisible(false);
            this.cConnexionButtonHover.setVisible(false);
        }
    }

    public void savePassAndName(){
        hPasswordSaver.savePassword();
        hPasswordSaver.saveCheckBox();
        hUsernameSaver.saveUsername();

        pPasswordSaver.savePassword();
        pPasswordSaver.saveCheckBox();
        pUsernameSaver.saveUsername();

        cUsernameSaver.saveUsername();
    }

    public JTextField getHUsernameField() {
        return hUsernameField;
    }

    public JPasswordField getHPasswordField() {
        return hPasswordField;
    }

    public JTextField getPUsernameField() {
        return pUsernameField;
    }

    public JPasswordField getPPasswordField() {
        return pPasswordField;
    }

    public ConnexionButtonAction getHConnexionButtonAction() {
        return hConnexionButtonAction;
    }

    public ConnexionButtonAction getPConnexionButtonAction() {
        return pConnexionButtonAction;
    }

    public ConnexionButtonAction getCConnexionButtonAction() {
        return cConnexionButtonAction;
    }

    public JTextField getCUsernameField() {
        return cUsernameField;
    }
}
