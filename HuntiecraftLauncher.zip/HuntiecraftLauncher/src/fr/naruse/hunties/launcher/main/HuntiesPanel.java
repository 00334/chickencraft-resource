package fr.naruse.hunties.launcher.main;

import fr.naruse.hunties.launcher.event.*;
import fr.naruse.hunties.launcher.main.button.SocialNetworkButtons;
import fr.naruse.hunties.launcher.main.interfaces.game.GameInterfaceManager;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.utils.HuntiesProgressBar;
import fr.naruse.hunties.launcher.utils.SkinLocator;
import fr.naruse.hunties.launcher.utils.Utils;
import fr.theshark34.swinger.Swinger;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

import static fr.theshark34.swinger.Swinger.drawFullsizedImage;

public class HuntiesPanel extends JPanel {
    private HuntiesFrame huntiesFrame;
    private HuntiesProgressBar progressBar = new HuntiesProgressBar();
    private JLabel infoLabel = new JLabel("Connecte-toi pour jouer!", SwingConstants.CENTER);
    private JButton quitButtonHover = new JButton(new ImageIcon(Swinger.getResource("button/quit.png")));
    private JButton quitButton = new JButton(new ImageIcon(Swinger.getResource("button/quitsHover.png")));
    private JButton minimizeButtonHover = new JButton(new ImageIcon(Swinger.getResource("button/minimize.png")));
    private JButton minimizeButton = new JButton(new ImageIcon(Swinger.getResource("button/minimizesHover.png")));
    private JButton invislbeB = new JButton(new ImageIcon(Swinger.getResource("button/minimizesHover.png")));
    private BufferedImage fontImage;
    private QuitButtonAction quitButtonAction;
    private MinimizeButtonAction minimizeButtonAction;
    private ConnexionButtonAction connexionButtonAction;

    private GameInterfaceManager gameInterfaceManager;
    private UtilsInterfaceManager utilsInterfaceManager;

    private SkinLocator skinLocator;

    public HuntiesPanel(HuntiesFrame huntiesFrame) {
        this.huntiesFrame = huntiesFrame;

        setLayout(null);

        setBackground(new Color(255, 255, 255, 0));

        this.skinLocator = new SkinLocator();
        this.add(skinLocator);
        this.gameInterfaceManager = new GameInterfaceManager(this);
        this.utilsInterfaceManager = new UtilsInterfaceManager(this);

        this.fontImage = Utils.getFontImage();

        this.progressBar.setVisible(true);
        this.progressBar.setBackground(Color.GRAY);
        this.progressBar.setForeground(new Color(194, 88, 77));
        this.progressBar.setBounds(157, 720, 20, 20);

        this.add(progressBar);

        this.infoLabel.setForeground(Color.WHITE);
        this.infoLabel.setFont(new JTextField().getFont().deriveFont(16F));
        this.infoLabel.setFont(infoLabel.getFont().deriveFont(13f));
        this.infoLabel.setBounds(372, 705, 280, 23);
        this.add(infoLabel);

        this.quitButton.setBounds(huntiesFrame.getWidth()-30, 3, 20, 20);
        this.quitButton.addActionListener(quitButtonAction = new QuitButtonAction(this, quitButton, quitButtonHover));
        this.quitButton.addMouseListener(quitButtonAction);
        this.quitButton.setBorder(BorderFactory.createEmptyBorder());
        this.quitButton.setContentAreaFilled(false);
        this.quitButton.setBorderPainted(false);
        this.add(quitButton);
        this.quitButtonHover.setBounds(huntiesFrame.getWidth()-30, 3, 20, 20);
        this.quitButtonHover.addActionListener(quitButtonAction);
        this.quitButtonHover.addMouseListener(quitButtonAction);
        this.quitButtonHover.setVisible(false);
        this.quitButtonHover.setBorder(BorderFactory.createEmptyBorder());
        this.quitButtonHover.setContentAreaFilled(false);
        this.quitButtonHover.setBorderPainted(false);
        this.add(quitButtonHover);

        this.minimizeButton.setBounds(huntiesFrame.getWidth()-30*2, 3, 20, 20);
        this.minimizeButton.addActionListener(minimizeButtonAction = new MinimizeButtonAction(this, minimizeButton, minimizeButtonHover));
        this.minimizeButton.addMouseListener(minimizeButtonAction);
        this.minimizeButton.setBorder(BorderFactory.createEmptyBorder());
        this.minimizeButton.setContentAreaFilled(false);
        this.minimizeButton.setBorderPainted(false);
        this.add(minimizeButton);
        this.minimizeButtonHover.setBounds(huntiesFrame.getWidth()-30*2, 3, 20, 20);
        this.minimizeButtonHover.addActionListener(minimizeButtonAction);
        this.minimizeButtonHover.addMouseListener(minimizeButtonAction);
        this.minimizeButtonHover.setVisible(false);
        this.minimizeButtonHover.setBorder(BorderFactory.createEmptyBorder());
        this.minimizeButtonHover.setContentAreaFilled(false);
        this.minimizeButtonHover.setBorderPainted(false);
        this.add(minimizeButtonHover);
        this.add(invislbeB);

        new SocialNetworkButtons(this);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawFullsizedImage(g, this, fontImage);
        gameInterfaceManager.paintComponent(g);
        utilsInterfaceManager.paintComponent(g);
        progressBar.paintComponent(g);
        skinLocator.paintComponent(g);
    }

    public void setInfoText(String s) {
        infoLabel.setText(s);
    }

    public HuntiesProgressBar getProgressBar() {
        return this.progressBar;
    }

    public HuntiesFrame getHuntiesFrame() {
        return huntiesFrame;
    }

    public JLabel getInfoLabel() {
        return infoLabel;
    }

    public void getNewConnexionButtonAction(ConnexionButtonAction connexionButtonAction) {
        this.connexionButtonAction = connexionButtonAction;
    }

    public SkinLocator getSkinLocator() {
        return skinLocator;
    }
}
