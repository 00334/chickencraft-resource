package fr.naruse.hunties.launcher.main;

import fr.naruse.hunties.launcher.utils.Animator;
import fr.theshark34.openlauncherlib.util.ramselector.RamSelector;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.util.WindowMover;

import javax.swing.*;
import java.io.File;

public class HuntiesFrame extends JFrame {
    private Main pl;
    private HuntiesPanel huntiesPanel;
    public HuntiesFrame(Main pl) {
        this.pl = pl;
        this.setTitle("HuntiesCraft-Network");
        this.setIconImage(Swinger.getResource("icon.jpg"));
        this.setSize(1200, 750);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setContentPane(huntiesPanel = new HuntiesPanel(this));
        this.setUndecorated(true);
        WindowMover mover = new WindowMover(this);
        this.addMouseListener(mover);
        this.addMouseMotionListener(mover);
        this.huntiesPanel.addMouseListener(mover);
        this.huntiesPanel.addMouseMotionListener(mover);
        this.setVisible(true);
        Animator.fadeInFrame(this, Animator.FAST);
        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                super.run();
                pl.getSqlConnection().disconnection();
            }
        });
    }

    public void close(){
        if(pl.getHuntiesConnection().getAbstractUpdater() != null){
            if(pl.getHuntiesConnection().getAbstractUpdater().getInformationThread() != null){
                pl.getHuntiesConnection().getAbstractUpdater().getInformationThread().interrupt();
            }
            if(pl.getHuntiesConnection().getAbstractUpdater().getUpdateThread() != null){
                pl.getHuntiesConnection().getAbstractUpdater().getUpdateThread().interrupt();
            }
            if(pl.getHuntiesConnection().getAbstractUpdater().getShaderThread() != null){
                pl.getHuntiesConnection().getAbstractUpdater().getShaderThread().interrupt();
            }
        }
        Animator.fadeOutFrame(this, 1, new Runnable() {
            @Override
            public void run() {
                System.exit(0);
            }
        });
    }

    public HuntiesPanel getHuntiesPanel() {
        return huntiesPanel;
    }

    public Main getMain() {
        return pl;
    }
}
