package fr.naruse.hunties.launcher.main.connector;

import fr.naruse.hunties.launcher.event.ConnexionButtonAction;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.utils.Utils;

public abstract class AbstractConnector {
    protected HuntiesPanel huntiesPanel;
    public AbstractConnector(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
    }

    public void connexion(ConnexionButtonAction connexionButtonAction){
        Utils.generateDir();
    }
}
