package fr.naruse.hunties.launcher.main.updater;

import fr.naruse.hunties.launcher.discord.DiscordEventHandler;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.connector.AuthenticatorInfos;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.selector.VersionSelectorFrame;
import fr.naruse.hunties.launcher.utils.Utils;
import fr.naruse.hunties.launcher.utils.log.LogFrame;
import fr.theshark34.openlauncherlib.external.ExternalLaunchProfile;
import fr.theshark34.openlauncherlib.external.ExternalLauncher;
import fr.theshark34.openlauncherlib.minecraft.*;
import fr.theshark34.openlauncherlib.util.ProcessLogManager;
import fr.theshark34.supdate.SUpdate;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class UpdaterUniversal extends AbstractUpdater {
    private File DIR;
    public UpdaterUniversal(Main main) {
        super(main);
        this.DIR = main.getHuntiesConnection().UNIVERSAL_DIR;
    }

    private AuthInfos authInfos;
    @Override
    public void update() {
        if(AuthenticatorInfos.CRACK_AUTH == null){
            authInfos = AuthenticatorInfos.PREMIUM_AUTH;
        }else{
            authInfos = AuthenticatorInfos.CRACK_AUTH;
        }

        String host = "https://huntiescraft.net/public/launcher/servers/sides/universal/";
        SUpdate su = new SUpdate(host, DIR);
        su.getServerRequester().setRewriteEnabled(true);
        updateThread = new Thread(){
            @Override
            public void run() {
                super.run();
                try{
                    su.start();
                    Main.INSTANCE.getHuntiesConnection().getUpdaterCommon().informationThread.interrupt();
                }catch (Exception e){
                    e.printStackTrace();
                    main.getHuntiesFrame().setVisible(false);
                    JOptionPane.showMessageDialog(main.getHuntiesFrame().getHuntiesPanel(), "Erreur, Impossible de mettre à jour le jeu : "+e.getLocalizedMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                    return;
                }
                ressourcePackThread = new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        List<String> links = UtilsInterfaceManager.getInterfaceDownload().getResourcesPacksBox().getDownloadLinks();
                        int size = links.size();
                        int count = 1;
                        for(String link : links){
                            try {
                                String name = UtilsInterfaceManager.getInterfaceDownload().getResourcesPacksBox().getShaderName(link);
                                Utils.downloadResourcePack(link, new File(new File(DIR, "resourcepacks"), name), count, size);
                                System.out.println("[HuntiesLauncer] Download successful for "+name+".");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            count++;
                        }
                        copyResourcePacks(Interfaces.UNIVERSAL);
                        File versionDIR = new File(DIR, "versions/"+VersionSelectorFrame.getVersion());
                        unzipAssets(versionDIR, new File(DIR, "zipFiles/assets"+VersionSelectorFrame.getVersion()+".zip"));
                        launchGame();
                        this.interrupt();
                    }
                };
                ressourcePackThread.start();
            }
        };
        updateThread.start();
    }

    @Override
    public void launchGame() {
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Lancement du jeu...");
        try {
            DIR = new File(DIR, "versions/"+VersionSelectorFrame.getVersion());

            main.getHuntiesConnection().VERSION = new GameVersion(VersionSelectorFrame.getVersion(), GameType.V1_8_HIGHER);
            main.getHuntiesConnection().INFOS_UNIVERSAL = new GameInfos("HuntiesCraft-Network", DIR, main.getHuntiesConnection().VERSION, new GameTweak[] {});

            ExternalLaunchProfile profile = MinecraftLauncher.createExternalProfile(main.getHuntiesConnection().INFOS_UNIVERSAL, GameFolder.BASIC, authInfos);
            int xmx = Integer.valueOf(main.getHuntiesOption().getString("memory"));
            profile.getVmArgs().add("-Xmx"+xmx+"M");
            for(int i = 0; i != profile.getVmArgs().size(); i++){
                String arg = profile.getVmArgs().get(i);
                if(arg.equalsIgnoreCase("XX:+CMSIncrementalMode")){
                    profile.getVmArgs().remove(arg);
                    System.out.println("[HuntiesLauncher] Removing CMSIncrementalMode argument.");
                }
                System.out.println("[HuntiesLauncher] Argument "+(i+1)+"; "+arg);
            }

            DiscordEventHandler.inLaunching();
            ExternalLauncher launcher = new ExternalLauncher(profile);
            Process p = launcher.launch();
            ProcessLogManager manager = new ProcessLogManager(p.getInputStream(), new File(DIR, "logs.txt"));
            manager.start();
            Thread.sleep(5000L);
            main.getHuntiesFrame().setVisible(false);
            p.waitFor();
            DiscordEventHandler.stop();
            LogFrame.setCloseOperation();
            main.getSqlConnection().disconnection();
        } catch (Exception var5) {
            var5.printStackTrace();
        }
    }
}
