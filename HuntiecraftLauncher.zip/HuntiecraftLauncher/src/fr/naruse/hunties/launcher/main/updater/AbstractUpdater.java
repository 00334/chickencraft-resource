package fr.naruse.hunties.launcher.main.updater;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.connector.AuthenticatorInfos;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.game.GameInterfaceManager;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.naruse.hunties.launcher.utils.Utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

public abstract class AbstractUpdater {
    protected Main main;
    protected Thread updateThread, shaderThread, ressourcePackThread;
    public AbstractUpdater(Main main) {
        this.main = main;
    }

    public abstract void update();

    public abstract void launchGame();

    protected File downloadAssets(String host, File dest){
        try{
            InputStream is = null;
            OutputStream os = null;
            if(!dest.getParentFile().exists()){
                dest.getParentFile().mkdirs();
            }
            try {
                System.out.println("[HuntiesLauncher] Checking assets...");
                main.getHuntiesFrame().getHuntiesPanel().setInfoText("Vérification des assets...");
                if(dest.exists()){
                    if(dest.length() == Utils.fileSize(host)){
                        return dest;
                    }else{
                        dest.delete();
                    }
                }
                URL url = new URL(host);
                URLConnection connection = url.openConnection();
                int fileLength = connection.getContentLength();
                if (fileLength == -1) {
                    System.out.println("Invalide URL or file.");
                    return null;
                }
                is = connection.getInputStream();
                os = new FileOutputStream(dest);
                byte[] buffer = new byte[1024];
                int length;
                int count = 0;
                main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(fileLength);
                DecimalFormat df = new DecimalFormat("0.##");
                while ((length = is.read(buffer)) > 0) {
                    count += length;
                    main.getHuntiesFrame().getHuntiesPanel().setInfoText("Téléchargement des assets... ("+df.format(count*0.000001)+" Mo/"+df.format(fileLength*0.000001)+" Mo)");
                    main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(count);
                    os.write(buffer, 0, length);
                }
            } finally {
                if(is != null){
                    is.close();
                    os.close();
                }
            }
            return dest;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    protected void unzipAssets(File folder){
        unzipAssets(folder, new File(folder, "zipFiles/assetsZip.zip"));
    }

    protected void unzipAssets(File folder, File assetsZipFile){
        main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setMaximum(100);
        main.getHuntiesFrame().getHuntiesPanel().getProgressBar().setValue(100);
        File assetsFolder = new File(folder, "assets");
        if(assetsFolder.exists()){
            assetsFolder.delete();
        }
        main.getHuntiesFrame().getHuntiesPanel().setInfoText("Décompression des assets...");
        System.out.println("[HuntiesLauncher] Unzipping '"+assetsZipFile.getName()+"' to '"+assetsFolder.getParentFile().getPath()+"'...");
        Utils.unzip(assetsZipFile, assetsFolder.getParentFile());
    }

    public static boolean isConnected(AbstractUpdater abstractUpdater){
        if(abstractUpdater instanceof UpdaterHunties){
            if(AuthenticatorInfos.HUNTIES_USERNAME == null){
                UtilsInterfaceManager.State.setInterfaceEnabled(Interfaces.CONNEXION);
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Connecte-toi pour jouer!");
                return false;
            }
            return true;
        }
        if(abstractUpdater instanceof UpdaterVanilla){
            if(AuthenticatorInfos.HUNTIES_USERNAME == null){
                UtilsInterfaceManager.State.setInterfaceEnabled(Interfaces.CONNEXION);
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Connecte-toi pour jouer!");
                return false;
            }
            return true;
        }
        if(abstractUpdater instanceof UpdaterUniversal){
            if(AuthenticatorInfos.CRACK_USERNAME == null && AuthenticatorInfos.PREMIUM_USERNAME == null){
                UtilsInterfaceManager.State.setInterfaceEnabled(Interfaces.CONNEXION);
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Connecte-toi pour jouer!");
                return false;
            }
            if(AuthenticatorInfos.PREMIUM_USERNAME != null){
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                GameInterfaceManager.State.setInterfaceEnabled(Interfaces.UNIVERSAL);
                return true;
            }else{
                if(AuthenticatorInfos.CRACK_USERNAME != null){
                    UtilsInterfaceManager.State.setInterfaceEnabled(null);
                    GameInterfaceManager.State.setInterfaceEnabled(Interfaces.UNIVERSAL);
                    return true;
                }else{
                    UtilsInterfaceManager.State.setInterfaceEnabled(Interfaces.CONNEXION);
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Connecte-toi pour jouer!");
                    return false;
                }
            }
        }
        return false;
    }

    protected void copyResourcePacks(Interfaces interfaces) {
        File ressourcePackFile = null;
        switch (interfaces){
            case MODDED: ressourcePackFile = new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "resourcepacks"); break;
            case VANILLA: ressourcePackFile = new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "resourcepacks"); break;
            case UNIVERSAL: ressourcePackFile = new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "resourcepacks"); break;
        }
        if(ressourcePackFile == null){
            return;
        }
        if(ressourcePackFile.listFiles() != null){
            createResourcePackFile("1.8.9");
            createResourcePackFile("1.9.4");
            createResourcePackFile("1.10.2");
            createResourcePackFile("1.11.2");
            createResourcePackFile("1.12.2");
            createResourcePackFile("1.13.2");
            createResourcePackFile("1.14.4");
            for(File file : ressourcePackFile.listFiles()){
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.8.9/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.8.9/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.9.4/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.9.4/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.10.2/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.10.2/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.11.2/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.11.2/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.12.2/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.12.2/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.13.2/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.13.2/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.14.4/resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.14.4/resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "resourcepacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "resourcepacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "resourcepacks/"+file.getName()), true);
                }
            }
        }
    }

    protected void copyShaders(Interfaces interfaces) {
        File shaderpacksFile = null;
        switch (interfaces){
            case MODDED: shaderpacksFile = new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "shaderpacks"); break;
            case VANILLA: shaderpacksFile = new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "shaderpacks"); break;
        }
        if(shaderpacksFile == null){
            return;
        }
        if(shaderpacksFile.listFiles() != null){
            for(File file : shaderpacksFile.listFiles()){
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "shaderpacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "shaderpacks/"+file.getName()), true);
                }
                if(file.length() != new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "shaderpacks/"+file.getName()).length()){
                    Utils.copyFile(file, new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "shaderpacks/"+file.getName()), true);
                }
            }
        }
    }

    protected void createResourcePackFile(String version){
        File file = new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/"+version+"/resourcepacks");
        if(!file.exists()){
            file.mkdirs();
        }
    }

    public Thread getShaderThread() {
        return shaderThread;
    }

    public Thread getUpdateThread() {
        return updateThread;
    }

    public Thread getInformationThread() {
        return Main.INSTANCE.getHuntiesConnection().getUpdaterCommon().informationThread;
    }

    protected void setDone(boolean done) {
        Main.INSTANCE.getHuntiesConnection().isUpdating = done;
    }
}
