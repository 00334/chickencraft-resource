package fr.naruse.hunties.launcher.main.connector;

import fr.litarvan.openauth.AuthPoints;
import fr.litarvan.openauth.AuthenticationException;
import fr.litarvan.openauth.Authenticator;
import fr.litarvan.openauth.model.AuthAgent;
import fr.litarvan.openauth.model.response.AuthResponse;
import fr.naruse.hunties.launcher.event.ConnexionButtonAction;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.game.GameInterfaceManager;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.openlauncherlib.minecraft.AuthInfos;

import javax.swing.*;

public class ConnectorPremium extends AbstractConnector {
    public ConnectorPremium(HuntiesPanel huntiesPanel) {
        super(huntiesPanel);
    }

    @Override
    public void connexion(ConnexionButtonAction connexionButtonAction) {
        super.connexion(connexionButtonAction);
        new Thread() {
            @Override
            public void run() {
                super.run();
                connexionButtonAction.setConnected(true);
                huntiesPanel.setInfoText("Tentative de connexion...");
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                if(!connexion(UtilsInterfaceManager.getInterfaceConnexion().getPUsernameField().getText(), UtilsInterfaceManager.getInterfaceConnexion().getPPasswordField().getText())){
                    huntiesPanel.setInfoText("Connecte-toi pour jouer!");
                    connexionButtonAction.setConnected(false);
                    return;
                }
                huntiesPanel.setInfoText("Connecté : "+ UtilsInterfaceManager.getInterfaceConnexion().getPUsernameField().getText());
                UtilsInterfaceManager.setPseudo(UtilsInterfaceManager.getInterfaceConnexion().getPUsernameField().getText());
                UtilsInterfaceManager.getInterfaceConnexion().savePassAndName();
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                AuthenticatorInfos.USERNAME = UtilsInterfaceManager.getInterfaceConnexion().getPUsernameField().getText();
                AuthenticatorInfos.PREMIUM_USERNAME = UtilsInterfaceManager.getInterfaceConnexion().getPUsernameField().getText();
                AuthenticatorInfos.PREMIUM_PASSWORD = UtilsInterfaceManager.getInterfaceConnexion().getPPasswordField().getText();
                GameInterfaceManager.State.setInterfaceEnabled(Interfaces.UNIVERSAL);
            }
        }.start();
    }

    private boolean connexion(String username, String password) {
        try {
            Authenticator authenticator = new Authenticator(Authenticator.MOJANG_AUTH_URL, AuthPoints.NORMAL_AUTH_POINTS);
            AuthResponse rep = authenticator.authenticate(AuthAgent.MINECRAFT, username, password, "");
            AuthenticatorInfos.PREMIUM_AUTH = new AuthInfos(rep.getSelectedProfile().getName(), rep.getAccessToken(), rep.getSelectedProfile().getId());
        } catch (AuthenticationException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(huntiesPanel, "Erreur, Impossible de se connecter : identifiant ou mot de passe incorrect !", "Erreur", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
}
