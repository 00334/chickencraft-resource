package fr.naruse.hunties.launcher.main.connector;

public enum Connectors {

    HUNTIES(),
    PREMIUM(),
    CRACK(),;

}
