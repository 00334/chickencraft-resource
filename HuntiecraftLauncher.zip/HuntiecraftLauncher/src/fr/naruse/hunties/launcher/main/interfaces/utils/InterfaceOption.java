package fr.naruse.hunties.launcher.main.interfaces.utils;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.AbstractInterface;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.selector.GameConfigurationSelector;
import fr.naruse.hunties.launcher.selector.InstallationPathSelector;
import fr.naruse.hunties.launcher.selector.RamBoxesSelector;
import fr.naruse.hunties.launcher.option.OptionsFrame2;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import java.awt.*;

public class InterfaceOption extends AbstractInterface implements SwingerEventListener {
    private RamBoxesSelector ramBoxesSelector;
    private GameConfigurationSelector gameConfigurationSelector;
    private InstallationPathSelector installationPathSelector;

    private STexturedButton moreOptions = new STexturedButton(Swinger.getResource("button/moreOptions.png"));
    public InterfaceOption(HuntiesPanel huntiesPanel) {
        super(huntiesPanel, Interfaces.OPTION);
        this.ramBoxesSelector = new RamBoxesSelector(huntiesPanel);
        this.gameConfigurationSelector = new GameConfigurationSelector(huntiesPanel);
        this.installationPathSelector = new InstallationPathSelector(huntiesPanel);

        moreOptions.setBounds(185, 260+165*2+10);
        moreOptions.setVisible(false);
        huntiesPanel.add(moreOptions);
        moreOptions.addEventListener(this);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if(enabled){
            ramBoxesSelector.setVisible(true);
            gameConfigurationSelector.setVisible(true);
            installationPathSelector.setVisible(true);
            moreOptions.setVisible(true);
        }else{
            ramBoxesSelector.setVisible(false);
            gameConfigurationSelector.setVisible(false);
            installationPathSelector.setVisible(false);
            moreOptions.setVisible(false);
        }
    }

    public RamBoxesSelector getRamBoxesSelector() {
        return ramBoxesSelector;
    }

    public GameConfigurationSelector getGameConfigurationSelector() {
        return gameConfigurationSelector;
    }

    public InstallationPathSelector getInstallationPathSelector() {
        return installationPathSelector;
    }

    @Override
    public void onEvent(SwingerEvent e) {
        if(e.getSource() == moreOptions){
            UtilsInterfaceManager.State.setInterfaceEnabled(null);
            new OptionsFrame2(getHuntiesPanel());
        }
    }
}
