package fr.naruse.hunties.launcher.main.interfaces;

import java.awt.*;

public interface IInterface {

    void paintComponent(Graphics g);
}
