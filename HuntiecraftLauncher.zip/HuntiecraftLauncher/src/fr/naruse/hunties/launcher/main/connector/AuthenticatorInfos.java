package fr.naruse.hunties.launcher.main.connector;

import fr.theshark34.openlauncherlib.minecraft.AuthInfos;

public class AuthenticatorInfos {
    public static String HUNTIES_USERNAME, PREMIUM_USERNAME, CRACK_USERNAME;
    public static String HUNTIES_PASSWORD, PREMIUM_PASSWORD;
    public static String USERNAME;

    public static AuthInfos PREMIUM_AUTH, CRACK_AUTH;
}
