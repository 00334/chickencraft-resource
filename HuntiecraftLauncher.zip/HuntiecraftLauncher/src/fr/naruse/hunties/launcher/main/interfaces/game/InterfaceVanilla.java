package fr.naruse.hunties.launcher.main.interfaces.game;

import fr.naruse.hunties.launcher.event.LaunchButtonAction;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.connector.Connectors;
import fr.naruse.hunties.launcher.main.interfaces.AbstractInterface;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import java.awt.*;

public class InterfaceVanilla extends AbstractInterface {
    private STexturedButton launchButton = new STexturedButton(Swinger.getResource("button/launchsButton.png"));
    private STexturedButton launchButtonHover = new STexturedButton(Swinger.getResource("button/launchsButtonHover.png"));
    private LaunchButtonAction launchButtonAction;
    public InterfaceVanilla(HuntiesPanel huntiesPanel) {
        super(huntiesPanel, Interfaces.VANILLA);
        launchButtonAction = new LaunchButtonAction(huntiesPanel, launchButton, launchButtonHover, new Connectors[] {Connectors.PREMIUM, Connectors.CRACK});
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if(enabled){
            launchButtonHover.setVisible(false);
            launchButton.setVisible(true);
        }else{
            launchButtonHover.setVisible(false);
            launchButton.setVisible(false);
        }
    }

    public LaunchButtonAction getLaunchButtonAction() {
        return launchButtonAction;
    }
}
