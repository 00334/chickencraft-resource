package fr.naruse.hunties.launcher.main.interfaces.game;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.AbstractInterface;
import fr.naruse.hunties.launcher.main.interfaces.IInterface;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.state.ServerStateInfo;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class GameInterfaceManager implements IInterface, SwingerEventListener, MouseListener {

    private InterfaceModded interfaceModded;
    private InterfaceVanilla interfaceVanilla;
    private InterfaceUniversal interfaceUniversal;

    private AbstractInterface currentInterface;

    private HuntiesPanel huntiesPanel;
    private static GameInterfaceManager INTERFACE_MANAGER;

    private STexturedButton moddedButton = new STexturedButton(Interfaces.MODDED.getButtonImage());
    private STexturedButton vanillaButton = new STexturedButton(Interfaces.VANILLA.getButtonImage());
    private STexturedButton universalButton = new STexturedButton(Interfaces.UNIVERSAL.getButtonImage());
    private STexturedButton moddedHover = new STexturedButton(Interfaces.MODDED.getHoverImage());
    private STexturedButton vanillaHover = new STexturedButton(Interfaces.VANILLA.getHoverImage());
    private STexturedButton universalHover = new STexturedButton(Interfaces.UNIVERSAL.getHoverImage());

    private ServerStateInfo serverStateInfo;

    private boolean areButtonsVisible = true;
    public GameInterfaceManager(HuntiesPanel panel) {
        INTERFACE_MANAGER = this;
        this.huntiesPanel = panel;
        this.serverStateInfo = new ServerStateInfo("https://huntiescraft.net/public/launcher/options/server_state.json");
        this.interfaceModded = new InterfaceModded(huntiesPanel);
        this.interfaceVanilla = new InterfaceVanilla(huntiesPanel);
        this.interfaceUniversal = new InterfaceUniversal(huntiesPanel);

        moddedButton.setBounds(105, 0);
        vanillaButton.setBounds(340, 0);
        universalButton.setBounds(575, 0);
        huntiesPanel.add(moddedButton);
        huntiesPanel.add(vanillaButton);
        huntiesPanel.add(universalButton);
        moddedButton.addEventListener(this);
        vanillaButton.addEventListener(this);
        universalButton.addEventListener(this);
        moddedButton.addMouseListener(this);
        vanillaButton.addMouseListener(this);
        universalButton.addMouseListener(this);

        moddedHover.setBounds(105, 0);
        vanillaHover.setBounds(340, 0);
        universalHover.setBounds(575, 0);
        moddedHover.setVisible(false);
        vanillaHover.setVisible(false);
        universalHover.setVisible(false);
        huntiesPanel.add(moddedHover);
        huntiesPanel.add(vanillaHover);
        huntiesPanel.add(universalHover);
        moddedHover.addEventListener(this);
        vanillaHover.addEventListener(this);
        universalHover.addEventListener(this);
        moddedHover.addMouseListener(this);
        vanillaHover.addMouseListener(this);
        universalHover.addMouseListener(this);

        State.setInterfaceEnabled(Interfaces.MODDED);
    }

    public static void setButtonVisible(boolean areVisible) {
        if (areVisible) {
            INTERFACE_MANAGER.areButtonsVisible = true;
            if(State.getEnabledInterface() != Interfaces.MODDED){
                INTERFACE_MANAGER.moddedHover.setVisible(false);
                INTERFACE_MANAGER.moddedButton.setVisible(true);
                INTERFACE_MANAGER.interfaceModded.getLaunchButtonAction().setVisible(true);
            }else{
                INTERFACE_MANAGER.moddedHover.setVisible(true);
                INTERFACE_MANAGER.moddedButton.setVisible(false);
            }
            if(State.getEnabledInterface() != Interfaces.VANILLA){
                INTERFACE_MANAGER.vanillaHover.setVisible(false);
                INTERFACE_MANAGER.vanillaButton.setVisible(true);
                INTERFACE_MANAGER.interfaceVanilla.getLaunchButtonAction().setVisible(true);
            }else{
                INTERFACE_MANAGER.vanillaHover.setVisible(true);
                INTERFACE_MANAGER.vanillaButton.setVisible(false);
            }
            if(State.getEnabledInterface() != Interfaces.UNIVERSAL){
                INTERFACE_MANAGER.universalHover.setVisible(false);
                INTERFACE_MANAGER.universalButton.setVisible(true);
                INTERFACE_MANAGER.interfaceUniversal.getLaunchButtonAction().setVisible(true);
            }else{
                INTERFACE_MANAGER.universalHover.setVisible(true);
                INTERFACE_MANAGER.universalButton.setVisible(false);
            }
            INTERFACE_MANAGER.huntiesPanel.getProgressBar().setVisible(true);
            INTERFACE_MANAGER.huntiesPanel.getInfoLabel().setVisible(true);
            INTERFACE_MANAGER.serverStateInfo.setVisible(true);
        }else{
            INTERFACE_MANAGER.areButtonsVisible = false;
            INTERFACE_MANAGER.moddedButton.setVisible(false);
            INTERFACE_MANAGER.moddedHover.setVisible(false);
            INTERFACE_MANAGER.vanillaButton.setVisible(false);
            INTERFACE_MANAGER.vanillaHover.setVisible(false);
            INTERFACE_MANAGER.universalButton.setVisible(false);
            INTERFACE_MANAGER.universalHover.setVisible(false);

            INTERFACE_MANAGER.huntiesPanel.getProgressBar().setVisible(false);
            INTERFACE_MANAGER.huntiesPanel.getInfoLabel().setVisible(false);
            INTERFACE_MANAGER.interfaceModded.getLaunchButtonAction().setVisible(false);
            INTERFACE_MANAGER.interfaceVanilla.getLaunchButtonAction().setVisible(false);
            INTERFACE_MANAGER.interfaceUniversal.getLaunchButtonAction().setVisible(false);

            INTERFACE_MANAGER.serverStateInfo.setVisible(false);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        currentInterface.paintComponent(g);
    }

    @Override
    public void onEvent(SwingerEvent e) {
        if(e.getSource() == moddedHover){
            if(!(currentInterface instanceof InterfaceModded)){
                State.setInterfaceEnabled(Interfaces.MODDED);
            }
        }
        if(e.getSource() == vanillaHover){
            if(!(currentInterface instanceof InterfaceVanilla)){
                State.setInterfaceEnabled(Interfaces.VANILLA);
            }
        }
        if(e.getSource() == universalHover){
            if(!(currentInterface instanceof InterfaceUniversal)){
                State.setInterfaceEnabled(Interfaces.UNIVERSAL);
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if(e.getSource() == moddedButton){
            if(!moddedHover.isVisible()){
                moddedButton.setVisible(false);
                moddedHover.setVisible(true);
            }
        }else if(e.getSource() == vanillaButton){
            if(!vanillaHover.isVisible()){
                vanillaButton.setVisible(false);
                vanillaHover.setVisible(true);
            }
        }else if(e.getSource() == universalButton){
            if(!universalHover.isVisible()){
                universalButton.setVisible(false);
                universalHover.setVisible(true);
            }
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(e.getSource() == moddedHover){
            if(State.getEnabledInterface() == Interfaces.MODDED){
                return;
            }
            moddedHover.setVisible(false);
            moddedButton.setVisible(true);
        }else if(e.getSource() == vanillaHover){
            if(State.getEnabledInterface() == Interfaces.VANILLA){
                return;
            }
            vanillaHover.setVisible(false);
            vanillaButton.setVisible(true);
        }else if(e.getSource() == universalHover){
            if(State.getEnabledInterface() == Interfaces.UNIVERSAL){
                return;
            }
            universalHover.setVisible(false);
            universalButton.setVisible(true);
        }
    }

    public static class State{
        private static boolean isModdedEnabled = true, isVanillaEnabled = false, isUniversalEnabled = true;

        public static Interfaces getEnabledInterface(){
            if(isModdedEnabled){
                return Interfaces.MODDED;
            }
            if(isVanillaEnabled){
                return Interfaces.VANILLA;
            }
            if(isUniversalEnabled){
                return Interfaces.UNIVERSAL;
            }
            return null;
        }

        public static void setInterfaceEnabled(Interfaces interfaces){
            switch (interfaces){
                case MODDED:{
                    INTERFACE_MANAGER.interfaceModded.setEnabled(true);
                    INTERFACE_MANAGER.interfaceVanilla.setEnabled(false);
                    INTERFACE_MANAGER.interfaceUniversal.setEnabled(false);
                    INTERFACE_MANAGER.currentInterface = INTERFACE_MANAGER.interfaceModded;
                    INTERFACE_MANAGER.moddedButton.setVisible(false);
                    INTERFACE_MANAGER.moddedHover.setVisible(true);
                    INTERFACE_MANAGER.vanillaButton.setVisible(true);
                    INTERFACE_MANAGER.vanillaHover.setVisible(false);
                    INTERFACE_MANAGER.universalButton.setVisible(true);
                    INTERFACE_MANAGER.universalHover.setVisible(false);
                    isModdedEnabled = true;
                    isVanillaEnabled  = false;
                    isUniversalEnabled = false;
                    break;
                }
                case VANILLA:{
                    INTERFACE_MANAGER.interfaceModded.setEnabled(false);
                    INTERFACE_MANAGER.interfaceVanilla.setEnabled(true);
                    INTERFACE_MANAGER.interfaceUniversal.setEnabled(false);
                    INTERFACE_MANAGER.currentInterface = INTERFACE_MANAGER.interfaceVanilla;
                    INTERFACE_MANAGER.vanillaButton.setVisible(false);
                    INTERFACE_MANAGER.vanillaHover.setVisible(true);
                    INTERFACE_MANAGER.moddedButton.setVisible(true);
                    INTERFACE_MANAGER.moddedHover.setVisible(false);
                    INTERFACE_MANAGER.universalButton.setVisible(true);
                    INTERFACE_MANAGER.universalHover.setVisible(false);
                    isModdedEnabled = false;
                    isVanillaEnabled  = true;
                    isUniversalEnabled = false;
                    break;
                }
                case UNIVERSAL:{
                    INTERFACE_MANAGER.interfaceModded.setEnabled(false);
                    INTERFACE_MANAGER.interfaceVanilla.setEnabled(false);
                    INTERFACE_MANAGER.interfaceUniversal.setEnabled(true);
                    INTERFACE_MANAGER.currentInterface = INTERFACE_MANAGER.interfaceUniversal;
                    INTERFACE_MANAGER.universalButton.setVisible(false);
                    INTERFACE_MANAGER.universalHover.setVisible(true);
                    INTERFACE_MANAGER.moddedButton.setVisible(true);
                    INTERFACE_MANAGER.moddedHover.setVisible(false);
                    INTERFACE_MANAGER.vanillaButton.setVisible(true);
                    INTERFACE_MANAGER.vanillaHover.setVisible(false);
                    isModdedEnabled = false;
                    isVanillaEnabled  = false;
                    isUniversalEnabled = true;
                    break;
                }
            }
            if(INTERFACE_MANAGER.huntiesPanel.getGraphics() != null){
               INTERFACE_MANAGER.huntiesPanel.repaint();
            }
            //System.out.println("[HuntiesLauncher] GameInterfaceManager : interface '"+interfaces.name()+"' loaded.");
        }

        public static boolean isModdedEnabled() {
            return isModdedEnabled;
        }

        public static boolean isUniversalEnabled() {
            return isUniversalEnabled;
        }

        public static boolean isVanillaEnabled() {
            return isVanillaEnabled;
        }
    }
}
