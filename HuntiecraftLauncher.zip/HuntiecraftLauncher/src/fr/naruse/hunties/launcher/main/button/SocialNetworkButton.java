package fr.naruse.hunties.launcher.main.button;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class SocialNetworkButton implements MouseListener {
    private JButton button;
    private JButton hover;
    private String link;
    public SocialNetworkButton(HuntiesPanel huntiesPanel, STexturedButton sButton, STexturedButton sHover,  String link, int x, int y) {
        this.button = new JButton(new ImageIcon(sButton.getTexture()));
        this.hover = new JButton(new ImageIcon(sHover.getTexture()));
        this.link = link;
        button.setBounds(x, y, 50, 50);
        button.addMouseListener(this);
        button.setBorder(BorderFactory.createEmptyBorder());
        button.setContentAreaFilled(false);
        huntiesPanel.add(button);
        hover.setBounds(x, y, 50, 50);
        hover.addMouseListener(this);
        hover.setBorder(BorderFactory.createEmptyBorder());
        hover.setContentAreaFilled(false);
        huntiesPanel.add(hover);
        hover.setVisible(false);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(link.equalsIgnoreCase("")){
            return;
        }
        if(Desktop.isDesktopSupported()){
            try {
                Desktop.getDesktop().browse(new URI(link));
            } catch (IOException e1) {
                e1.printStackTrace();
            } catch (URISyntaxException e1) {
                e1.printStackTrace();
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        button.setVisible(false);
        hover.setVisible(true);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        button.setVisible(true);
        hover.setVisible(false);
    }
}
