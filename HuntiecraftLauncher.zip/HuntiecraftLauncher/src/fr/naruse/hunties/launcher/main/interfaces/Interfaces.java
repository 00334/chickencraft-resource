package fr.naruse.hunties.launcher.main.interfaces;

import fr.naruse.hunties.launcher.main.HuntiesPanel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

public enum Interfaces {

    MODDED("images/interfaces/interfaceModded.png", "images/interfaces/hover/moddedHovers.png", "images/interfaces/button/moddedButtons.png"),
    VANILLA("images/interfaces/interfaceVanillas.png", "images/interfaces/hover/vanillaHovers.png", "images/interfaces/button/vanillaButtons.png"),
    UNIVERSAL("images/interfaces/interfaceUniversals.png", "images/interfaces/hover/universalHovers.png", "images/interfaces/button/universalButtons.png"),

    DOWNLOAD("images/interfaces/interfaceDownloads.png", "images/interfaces/button/downloadButtons.png", "images/interfaces/hover/downloadHover.png"),
    OPTION("images/interfaces/interfaceOption.png", "images/interfaces/button/optionsButton.png", "images/interfaces/hover/optionsHover.png"),
    CONNEXION("images/interfaces/interfacesConnexion.png", "images/interfaces/button/connexionButton.png", "images/interfaces/hover/connexionHover.png");

    private String iPath, bPath, hHover;
    private BufferedImage iBufferedImage, bBufferedImage, hBufferedImage;
    Interfaces(String iPath, String bPath, String hHover) {
        this.iPath = iPath;
        this.bPath = bPath;
        this.hHover = hHover;
        try {
            this.iBufferedImage = ImageIO.read(HuntiesPanel.class.getResourceAsStream(iPath));
            this.bBufferedImage = ImageIO.read(HuntiesPanel.class.getResourceAsStream(bPath));
            this.hBufferedImage = ImageIO.read(HuntiesPanel.class.getResourceAsStream(hHover));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getInterfacePath() {
        return iPath;
    }

    public String getButtonPath() {
        return bPath;
    }

    public String getHoverPath() {
        return hHover;
    }

    public BufferedImage getInterfaceImage() {
        return iBufferedImage;
    }

    public BufferedImage getButtonImage() {
        return bBufferedImage;
    }

    public BufferedImage getHoverImage() {
        return hBufferedImage;
    }
}
