package fr.naruse.hunties.launcher.main.printer;

import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public abstract class Printer {
    private Interfaces interfaces;
    private List<String> list = new ArrayList<>();
    public Printer(Interfaces interfaces) {
        this.interfaces = interfaces;
        run();
    }

    public abstract void run();

    public void addFile(String name){
        list.add(name);
    }

    public List<String> getList() {
        return list;
    }

    private boolean contains(String name){
        for(String fileName : list){
            if(fileName.equalsIgnoreCase(name)){
                return true;
            }
        }
        return false;
    }

    public void print(File from, File dest){
        if(from.listFiles() == null){
            return;
        }
        for(File downloadedFile : from.listFiles()){
            File f = new File(dest, downloadedFile.getName());
            if(contains(downloadedFile.getName())){
                checkInFile(downloadedFile, f);
            }
        }
    }

    private File checkInFile(File file, File dest){
        if(file.listFiles() != null){
            for(File f : file.listFiles()){
                checkInFile(f, new File(dest, f.getName()));
            }
        }else{
            if(dest.exists()){
                if(file.length() != dest.length()){
                    System.out.println("[HuntiesLauncher] Copying "+file.getName()+" to "+dest.getPath());
                    Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Copie du fichier '"+file.getName()+"'...");
                    dest.delete();
                    Utils.copyFile(file, dest);
                }
            }else{
                System.out.println("[HuntiesLauncher] Copying "+file.getName()+" to "+dest.getPath());
                Main.INSTANCE.getHuntiesFrame().getHuntiesPanel().setInfoText("Copie du fichier '"+file.getName()+"'...");
                Utils.copyFile(file, dest);
            }
        }
        return null;
    }

    public static Printer MODDED = new Printer(Interfaces.MODDED){

        @Override
        public void run() {
            addFile("configurations");
            addFile("images");
            addFile("natives");
            addFile("zipFiles");
            addFile("minecraft.jar");
        }
    };

    public static Printer UNIVERSAL = new Printer(Interfaces.UNIVERSAL){

        @Override
        public void run() {
            addFile("natives");
        }
    };
}
