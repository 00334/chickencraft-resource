package fr.naruse.hunties.launcher.main.connector;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import fr.naruse.hunties.launcher.discord.DiscordEventHandler;
import fr.naruse.hunties.launcher.event.ConnexionButtonAction;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.game.GameInterfaceManager;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;

import javax.swing.*;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;

public class ConnectorModded extends AbstractConnector {
    public ConnectorModded(HuntiesPanel huntiesPanel) {
        super(huntiesPanel);
    }

    @Override
    public void connexion(ConnexionButtonAction connexionButtonAction){
        super.connexion(connexionButtonAction);
        new Thread() {
            @Override
            public void run() {
                super.run();
                huntiesPanel.setInfoText("Tentative de connexion...");
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                String username = UtilsInterfaceManager.getInterfaceConnexion().getHUsernameField().getText();
                String password = UtilsInterfaceManager.getInterfaceConnexion().getHPasswordField().getText();
                if(!connexion(UtilsInterfaceManager.getInterfaceConnexion().getHUsernameField().getText(), UtilsInterfaceManager.getInterfaceConnexion().getHPasswordField().getText())){
                    huntiesPanel.setInfoText("Connecte-toi pour jouer!");
                    connexionButtonAction.setConnected(false);
                    JOptionPane.showMessageDialog(huntiesPanel, "Impossible de se connecter ! Verifier votre pseudonyme et votre mot de passe.");
                    return;
                }
                huntiesPanel.getSkinLocator().setName(username);
                huntiesPanel.setInfoText("Connecté : "+ username);
                UtilsInterfaceManager.setPseudo(username);
                UtilsInterfaceManager.getInterfaceConnexion().savePassAndName();
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                AuthenticatorInfos.USERNAME = username;
                AuthenticatorInfos.HUNTIES_USERNAME = username;
                AuthenticatorInfos.HUNTIES_PASSWORD = password;
                connexionButtonAction.setConnected(true);
                if(GameInterfaceManager.State.getEnabledInterface() == Interfaces.UNIVERSAL){
                    GameInterfaceManager.State.setInterfaceEnabled(Interfaces.MODDED);
                }

            }
        }.start();
    }

    private boolean connexion(String username, String password){
        DiscordEventHandler.inConnection();
        File dest = new File(Main.INSTANCE.getHuntiesConnection().DIR, "exists.json");
        try {
            URLConnection connection = new URL("http://huntiescraft.net/api/trixauth/check/?pseudo="+username+"&password="+password).openConnection();
            connection.addRequestProperty("Accept", "application/json");
            connection.addRequestProperty("Connection", "close");
            connection.addRequestProperty("Content-Encoding", "gzip");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
            connection.setDoOutput(true);
            DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
            outputStream.flush();
            outputStream.close();

            InputStream is = connection.getInputStream();
            try (BufferedInputStream in = new BufferedInputStream(is);
                 FileOutputStream fileOutputStream = new FileOutputStream(dest)) {
                byte dataBuffer[] = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                    fileOutputStream.write(dataBuffer, 0, bytesRead);
                }
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }

            JsonParser jsonParser = new JsonParser();
            JsonObject jsonObject = (JsonObject) jsonParser.parse(new JsonReader(new FileReader(dest)));
            boolean result = jsonObject.get("exists").getAsBoolean();
            if(GameInterfaceManager.State.getEnabledInterface() == Interfaces.UNIVERSAL){
                GameInterfaceManager.State.setInterfaceEnabled(Interfaces.MODDED);
            }
            DiscordEventHandler.inCheckingFiles();
            dest.delete();
            return result;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
