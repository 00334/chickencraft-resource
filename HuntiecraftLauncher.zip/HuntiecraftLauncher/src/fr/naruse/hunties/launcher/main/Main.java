package fr.naruse.hunties.launcher.main;

import fr.naruse.hunties.launcher.discord.Discord;
import fr.naruse.hunties.launcher.game.GameManager;
import fr.naruse.hunties.launcher.memory.MemoryHandler;
import fr.naruse.hunties.launcher.utils.log.HuntiesOutputStream;
import fr.naruse.hunties.launcher.utils.log.LogFrame;
import fr.naruse.hunties.launcher.utils.updater.LauncherUpdater;
import fr.naruse.hunties.launcher.utils.HuntiesOption;
import fr.naruse.hunties.launcher.utils.SqlConnection;
import fr.naruse.hunties.launcher.video.VideoManager;
import fr.theshark34.swinger.Swinger;
import net.arikia.dev.drpc.DiscordRichPresence;

import javax.swing.*;
import java.io.File;
import java.io.PrintStream;

public class Main {
    public static Main INSTANCE;
    public static void main(String[] args){
        try {
            new Main();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private HuntiesFrame huntiesFrame;
    private HuntiesConnection huntiesConnection;
    private HuntiesOption huntiesOption;
    private SqlConnection sqlConnection;
    private Discord discord;
    private VideoManager videoManager;
    private GameManager gameManager;
    private LauncherUpdater launcherUpdater;
    private LogFrame logFrame;
    private HuntiesOutputStream huntiesOutputStream;
    public Main() throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {

        INSTANCE = this;

        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        Swinger.setSystemLookNFeel();
        Swinger.setResourcePath("/fr/naruse/hunties/launcher/main/images/");

        this.huntiesConnection = new HuntiesConnection(this);
        this.huntiesOption = new HuntiesOption(new File(huntiesConnection.DIR, "launcher_settings.txt"));

        if(Boolean.valueOf(huntiesOption.getString("enableLogs"))){
            this.logFrame = new LogFrame();
            PrintStream printStream;
            System.setOut(printStream = new PrintStream(huntiesOutputStream = new HuntiesOutputStream()));
            System.setErr(printStream);
            huntiesOutputStream.setLogFrame(logFrame);
        }
        //this.sqlConnection = new SqlConnection();
        //this.sqlConnection = new SqlConnection("jdbc:mysql://","localhost", "grades", "root", "");
        this.sqlConnection = new SqlConnection("jdbc:mysql://","ba1050353-002.dbaas.ovh.net:35932", "BDD_Launcher", "NaruseII", "LOGH251e40fesgliugLUIG2e10geq");
        this.huntiesFrame = new HuntiesFrame(this);
        this.discord = new Discord(new DiscordRichPresence());
        huntiesConnection.CRASH_FOLDER.mkdirs();
        this.videoManager = new VideoManager(this);
        this.gameManager = new GameManager(this);
        this.launcherUpdater = new LauncherUpdater(this);
        new MemoryHandler();
        //new LauncherCleaner(this);
        //new MusicFrame(this);
    }

    public HuntiesFrame getHuntiesFrame() {
        return huntiesFrame;
    }

    public HuntiesConnection getHuntiesConnection() {
        return huntiesConnection;
    }

    public HuntiesOption getHuntiesOption() {
        return huntiesOption;
    }

    public SqlConnection getSqlConnection() {
        return sqlConnection;
    }

    public Discord getDiscord() {
        return discord;
    }

    public VideoManager getVideoManager() {
        return videoManager;
    }

    public GameManager getGameManager() {
        return gameManager;
    }

    public LauncherUpdater getLauncherUpdater() {
        return launcherUpdater;
    }

    public LogFrame getLogFrame() {
        return logFrame;
    }

    public void setLogFrame(LogFrame logFrame) {
        this.logFrame = logFrame;
    }
}
