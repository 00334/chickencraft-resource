package fr.naruse.hunties.launcher.main;

import fr.naruse.hunties.launcher.main.updater.AbstractUpdater;
import fr.naruse.hunties.launcher.main.updater.UpdaterCommon;
import fr.naruse.hunties.launcher.utils.Utils;
import fr.theshark34.openlauncherlib.minecraft.GameInfos;
import fr.theshark34.openlauncherlib.minecraft.GameTweak;
import fr.theshark34.openlauncherlib.minecraft.GameType;
import fr.theshark34.openlauncherlib.minecraft.GameVersion;

import javax.swing.*;
import java.io.*;

public class HuntiesConnection {

    private Main main;
    public GameVersion VERSION = new GameVersion("1.12.2", GameType.V1_8_HIGHER);
    public GameInfos INFOS = new GameInfos("HuntiesCraft-Network", VERSION,  new GameTweak[] {GameTweak.FORGE});
    public GameInfos INFOS_UNIVERSAL = new GameInfos("HuntiesCraft-Network", VERSION, new GameTweak[] {});
    public File DIR = INFOS.getGameDir();
    public File INSTALLATION_DIR, MODDED_DIR, VANILLA_DIR, UNIVERSAL_DIR, COMMON_DIR;
    public final File CRASH_FOLDER = new File(DIR, "crashes");

    private AbstractUpdater abstractUpdater;
    private UpdaterCommon updaterCommon;

    public boolean isUpdating = false;
    public HuntiesConnection(Main main) {
        this.main = main;
    }

    public void update(AbstractUpdater abstractUpdater){
        if(!AbstractUpdater.isConnected(abstractUpdater)){
            return;
        }
        if(isUpdating){
            return;
        }
        isUpdating = true;
        this.abstractUpdater = abstractUpdater;
        this.updaterCommon = new UpdaterCommon(main, abstractUpdater);
        System.out.println("[HuntiesLauncher] Starting updater : "+updaterCommon.getClass().getName());
        updaterCommon.update();
    }

    public AbstractUpdater getAbstractUpdater() {
        return abstractUpdater;
    }

    public UpdaterCommon getUpdaterCommon() {
        return updaterCommon;
    }
}
