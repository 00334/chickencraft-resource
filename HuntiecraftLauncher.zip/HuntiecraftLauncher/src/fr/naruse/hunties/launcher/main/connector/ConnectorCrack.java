package fr.naruse.hunties.launcher.main.connector;

import fr.naruse.hunties.launcher.event.ConnexionButtonAction;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.interfaces.Interfaces;
import fr.naruse.hunties.launcher.main.interfaces.game.GameInterfaceManager;
import fr.naruse.hunties.launcher.main.interfaces.utils.UtilsInterfaceManager;
import fr.theshark34.openlauncherlib.minecraft.AuthInfos;

import javax.swing.*;

public class ConnectorCrack extends AbstractConnector {
    public ConnectorCrack(HuntiesPanel huntiesPanel) {
        super(huntiesPanel);
    }

    @Override
    public void connexion(ConnexionButtonAction connexionButtonAction) {
        super.connexion(connexionButtonAction);
        new Thread() {
            @Override
            public void run() {
                super.run();
                connexionButtonAction.setConnected(true);
                huntiesPanel.setInfoText("Tentative de connexion...");
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                if(!connexion(UtilsInterfaceManager.getInterfaceConnexion().getCUsernameField().getText())){
                    huntiesPanel.setInfoText("Connecte-toi pour jouer!");
                    connexionButtonAction.setConnected(false);
                    return;
                }
                huntiesPanel.setInfoText("Connecté : "+ UtilsInterfaceManager.getInterfaceConnexion().getCUsernameField().getText());
                UtilsInterfaceManager.setPseudo(UtilsInterfaceManager.getInterfaceConnexion().getCUsernameField().getText());
                UtilsInterfaceManager.getInterfaceConnexion().savePassAndName();
                UtilsInterfaceManager.State.setInterfaceEnabled(null);
                AuthenticatorInfos.USERNAME = UtilsInterfaceManager.getInterfaceConnexion().getCUsernameField().getText();
                AuthenticatorInfos.CRACK_USERNAME = UtilsInterfaceManager.getInterfaceConnexion().getCUsernameField().getText();
                GameInterfaceManager.State.setInterfaceEnabled(Interfaces.UNIVERSAL);
            }
        }.start();
    }

    private boolean connexion(String username) {
        try {
            AuthenticatorInfos.CRACK_AUTH = new AuthInfos(username, "sry", "nope");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(huntiesPanel, "Erreur, Impossible de vous créer un compte !", "Erreur", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
}
