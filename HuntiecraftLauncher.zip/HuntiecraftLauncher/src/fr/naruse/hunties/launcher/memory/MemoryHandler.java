package fr.naruse.hunties.launcher.memory;

import com.sun.jna.Memory;
import fr.naruse.hunties.launcher.utils.Utils;

public class MemoryHandler {
    public MemoryHandler() {
        new Thread(){
            @Override
            public void run() {
                super.run();
                while (true){
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Runtime.getRuntime().gc();
                    new Memory(Runtime.getRuntime().totalMemory()).clear();
                }
            }
        }.start();
    }
}
