package fr.naruse.hunties.launcher.selector;

import fr.naruse.hunties.launcher.box.HcnCheckBox;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.option.OptionsFrame;
import fr.theshark34.openlauncherlib.util.ramselector.OptionFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

public class InstallationPathSelector implements MouseListener {
    private HcnCheckBox defaut, perso;
    private List<HcnCheckBox> hcnCheckBoxList = new ArrayList<>();
    private JLabel jLabel = new JLabel();
    public InstallationPathSelector(HuntiesPanel huntiesPanel) {
        InstallationPathSelector instance = this;
        new Thread(){
            @Override
            public void run() {
                super.run();
                defaut = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 750-269-19, 18, 19);
                defaut.addTo(huntiesPanel);
                hcnCheckBoxList.add(defaut);
                perso = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 128, 750-269+38, 18, 19);
                perso.addTo(huntiesPanel);
                hcnCheckBoxList.add(perso);
                jLabel.setForeground(new Color(239, 239, 239));
                jLabel.setFont(jLabel.getFont().deriveFont(13f));
                jLabel.setBounds(130, 540, 280, 30);
                huntiesPanel.add(jLabel);
                selectChosenRam(huntiesPanel);
                setVisible(false);
            }
        }.start();
    }

    public void selectChosenRam(HuntiesPanel huntiesPanel) {
        String path = huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().getString("path").replace(";", ":");
        if(defaut.isVisible()){
            if(path.equalsIgnoreCase("default")){
                defaut.setSelected(true);
                perso.setSelected(false);
                jLabel.setVisible(false);
            }else{
                defaut.setSelected(false);
                perso.setSelected(true);
                jLabel.setVisible(true);
                jLabel.setText(path);
            }
        }
    }

    public List<HcnCheckBox> getHcnCheckBoxList() {
        return hcnCheckBoxList;
    }

    public void mouseClicked(HcnCheckBox hcnCheckBox) {
        if(!hcnCheckBoxList.contains(hcnCheckBox)){
            return;
        }
        for(HcnCheckBox checkBox : hcnCheckBoxList){
            if(checkBox != hcnCheckBox){
                checkBox.setSelected(false);
            }
        }
        if(hcnCheckBox == perso){
            new OptionsFrame(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        }
        selectChosenRam(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
    }

    public void setVisible(boolean b) {
        jLabel.setVisible(b);
        for(HcnCheckBox hcnCheckBox : hcnCheckBoxList){
            hcnCheckBox.setVisible(b);
        }
        if(b){
            selectChosenRam(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getX() >= jLabel.getX() && e.getX() <= jLabel.getX()+jLabel.getWidth()){
            if(e.getY() >= jLabel.getY() && e.getY() <= jLabel.getY()+jLabel.getHeight()){
                new OptionsFrame(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
