package fr.naruse.hunties.launcher.selector;

import fr.naruse.hunties.launcher.event.OptionsButtonAction;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

public class RamViewer implements SwingerEventListener {
    private HuntiesPanel huntiesPanel;
    public RamViewer(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
        update();
    }

    public void update(){
        int maxRam = Integer.valueOf(huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().getString("memory"));
        System.out.println("[HuntiesLauncher] Max memory chosen: "+maxRam);
    }

    @Override
    public void onEvent(SwingerEvent e) {
        new OptionsButtonAction(huntiesPanel).onEvent(e);
    }
}
