package fr.naruse.hunties.launcher.selector;

import fr.naruse.hunties.launcher.box.HcnCheckBox;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;
import fr.naruse.hunties.launcher.utils.Utils;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GameConfigurationSelector {
    private HcnCheckBox ultra, middle, basic;
    private List<HcnCheckBox> hcnCheckBoxList = new ArrayList<>();
    public GameConfigurationSelector(HuntiesPanel huntiesPanel) {
        new Thread(){
            @Override
            public void run() {
                super.run();
                ultra = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 68, 18, 19, 0);
                ultra.addTo(huntiesPanel);
                hcnCheckBoxList.add(ultra);
                middle = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 68+19+4, 18, 19, 1);
                middle.addTo(huntiesPanel);
                hcnCheckBoxList.add(middle);
                basic = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 68+(19+4)*2, 18, 19, 2);
                basic.addTo(huntiesPanel);
                hcnCheckBoxList.add(basic);
                selectChosenRam(huntiesPanel);
                setVisible(false);
            }
        }.start();
    }

    private void selectChosenRam(HuntiesPanel huntiesPanel) {
        int maxRam = Integer.valueOf(huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().getString("configuration"));
        switch (maxRam){
            case 0: ultra.setSelected(true); break;
            case 1: middle.setSelected(true); break;
            case 2: basic.setSelected(true); break;
        }
    }

    public List<HcnCheckBox> getHcnCheckBoxList() {
        return hcnCheckBoxList;
    }

    public void mouseClicked(HcnCheckBox hcnCheckBox) {
        if(!hcnCheckBoxList.contains(hcnCheckBox)){
            return;
        }
        for(HcnCheckBox checkBox : hcnCheckBoxList){
            if(checkBox != hcnCheckBox){
                checkBox.setSelected(false);
            }
        }
        File configFile = new File(Main.INSTANCE.getHuntiesConnection().COMMON_DIR, "configurations");
        if(!configFile.exists()){
            configFile.mkdirs();
        }
        int i = JOptionPane.showConfirmDialog(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel(), "Cette action supprimera vos anciennes configurations graphiques !", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        if(i != 0){
            return;
        }
        if(hcnCheckBox == ultra){
            Utils.downloadFile("https://huntiescraft.net/app/webroot/launcher/sides/common/files/configurations/options_ultra.txt", new File(configFile, "options_ultra.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.8.9/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.9.4/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.10.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.11.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.13.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_ultra.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.14.4/optionsof.txt"));
        }else if(hcnCheckBox == middle){
            Utils.downloadFile("https://huntiescraft.net/app/webroot/launcher/sides/common/files/configurations/options_moyen.txt", new File(configFile, "options_moyen.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.8.9/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.9.4/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.10.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.11.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.13.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_moyen.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.14.4/optionsof.txt"));
        }else if(hcnCheckBox == basic){
            Utils.downloadFile("https://huntiescraft.net/app/webroot/launcher/sides/common/files/configurations/options_basique.txt", new File(configFile, "options_basique.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().MODDED_DIR, "optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().VANILLA_DIR, "optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.8.9/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.9.4/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.10.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.11.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.13.2/optionsof.txt"));
            Utils.copyFile(new File(configFile, "options_basique.txt"), new File(Main.INSTANCE.getHuntiesConnection().UNIVERSAL_DIR, "versions/1.14.4/optionsof.txt"));
        }
        save();
    }

    private void save() {
        String memory = null;
        for(HcnCheckBox checkBox : hcnCheckBoxList){
            if(checkBox.isSelected()){
                memory = checkBox.getMemory()+"";
                break;
            }
        }
        if(memory == null){
            hcnCheckBoxList.get(0).setSelected(true);
            System.out.println("[HuntiesLauncher] Can't save memory.");
            return;
        }
        Main.INSTANCE.getHuntiesOption().setString("configuration", memory);
        System.out.println("[HuntiesLauncher] Configuration chosen: "+memory);
    }

    public void setVisible(boolean b) {
        for(HcnCheckBox hcnCheckBox : hcnCheckBoxList){
            hcnCheckBox.setVisible(b);
        }
        if(b){
            selectChosenRam(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        }
    }
}
