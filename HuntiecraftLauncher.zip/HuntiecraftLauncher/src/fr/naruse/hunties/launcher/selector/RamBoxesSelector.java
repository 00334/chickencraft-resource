package fr.naruse.hunties.launcher.selector;

import fr.naruse.hunties.launcher.box.HcnCheckBox;
import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;

import java.util.ArrayList;
import java.util.List;

public class RamBoxesSelector {
    private HcnCheckBox ram1GB, ram2GB, ram3GB, ram4GB, ram5GB, ram6GB, ram7GB, ram8GB, ram9GB;
    private List<HcnCheckBox> hcnCheckBoxList = new ArrayList<>();
    public RamBoxesSelector(HuntiesPanel huntiesPanel) {
        ram1GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200, 18, 19, 1024);
        ram1GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram1GB);
        ram2GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+19+4, 18, 19, 1024*2);
        ram2GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram2GB);
        ram3GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*2, 18, 19, 1024*3);
        ram3GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram3GB);
        ram4GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*3, 18, 19, 1024*4);
        ram4GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram4GB);
        ram5GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*4, 18, 19, 1024*5);
        ram5GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram5GB);
        ram6GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*5, 18, 19, 1024*6);
        ram6GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram6GB);
        ram7GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*6, 18, 19, 1024*7);
        ram7GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram7GB);
        ram8GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*6+19+3, 18, 19, 1024*8);
        ram8GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram8GB);
        ram9GB = new HcnCheckBox("box/checkBoxEmpty.png", "box/checkBoxSelected.png", 129, 200+(19+4)*7+19+3, 18, 19, 1024*9);
        ram9GB.addTo(huntiesPanel);
        hcnCheckBoxList.add(ram9GB);
        selectChosenRam(huntiesPanel);
        setVisible(false);
    }

    private void selectChosenRam(HuntiesPanel huntiesPanel) {
        int maxRam = Integer.valueOf(huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().getString("memory"));
        switch (maxRam){
            case 512: ram1GB.setSelected(true); break;
            case 1024: ram1GB.setSelected(true); break;
            case 1024*2: ram2GB.setSelected(true); break;
            case 1024*3: ram3GB.setSelected(true); break;
            case 1024*4: ram4GB.setSelected(true); break;
            case 1024*5: ram5GB.setSelected(true); break;
            case 1024*6: ram6GB.setSelected(true); break;
            case 1024*7: ram7GB.setSelected(true); break;
            case 1024*8: ram8GB.setSelected(true); break;
            case 1024*9: ram9GB.setSelected(true); break;
        }
    }

    public List<HcnCheckBox> getHcnCheckBoxList() {
        return hcnCheckBoxList;
    }

    public void mouseClicked(HcnCheckBox hcnCheckBox) {
        if(!hcnCheckBoxList.contains(hcnCheckBox)){
            return;
        }
        for(HcnCheckBox checkBox : hcnCheckBoxList){
            if(checkBox != hcnCheckBox){
                checkBox.setSelected(false);
            }
        }
        save();
    }

    private void save() {
        String memory = null;
        for(HcnCheckBox checkBox : hcnCheckBoxList){
            if(checkBox.isSelected()){
                memory = checkBox.getMemory()+"";
                break;
            }
        }
        if(memory == null){
            hcnCheckBoxList.get(0).setSelected(true);
            System.out.println("[HuntiesLauncher] Can't save memory.");
            return;
        }
        Main.INSTANCE.getHuntiesOption().setString("memory", memory);
        System.out.println("[HuntiesLauncher] Max memory chosen: "+memory);
    }

    public void setVisible(boolean b) {
        for(HcnCheckBox hcnCheckBox : hcnCheckBoxList){
            hcnCheckBox.setVisible(b);
        }
        if(b){
            selectChosenRam(Main.INSTANCE.getHuntiesFrame().getHuntiesPanel());
        }
    }
}
