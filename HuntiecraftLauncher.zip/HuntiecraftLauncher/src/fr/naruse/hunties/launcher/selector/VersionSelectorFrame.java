package fr.naruse.hunties.launcher.selector;

import fr.naruse.hunties.launcher.main.HuntiesPanel;
import fr.naruse.hunties.launcher.main.Main;
import fr.theshark34.swinger.Swinger;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class VersionSelectorFrame extends JFrame implements ActionListener {
    private HuntiesPanel huntiesPanel;
    private JButton ok, reset;
    private JComboBox versions = new JComboBox(new String[] {"1.8", "1.9", "1.10","1.11","1.12", "1.13", "1.14"});
    public VersionSelectorFrame(HuntiesPanel huntiesPanel) {
        this.huntiesPanel = huntiesPanel;
        this.setTitle("Sélectionner une version");
        this.setResizable(false);
        this.setSize(425, 180);
        this.setIconImage(Swinger.getResource("icon.jpg"));
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        JLabel chooseHardDriveText = new JLabel("Version:");
        chooseHardDriveText.setBounds(10, 0, 200, 100);
        chooseHardDriveText.setFont(chooseHardDriveText.getFont().deriveFont(15f));
        this.add(chooseHardDriveText);

        ArrayList<String> hdd = new ArrayList<>();
        File[] paths;
        paths = File.listRoots();
        for(File path:paths) {
            hdd.add(path.toString());
        }
        ok = new JButton("Ok");
        ok.addActionListener(this);
        ok.setBounds(getWidth()/2-80/2-52, 70, 100, 23);
        this.add(ok);
        reset = new JButton("Reset");
        reset.addActionListener(this);
        reset.setBounds(getWidth()/2-80/2+52, 70, 100, 23);
        this.add(reset);
        versions.setBounds(375-200-40, 40, 150, 20);
        versions.addActionListener(this);
        refreshVersion();
        this.add(versions);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == ok){
            System.out.println("[HuntiesLauncher] Version : "+versions.getSelectedItem());
            huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().setString("version", versions.getSelectedItem()+"");
            refreshVersion();
            setVisible(false);
        }
        if(e.getSource() == reset){
            huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().setString("version", "1.12");
            refreshVersion();
        }
    }

    private void refreshVersion(){
        switch (huntiesPanel.getHuntiesFrame().getMain().getHuntiesOption().getString("version")){
            case "1.8": versions.setSelectedIndex(0); break;
            case "1.9": versions.setSelectedIndex(1); break;
            case "1.10": versions.setSelectedIndex(2); break;
            case "1.11": versions.setSelectedIndex(3); break;
            case "1.12": versions.setSelectedIndex(4); break;
            case "1.13": versions.setSelectedIndex(5); break;
            case "1.14": versions.setSelectedIndex(6); break;
        }
    }

    public static String getVersion(){
        switch (Main.INSTANCE.getHuntiesOption().getString("version")){
            case "1.8": return "1.8.9";
            case "1.9": return "1.9.4";
            case "1.10": return "1.10.2";
            case "1.11": return "1.11.2";
            case "1.12": return "1.12.2";
            case "1.13": return "1.13.2";
            case "1.14": return "1.14.4";
        }
        return null;
    }
}
