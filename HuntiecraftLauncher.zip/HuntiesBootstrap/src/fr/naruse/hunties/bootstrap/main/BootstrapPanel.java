package fr.naruse.hunties.bootstrap.main;

import fr.theshark34.swinger.colored.SColoredBar;

import javax.swing.*;
import java.awt.*;

import static fr.theshark34.swinger.Swinger.getTransparentWhite;

public class BootstrapPanel extends JPanel {
    private JLabel infoLabel = new JLabel("Initialisation...");
    private SColoredBar progressBar = new SColoredBar(getTransparentWhite(100), getTransparentWhite(175));
    public BootstrapPanel() {
        this.setLayout(null);
        this.infoLabel.setForeground(Color.BLACK);
        this.infoLabel.setFont(infoLabel.getFont().deriveFont(17F));
        this.infoLabel.setBounds(145, 20, 400, 40);
        this.add(infoLabel);
        this.progressBar.setVisible(true);
        this.progressBar.setBackground(Color.LIGHT_GRAY);
        this.progressBar.setForeground(new Color(194, 57, 16));
        this.progressBar.setBounds(12, 65, 400-15*2, 20);
        this.add(progressBar);
    }

    public void setInfoText(String text){
        this.infoLabel.setText(text);
    }

    public SColoredBar getProgressBar() {
        return progressBar;
    }

    public JLabel getInfoLabel() {
        return infoLabel;
    }
}
