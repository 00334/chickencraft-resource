package fr.naruse.hunties.bootstrap.main;

import fr.naruse.hunties.bootstrap.log.LogFrame;
import fr.theshark34.openlauncherlib.external.ClasspathConstructor;
import fr.theshark34.openlauncherlib.external.ExternalLaunchProfile;
import fr.theshark34.openlauncherlib.external.ExternalLauncher;

import java.io.File;
import java.io.IOException;

public class Updater {
    private Main main;
    public Updater(Main main) {
        this.main = main;
    }

    public void update() {
        System.out.println("[HuntiesBootstrap] Checking dir location: "+main.dir.getAbsolutePath());
        if(!main.dir.exists()){
            main.dir.mkdirs();
            System.out.println("[HuntiesBootstrap] Dir created to: "+main.dir.getAbsolutePath());
        }
        System.out.println("[HuntiesBootstrap] Starting download...");
        try {
            Utils.downloadFile(main, main.bootstrapPanel, "https://huntiescraft.net/public/launcher/servers/sides/common/files/launcher.jar", new File(main.dir, "launcher.jar"));
        } catch (IOException e) {
            main.bootstrapPanel.setInfoText("Erreur : "+e);
            e.printStackTrace();
        }
        main.bootstrapPanel.setInfoText("Lancement...");
        ClasspathConstructor constructor = new ClasspathConstructor();
        constructor.add(new File("launcher.jar"));
        ExternalLaunchProfile profile = new ExternalLaunchProfile("fr.naruse.hunties.launcher.main.Main", main.dir+"/launcher.jar");
        ExternalLauncher launcher = new ExternalLauncher(profile);
        main.splashFrame.stop();
        try {
            Process p = Runtime.getRuntime().exec("java -jar "+new File(main.dir+"/launcher.jar").getAbsolutePath());
           // Process p = launcher.launch();
            main.setVisible(false);
            Thread.sleep(1000*6);
            LogFrame.getINTANCE().setVisible(false);
            p.waitFor();
        } catch (Exception e) {
            main.bootstrapPanel.setInfoText("Erreur : "+e);
            e.printStackTrace();
        }
        System.exit(0);
    }
}
