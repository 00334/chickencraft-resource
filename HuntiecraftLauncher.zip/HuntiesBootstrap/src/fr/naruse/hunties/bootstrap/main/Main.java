package fr.naruse.hunties.bootstrap.main;

import fr.naruse.hunties.bootstrap.log.HuntiesOutputStream;
import fr.naruse.hunties.bootstrap.log.LogFrame;
import fr.theshark34.openlauncherlib.minecraft.GameInfos;
import fr.theshark34.openlauncherlib.minecraft.GameTweak;
import fr.theshark34.openlauncherlib.minecraft.GameType;
import fr.theshark34.openlauncherlib.minecraft.GameVersion;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.util.WindowMover;

import javax.swing.*;
import java.io.File;
import java.io.PrintStream;

public class Main extends JFrame {

    public static void main(String[] args){
        Swinger.setSystemLookNFeel();
        Swinger.setResourcePath("/fr/naruse/hunties/bootstrap/main/");
        new Main();
    }

    public GameVersion version = new GameVersion("1.12.2", GameType.V1_8_HIGHER);
    public GameInfos infos = new GameInfos("HuntiesCraft-Network", version, new GameTweak[] {GameTweak.FORGE});
    public File dir = infos.getGameDir();
    public BootstrapPanel bootstrapPanel;
    public SplashFrame splashFrame;

    private LogFrame logFrame;
    private HuntiesOutputStream huntiesOutputStream;
    public Main() {
        System.setOut(new PrintStream(huntiesOutputStream = new HuntiesOutputStream()));
        this.logFrame = new LogFrame();
        huntiesOutputStream.setLogFrame(logFrame);

        System.out.println("[HuntiesBootstrap] Loading SplashScreen...");
        splashFrame = new SplashFrame();
        System.out.println("[HuntiesBootstrap] Showing SplashScreen");
        splashFrame.display();
        System.out.println("[HuntiesBootstrap] Initialisation...");
        this.setTitle("HuntiesCraft-Network");
        this.setIconImage(Swinger.getResource("icons.jpg"));
        this.setSize(400, 150);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        System.out.println("[HuntiesBootstrap] Setting panel...");
        this.setContentPane(bootstrapPanel = new BootstrapPanel());
        this.setResizable(false);
        System.out.println("[HuntiesBootstrap] Setting WindowMover...");
        WindowMover mover = new WindowMover(this);
        this.addMouseListener(mover);
        this.addMouseMotionListener(mover);
        new Updater(this).update();
    }
}
