package fr.naruse.hunties.bootstrap.main;

import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.animation.Animator;

import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.util.concurrent.TimeUnit;

public class SplashFrame extends JFrame {
    public SplashFrame() {
        this.setTitle("HuntiesCraft-Network");
        this.setUndecorated(true);
        this.setIconImage(Swinger.getResource("icons.jpg"));
        this.setDefaultCloseOperation(3);
        this.setSize(Swinger.getResource("icons.jpg").getWidth(this), Swinger.getResource("icons.jpg").getHeight(this));
        this.setLocationRelativeTo(null);
        this.setBackground(new Color(0, 0, 0, 0));
        BufferedImage image = Swinger.getResource("logos.png");
        this.setContentPane(new SplashPanel(image));

    }

    public void display() {
        Animator.fadeInFrame(this, Animator.FAST);
        this.setVisible(true);
    }

    public void stop() {
        new Thread(){
            @Override
            public void run() {
                super.run();
                try {
                    Thread.sleep(TimeUnit.SECONDS.toMillis(2));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Animator.fadeOutFrame(SplashFrame.this, Animator.FAST);
                try {
                    Thread.sleep(TimeUnit.SECONDS.toMillis(1));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                SplashFrame.this.setVisible(false);
            }
        }.start();
    }

    private class SplashPanel extends JPanel {
        private Image image;
        public SplashPanel(Image bufferedImage) {
            this.image = bufferedImage;
            setOpaque(false);
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(this.image, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }
}
