package fr.naruse.hunties.bootstrap.main;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

public class Utils {

    public static File downloadFile(Main main, BootstrapPanel bootstrapPanel, String host, File dest) throws IOException, NullPointerException{
        InputStream is = null;
        OutputStream os = null;
        try {
            System.out.println("[HuntiesBootstrap] Getting url host...");
            URL url = new URL(host);
            System.out.println("[HuntiesBootstrap] Opening connection..");
            URLConnection connection = url.openConnection();
            int fileLength = connection.getContentLength();
            System.out.println("[HuntiesBootstrap] File length: "+fileLength);
            if (fileLength == -1) {
                System.out.println("Invalide URL or file.");
                return null;
            }
            if(dest.exists()){
                System.out.println("[HuntiesBootstrap] launcher.jar already exists !");
                System.out.println("[HuntiesBootstrap] Checking launcher.jar...");
                if(dest.length() == fileLength){
                    System.out.println("[HuntiesBootstrap] launcher.jar is updated.");
                    return dest;
                }
                System.out.println("[HuntiesBootstrap] Deleting launcher.jar...");
                dest.delete();
                System.out.println("[HuntiesBootstrap] Delete complete.");
            }
            main.setVisible(true);
            System.out.println("[HuntiesBootstrap] Opening stream...");
            is = connection.getInputStream();
            os = new FileOutputStream(dest);
            System.out.println("[HuntiesBootstrap] Starting writing...");
            byte[] buffer = new byte[1024];
            int length;
            int count = 0;
            DecimalFormat df = new java.text.DecimalFormat("0.##");
            bootstrapPanel.getInfoLabel().setBounds(10, 20, 400, 40);
            int repeat = 0;
            while ((length = is.read(buffer)) > 0) {
                count += length;
                bootstrapPanel.getProgressBar().setMaximum(fileLength);
                bootstrapPanel.getProgressBar().setValue(count);
                bootstrapPanel.setInfoText("Téléchargement du launcher ("+df.format(count*0.000001)+" Mo /"+df.format(fileLength*0.000001)+" Mo)");
                if(repeat >= 10){
                    repeat = 0;
                    System.out.println("[HuntiesBootstrap] Status: "+count+"/"+fileLength);
                }
                os.write(buffer, 0, length);
                repeat++;
            }
            System.out.println("[HuntiesBootstrap] Download successful for "+dest.getName()+".");
        } finally {
            if(is != null){
                is.close();
                os.close();
            }
        }
        return dest;
    }


}
