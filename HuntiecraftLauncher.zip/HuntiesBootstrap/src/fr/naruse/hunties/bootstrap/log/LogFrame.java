package fr.naruse.hunties.bootstrap.log;

import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.util.WindowMover;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class LogFrame extends JFrame {
    private JTextPane jTextPane = new JTextPane();
    private JScrollPane jScrollPane = new JScrollPane(jTextPane);
    private static LogFrame INTANCE;
    public LogFrame() {
        this.INTANCE = this;
        this.setTitle("HuntiesCraft-Network | Console de Logs");
        this.setIconImage(Swinger.getResource("icons.jpg"));
        this.setSize(1200, 560);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        //this.setContentPane(null);
        WindowMover mover = new WindowMover(this);
        this.addMouseListener(mover);
        this.addMouseMotionListener(mover);

        JTextArea textArea = new JTextArea();
        jTextPane.setForeground(textArea.getForeground());
        jTextPane.setFont(textArea.getFont());
        jTextPane.setEditable(false);
        jTextPane.setBackground(Color.GRAY);
        this.add(jScrollPane);

        this.setVisible(true);
    }

    public static LogFrame getINTANCE() {
        return INTANCE;
    }

    public void showInfo(String info) {
        append(info);
        this.validate();
        scrollDown();
    }

    public void showInfo(String info, Color color) {
        StyledDocument doc = jTextPane.getStyledDocument();

        Style style = jTextPane.addStyle("I'm a Style", null);
        StyleConstants.setForeground(style, color);
        try {
            doc.insertString(doc.getLength(), info, style);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
        this.validate();
        scrollDown();
    }

    private void append(String s) {
        try {
            Document doc = jTextPane.getDocument();
            doc.insertString(doc.getLength(), s, null);
        } catch(BadLocationException exc) {
            exc.printStackTrace();
        }
    }

    public void scrollDown(){
        jScrollPane.getVerticalScrollBar().setValue(jScrollPane.getVerticalScrollBar().getMaximum());
    }
}
