package fr.naruse.hunties.bootstrap.log;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HuntiesOutputStream extends OutputStream {

    private LogFrame logFrame = null;
    private final StringBuilder sb = new StringBuilder();
    public HuntiesOutputStream() {
    }

    @Override
    public void flush() throws IOException {
        super.flush();
    }

    @Override
    public void close() throws IOException {
        super.close();
    }

    @Override
    public void write(int b) throws IOException {
        if(logFrame == null){
           return;
        }
        if (b == '\r'){
            return;
        }
        if (b == '\n') {
            final String text = sb.toString() + "\n";
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    String newText = text;
                    if(newText.length() >= 1) if(newText.toCharArray()[1] == 'H' || newText.toCharArray()[1] == 'L'){
                        newText = "["+getDate()+"] "+newText;
                    }
                    newText = newText.replace("OpenLauncherLib", "HuntiesBootstrap").replace("TheShark34", "HuntiesCraft");
                    if(newText.contains("ERROR") || newText.contains("Exception") || newText.contains("?]") || newText.contains(".java")
                            || newText.contains("java.") ||newText.contains("Method") && !newText.contains("OptiFine")){
                        logFrame.showInfo(newText, new Color(133, 0, 0));
                    }else if(newText.contains("FATAL")){
                        logFrame.showInfo(newText, new Color(160, 147, 0));
                    }else if(newText.contains("WARN")){
                        logFrame.showInfo(newText, new Color(22, 61, 15));
                    }else{
                        logFrame.showInfo(newText);
                    }
                }
            });
            sb.setLength(0);
            return;
        }
        sb.append((char) b);
    }

    private String getDate(){
        return new SimpleDateFormat("HH:mm:ss").format(new Date());
    }

    public void setLogFrame(LogFrame logFrame) {
        this.logFrame = logFrame;
    }
}
